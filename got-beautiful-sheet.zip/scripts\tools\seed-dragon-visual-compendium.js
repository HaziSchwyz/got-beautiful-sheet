import { DRAGON_VISUAL_COMPENDIUM_DATA } from "../data/dragon-visual-compendium-data.js";

const MODULE_ID = "got-beautiful-sheet";
const PACK_ID = `${MODULE_ID}.dragon-visuals-got`;

function normalizeKey(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function visualToItemData(visual) {
  const mapped = visual.mappedSheetColors ?? {};
  const fullColors = visual.colors ?? {};

  return {
    name: visual.name,
    type: "equippableItem",
    img: visual.icon || "icons/svg/dragon.svg",
    system: {},
    flags: {
      [MODULE_ID]: {
        gearType: "dragonVisual",
        visualType: "dragonScales",
        dragonName: visual.name,
        visualKey: visual.visualKey ?? normalizeKey(visual.name),

        colors: {
          primary: mapped.primary ?? "#07111c",
          secondary: mapped.secondary ?? "#0a1d2c",
          accent: mapped.accent ?? "#d4472f",
          coldAccent: mapped.coldAccent ?? "#2aa6b8",
          textMain: mapped.textMain ?? "#f2e7d8"
        },

        dragonPalette: {
          bodyPrimary: fullColors.bodyPrimary ?? "",
          bodySecondary: fullColors.bodySecondary ?? "",
          bodyShadow: fullColors.bodyShadow ?? "",
          bodyHighlight: fullColors.bodyHighlight ?? "",
          wingMembrane: fullColors.wingMembrane ?? "",
          wingMembraneShadow: fullColors.wingMembraneShadow ?? "",
          spines: fullColors.spines ?? "",
          horns: fullColors.horns ?? "",
          throat: fullColors.throat ?? "",
          eyes: fullColors.eyes ?? "",
          textMain: fullColors.textMain ?? ""
        },

        scalePattern: visual.scalePattern ?? "default",
        scaleTexture: visual.scaleTexture ?? "",
        scaleOpacity: visual.scaleOpacity ?? 0.28,
        scaleSize: visual.scaleSize ?? 32,

        notes: visual.notes ?? "",
        notas: visual.notes ?? ""
      }
    }
  };
}

export async function seedDragonVisualCompendium() {
  if (!game.user?.isGM) {
    ui.notifications.error("Apenas o Mestre pode popular o compendium de Visuais de Dragão GOT.");
    return;
  }

  const pack = game.packs.get(PACK_ID);

  if (!pack) {
    ui.notifications.error(`Compendium não encontrado: ${PACK_ID}.`);
    return;
  }

  const wasLocked = pack.locked;
  if (wasLocked) {
    await pack.configure({ locked: false });
  }

  const existingDocuments = await pack.getDocuments();
  let created = 0;
  let updated = 0;

  for (const visual of DRAGON_VISUAL_COMPENDIUM_DATA) {
    const itemData = visualToItemData(visual);

    const existing = existingDocuments.find((document) => {
      const keyA = normalizeKey(document.name);
      const keyB = normalizeKey(itemData.name);
      return keyA === keyB;
    });

    if (existing) {
      await existing.update(itemData);
      updated += 1;
    } else {
      await Item.create(itemData, { pack: PACK_ID });
      created += 1;
    }
  }

  if (wasLocked) {
    await pack.configure({ locked: true });
  }

  ui.notifications.info(`Visuais de Dragão GOT populados. Criados: ${created}. Atualizados: ${updated}.`);
  console.log(`${MODULE_ID} | Visuais de Dragão GOT populados`, { created, updated });
}

globalThis.seedDragonVisualCompendium = seedDragonVisualCompendium;

await seedDragonVisualCompendium();