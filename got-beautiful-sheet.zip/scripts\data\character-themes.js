export const CHARACTER_THEMES = {
  "royal-dark": {
    id: "royal-dark",
    label: "Noite Real",
    description: "Tema atual azul-escuro da ficha.",
    variables: {
      "--got-primary": "#07111C",
      "--got-secondary": "#0A1D2C",
      "--got-accent": "#8A2E24",
      "--got-cold-accent": "#2AA6B8",
      "--got-text-main": "#F2E7D8",
      "--got-theme-bg":
        "linear-gradient(135deg, rgba(7, 17, 28, 0.96), rgba(5, 11, 18, 0.98)), #07111C",
      "--got-theme-panel":
        "linear-gradient(180deg, rgba(13, 38, 56, 0.86), rgba(8, 24, 38, 0.90))",
      "--got-theme-header":
        "linear-gradient(90deg, rgba(10, 29, 44, 0.88), rgba(7, 17, 28, 0.94))",
      "--got-theme-button":
        "rgba(5, 11, 18, 0.72)",
      "--got-theme-input":
        "rgba(5, 11, 18, 0.55)",
      "--got-theme-border": "rgba(42, 166, 184, 0.25)",
      "--got-theme-border-hot": "rgba(138, 46, 36, 0.65)"
    }
  },

  "medieval-parchment": {
    id: "medieval-parchment",
    label: "Medieval Pergaminho",
    description: "Tema claro, elegante e legível em estilo pergaminho medieval.",
    variables: {
      "--got-primary": "#d9c69a",
      "--got-secondary": "#ceb98a",
      "--got-accent": "#8b3a2b",
      "--got-cold-accent": "#7a5a34",
      "--got-text-main": "#3c2918",
      "--got-theme-bg":
        "linear-gradient(135deg, rgba(231, 218, 184, 0.98), rgba(214, 195, 152, 0.98)), #d9c69a",
      "--got-theme-panel":
        "linear-gradient(180deg, rgba(240, 228, 196, 0.96), rgba(224, 205, 165, 0.98))",
      "--got-theme-header":
        "linear-gradient(90deg, rgba(222, 205, 165, 0.98), rgba(204, 181, 133, 0.98))",
      "--got-theme-button":
        "rgba(238, 225, 193, 0.98)",
      "--got-theme-input":
        "rgba(248, 241, 223, 0.98)",
      "--got-theme-border": "rgba(122, 90, 52, 0.28)",
      "--got-theme-border-hot": "rgba(139, 58, 43, 0.60)"
    }
  },

  "belaerys": {
    id: "belaerys",
    label: "Casa Belaerys",
    description: "Tema azul, dourado e vermelho inspirado no estandarte Belaerys.",
    variables: {
      "--got-primary": "#082347",
      "--got-secondary": "#123865",
      "--got-accent": "#c62828",
      "--got-cold-accent": "#e0b83f",
      "--got-text-main": "#f7f0d7",
      "--got-theme-bg":
        "linear-gradient(135deg, rgba(8, 35, 71, 0.98), rgba(4, 18, 42, 0.98)), #082347",
      "--got-theme-panel":
        "linear-gradient(180deg, rgba(16, 50, 92, 0.90), rgba(9, 30, 58, 0.92))",
      "--got-theme-header":
        "linear-gradient(90deg, rgba(18, 56, 101, 0.96), rgba(8, 35, 71, 0.96))",
      "--got-theme-button":
        "rgba(9, 24, 48, 0.88)",
      "--got-theme-input":
        "rgba(5, 17, 36, 0.82)",
      "--got-theme-border": "rgba(224, 184, 63, 0.34)",
      "--got-theme-border-hot": "rgba(198, 40, 40, 0.72)"
    }
  },

  "targaryen-blacks": {
    id: "targaryen-blacks",
    label: "Targaryen — Negros",
    description: "Tema sombrio em preto, vermelho e dourado envelhecido.",
    variables: {
      "--got-primary": "#0d0a0a",
      "--got-secondary": "#1a1212",
      "--got-accent": "#a61d24",
      "--got-cold-accent": "#8c6a2b",
      "--got-text-main": "#f1e6cf",
      "--got-theme-bg":
        "linear-gradient(135deg, rgba(16, 10, 10, 0.98), rgba(6, 4, 4, 0.98)), #0d0a0a",
      "--got-theme-panel":
        "linear-gradient(180deg, rgba(28, 18, 18, 0.92), rgba(16, 10, 10, 0.92))",
      "--got-theme-header":
        "linear-gradient(90deg, rgba(26, 18, 18, 0.96), rgba(13, 10, 10, 0.96))",
      "--got-theme-button":
        "rgba(14, 10, 10, 0.90)",
      "--got-theme-input":
        "rgba(12, 9, 9, 0.90)",
      "--got-theme-border": "rgba(140, 106, 43, 0.34)",
      "--got-theme-border-hot": "rgba(166, 29, 36, 0.72)"
    }
  },

  "targaryen-greens": {
    id: "targaryen-greens",
    label: "Targaryen — Verdes",
    description: "Tema verde profundo com dourado e marfim.",
    variables: {
      "--got-primary": "#0f261d",
      "--got-secondary": "#18372b",
      "--got-accent": "#a67c2d",
      "--got-cold-accent": "#6e8d60",
      "--got-text-main": "#f3ebd4",
      "--got-theme-bg":
        "linear-gradient(135deg, rgba(15, 38, 29, 0.98), rgba(8, 20, 15, 0.98)), #0f261d",
      "--got-theme-panel":
        "linear-gradient(180deg, rgba(24, 55, 43, 0.92), rgba(14, 33, 25, 0.92))",
      "--got-theme-header":
        "linear-gradient(90deg, rgba(24, 55, 43, 0.96), rgba(15, 38, 29, 0.96))",
      "--got-theme-button":
        "rgba(10, 24, 18, 0.90)",
      "--got-theme-input":
        "rgba(9, 22, 17, 0.88)",
      "--got-theme-border": "rgba(110, 141, 96, 0.34)",
      "--got-theme-border-hot": "rgba(166, 124, 45, 0.72)"
    }
  }
};

export function getCharacterTheme(themeId) {
  return CHARACTER_THEMES[themeId] ?? CHARACTER_THEMES["royal-dark"];
}

export function getCharacterThemeChoices() {
  return Object.values(CHARACTER_THEMES).map((theme) => ({
    value: theme.id,
    label: theme.label
  }));
}