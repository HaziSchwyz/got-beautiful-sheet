﻿export const DRAGON_VISUAL_COMPENDIUM_DATA = [
  {
    name: "Tarrax",
    icon: "icons/svg/dragon.svg",
    visualKey: "tarrax",
    colors: {
      bodyPrimary: "#075a70",
      bodySecondary: "#063140",
      bodyShadow: "#041b24",
      bodyHighlight: "#1797b0",
      wingMembrane: "#e13b22",
      wingMembraneShadow: "#8f1f18",
      spines: "#ff5a2e",
      horns: "#d8793e",
      throat: "#d6a847",
      eyes: "#ffbd4a",
      textMain: "#f7ead2"
    },
    mappedSheetColors: {
      primary: "#041b24",
      secondary: "#063140",
      accent: "#e13b22",
      coldAccent: "#1797b0",
      textMain: "#f7ead2"
    },
    scaleTexture: "",
    sheetBackground: "",
    panelTexture: "",
    frameTexture: "",
    scalePattern: "lite-ambient",
    scaleOpacity: 0,
    scaleSize: 0,
    notes: "Preset visual do dragão Tarrax. Corpo azul-petróleo escuro, membranas vermelhas, espinhos vermelho-alaranjados e garganta dourada."
  },
  {
    name: "Harrengon",
    icon: "icons/svg/dragon.svg",
    visualKey: "harrengon",
    colors: {
      bodyPrimary: "#121820",
      bodySecondary: "#070a0f",
      bodyShadow: "#020306",
      bodyHighlight: "#1f6fd1",
      wingMembrane: "#0a111c",
      wingMembraneShadow: "#02050a",
      spines: "#2e8cff",
      horns: "#b8c2cc",
      throat: "#6f7f90",
      eyes: "#6bb8ff",
      textMain: "#e7edf2"
    },
    mappedSheetColors: {
      primary: "#05080d",
      secondary: "#101923",
      accent: "#2e8cff",
      coldAccent: "#6bb8ff",
      textMain: "#e7edf2"
    },
    scaleTexture: "",
    sheetBackground: "",
    panelTexture: "",
    frameTexture: "",
    scalePattern: "lite-ambient",
    scaleOpacity: 0,
    scaleSize: 0,
    notes: "Preset visual do dragão Harrengon. Corpo negro-grafite, escamas carvão, reflexos azul-cobalto frios e chifres prateados, com presença sombria inspirada em Harrenhal."
  }
];
