import { GOT_WEAPONS, GOT_WEAPON_QUALITIES, GOT_WEAPON_COMPENDIUM_SEED_VERSION } from "../data/gear-compendium-data.js";

const MODULE_ID = "got-beautiful-sheet";
const SEED_SOURCE = "got-gear-compendium-seed";

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function toArray(value) {
  return Array.isArray(value) ? value : [];
}

function cleanText(value) {
  const text = String(value ?? "").trim();
  return ["-", "—", "–"].includes(text) ? "" : text;
}

function makeWeaponDescription(weapon) {
  const qualities = toArray(weapon.qualidadesLista).join(", ") || "Nenhuma";

  return `<section class="got-gear-description got-weapon-description">
    <p><strong>Grupo:</strong> ${escapeHTML(weapon.grupo)}</p>
    <p><strong>Especialidade:</strong> ${escapeHTML(weapon.especialidade)}</p>
    <p><strong>Treinamento:</strong> ${escapeHTML(cleanText(weapon.treinamento) || "Nenhum")}</p>
    <p><strong>Dano:</strong> ${escapeHTML(weapon.dano)}</p>
    <p><strong>Qualidades:</strong> ${escapeHTML(qualities)}</p>
    <p><strong>Peso:</strong> ${escapeHTML(cleanText(weapon.peso) || "-")}</p>
    <p><strong>Preço:</strong> ${escapeHTML(cleanText(weapon.preco) || "-")}</p>
    ${cleanText(weapon.notas) ? `<p><strong>Notas:</strong> ${escapeHTML(weapon.notas)}</p>` : ""}
  </section>`;
}

function makeQualityDescription(quality) {
  return `<section class="got-gear-description got-weapon-quality-description">
    <p><strong>Tipo:</strong> ${escapeHTML(quality.tipo)}</p>
    <p><strong>Efeito:</strong> ${escapeHTML(quality.efeito)}</p>
    <hr>
    <p>${escapeHTML(quality.descricao)}</p>
    ${cleanText(quality.notas) ? `<p><strong>Notas:</strong> ${escapeHTML(quality.notas)}</p>` : ""}
  </section>`;
}

function getWeaponImage(weapon) {
  const group = weapon.grupo ?? "";
  const name = weapon.nome ?? "";

  if (group === "Escudos") return "icons/equipment/shield/kite-wooden-boss-brown.webp";
  if (["Arcos", "Bestas", "Armas Arremessadas"].includes(group)) return "icons/weapons/bows/shortbow-recurve.webp";
  if (name.includes("Lança") || group === "Lanças" || group === "Armas de Haste") return "icons/weapons/polearms/spear-flared-silver-pink.webp";
  if (group === "Machados") return "icons/weapons/axes/axe-battle-black.webp";
  if (["Lâminas Longas", "Lâminas Curtas", "Esgrima"].includes(group)) return "icons/weapons/swords/sword-broad-serrated-blue.webp";

  return "icons/weapons/hammers/hammer-war-rounding.webp";
}

function getQualityImage(quality) {
  const name = quality.nome ?? "";

  if (name.startsWith("Defensiva")) return "icons/equipment/shield/heater-steel-blue.webp";
  if (name.startsWith("Volume")) return "icons/containers/bags/sack-cloth-brown.webp";
  if (name.includes("Perfurante")) return "icons/weapons/ammunition/arrow-head-war-flight.webp";
  if (name.includes("Recarga")) return "icons/skills/ranged/crossbow-aim-bolt-blue.webp";

  return "icons/sundries/documents/document-sealed-red.webp";
}

function makeWeaponDocument(weapon) {
  const qualities = toArray(weapon.qualidadesLista);
  const data = {
    seedId: weapon.id,
    gearType: "weapon",
    group: weapon.grupo,
    specialty: weapon.especialidade,
    training: cleanText(weapon.treinamento),
    damage: cleanText(weapon.dano),
    qualities,
    qualitiesText: qualities.join("|"),
    weight: cleanText(weapon.peso),
    price: cleanText(weapon.preco),
    notes: cleanText(weapon.notas)
  };

  return {
    name: weapon.nome,
    type: "equippableItem",
    img: getWeaponImage(weapon),
    system: {
      description: makeWeaponDescription(weapon),
      category: weapon.grupo,
      props: {
        gearType: "weapon",
        isGotWeapon: true,
        ...data,
        flags: { gearType: "weapon" }
      }
    },
    flags: {
      [MODULE_ID]: {
        gearType: "weapon",
        seedSource: SEED_SOURCE,
        seedVersion: GOT_WEAPON_COMPENDIUM_SEED_VERSION,
        weaponData: data
      }
    }
  };
}

function makeWeaponQualityDocument(quality) {
  const data = {
    seedId: quality.id,
    gearType: "weaponQuality",
    qualityType: quality.tipo,
    effect: quality.efeito,
    value: quality.valor ?? null,
    notes: cleanText(quality.notas)
  };

  return {
    name: quality.nome,
    type: "equippableItem",
    img: getQualityImage(quality),
    system: {
      description: makeQualityDescription(quality),
      category: "Qualidade de Arma",
      props: {
        gearType: "weaponQuality",
        isGotWeaponQuality: true,
        ...data,
        flags: { gearType: "weaponQuality" }
      }
    },
    flags: {
      [MODULE_ID]: {
        gearType: "weaponQuality",
        seedSource: SEED_SOURCE,
        seedVersion: GOT_WEAPON_COMPENDIUM_SEED_VERSION,
        weaponQualityData: data
      }
    }
  };
}

async function forceUnlockPack(pack) {
  if (!pack) return false;

  const attempts = [];

  const tryStep = async (label, fn) => {
    try {
      await fn();
      attempts.push(`${label}: ok`);
    } catch (error) {
      attempts.push(`${label}: falhou (${error?.message ?? error})`);
    }
  };

  await tryStep("configure locked=false", async () => {
    if (typeof pack.configure === "function") await pack.configure({ locked: false });
  });

  await tryStep("metadata.locked=false", async () => {
    if (pack.metadata) pack.metadata.locked = false;
  });

  await tryStep("pack.locked=false", async () => {
    pack.locked = false;
  });

  await tryStep("defineProperty locked=false", async () => {
    Object.defineProperty(pack, "locked", {
      value: false,
      writable: true,
      configurable: true
    });
  });

  console.log(`${MODULE_ID} | Tentativas de destravar ${pack.collection}:`, attempts, {
    locked: pack.locked,
    metadataLocked: pack.metadata?.locked
  });

  return pack.locked === false;
}

async function assertPackWritable(pack, label) {
  const unlocked = await forceUnlockPack(pack);

  if (!unlocked || pack.locked) {
    ui.notifications.error(`${label} continua travado. Destrave pelo botão/cadeado do compendium e rode o seed novamente.`);
    throw new Error(`${label} locked after unlock attempts`);
  }
}

async function clearSeededDocuments(pack, gearType) {
  const documents = await pack.getDocuments();
  const ids = documents
    .filter((document) => {
      return document.getFlag?.(MODULE_ID, "seedSource") === SEED_SOURCE
        || document.getFlag?.(MODULE_ID, "gearType") === gearType;
    })
    .map((document) => document.id);

  if (ids.length > 0) {
    await Item.deleteDocuments(ids, { pack: pack.collection });
  }
}

async function seedPack({ packId, label, gearType, documents }) {
  const pack = game.packs.get(packId);

  if (!pack) {
    ui.notifications.error(`Compêndio não encontrado: ${label}. Confirme se o module.json foi substituído e reinicie o Foundry.`);
    throw new Error(`Compendium not found: ${packId}`);
  }

  await assertPackWritable(pack, label);
  await clearSeededDocuments(pack, gearType);
  await Item.createDocuments(documents, { pack: pack.collection });

  console.log(`${MODULE_ID} | ${label}: ${documents.length} itens gerados.`);
  return documents.length;
}

export async function seedGotGearCompendia() {
  if (!game.user?.isGM) {
    ui.notifications.warn("Apenas o Mestre pode popular os compêndios GOT.");
    return null;
  }

  const weaponDocs = GOT_WEAPONS.map(makeWeaponDocument);
  const qualityDocs = GOT_WEAPON_QUALITIES.map(makeWeaponQualityDocument);

  const weaponCount = await seedPack({
    packId: `${MODULE_ID}.armas-got`,
    label: "Armas GOT",
    gearType: "weapon",
    documents: weaponDocs
  });

  const qualityCount = await seedPack({
    packId: `${MODULE_ID}.qualidades-armas-got`,
    label: "Qualidades de Arma GOT",
    gearType: "weaponQuality",
    documents: qualityDocs
  });

  ui.notifications.info(`Compêndios GOT populados: ${weaponCount} armas e ${qualityCount} qualidades de arma.`);

  return {
    weapons: weaponCount,
    qualities: qualityCount
  };
}

globalThis.GOTSeedGearCompendia = seedGotGearCompendia;
