const MODULE_ID = "got-beautiful-sheet";

const DEFAULT_TRAIT_SYSTEM = {
  description: "",
  category: "",
  prerequisite: "",
  effects: [],
  flags: {},
  notes: [],
  configs: [],
  configValues: {},
  automationVersion: ""
};

function cloneValue(value) {
  return foundry.utils.deepClone(value);
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function getDocumentObject(document) {
  if (!document || typeof document !== "object") return {};

  if (typeof document.toObject === "function") {
    return document.toObject();
  }

  return document;
}

function getSourceSystem(itemOrSystem = {}) {
  if (itemOrSystem?.documentName === "Item") {
    const objectSystem = getDocumentObject(itemOrSystem).system ?? {};
    const sourceSystem = itemOrSystem._source?.system ?? {};

    return foundry.utils.mergeObject(cloneValue(sourceSystem), objectSystem, {
      inplace: false,
      insertKeys: true,
      insertValues: true,
      overwrite: true
    });
  }

  if (itemOrSystem?.system) {
    return getDocumentObject(itemOrSystem).system ?? {};
  }

  return getDocumentObject(itemOrSystem);
}

function getFlagValue(item, scope, key) {
  if (typeof item?.getFlag === "function") {
    const value = item.getFlag(scope, key);
    if (value !== undefined) return value;
  }

  return item?.flags?.[scope]?.[key] ?? item?._source?.flags?.[scope]?.[key];
}

function firstDefined(...values) {
  return values.find((value) => value !== undefined && value !== null);
}

function firstText(...values) {
  const value = firstDefined(...values);
  return value === undefined || value === null ? "" : String(value);
}

function normalizeArray(value) {
  if (Array.isArray(value)) return cloneValue(value);
  if (value === undefined || value === null || value === "") return [];
  return [value];
}

function normalizeObject(value) {
  return isPlainObject(value) ? cloneValue(value) : {};
}


function stripAutomationPlaceholderHtml(value) {
  let html = String(value ?? "");

  const placeholderPatterns = [
    /<hr\s*\/?>\s*<p>\s*<em>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/em>\s*<\/p>/gi,
    /<p>\s*<em>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/em>\s*<\/p>/gi,
    /<hr\s*\/?>\s*<p>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/p>/gi,
    /<p>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/p>/gi,
    /<hr\s*\/?>\s*<em>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/em>/gi,
    /<em>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/em>/gi,
    /Efeitos autom[aá]ticos ainda n[aã]o configurados\.?/gi
  ];

  for (const pattern of placeholderPatterns) {
    html = html.replace(pattern, "");
  }

  return html.trim();
}

function getHtmlElement(html) {
  if (html?.jquery) return html[0];
  if (Array.isArray(html)) return html[0];
  return html;
}

function bindClick(html, selector, handler) {
  if (html?.find) {
    html.find(selector).off("click.gotBeautifulSheet").on("click.gotBeautifulSheet", handler);
  }

  const root = getHtmlElement(html);
  if (!root?.querySelectorAll) return;

  root.querySelectorAll(selector).forEach((element) => {
    element.removeEventListener("click", handler);
    element.addEventListener("click", handler);
  });
}

function getSheetClass(item) {
  return String(
    getFlagValue(item, "core", "sheetClass")
    ?? item?.flags?.core?.sheetClass
    ?? item?._source?.flags?.core?.sheetClass
    ?? ""
  );
}

function getTraitType(item) {
  const sourceSystem = getSourceSystem(item);
  const props = sourceSystem.props ?? {};

  return String(
    getFlagValue(item, MODULE_ID, "traitType")
    ?? item?.flags?.[MODULE_ID]?.traitType
    ?? item?._source?.flags?.[MODULE_ID]?.traitType
    ?? props.traitType
    ?? props.flags?.traitType
    ?? sourceSystem.flags?.traitType
    ?? sourceSystem.traitType
    ?? item?.system?.props?.traitType
    ?? item?.system?.props?.flags?.traitType
    ?? item?.system?.flags?.traitType
    ?? item?.system?.traitType
    ?? item?.system?.kind
    ?? item?.type
    ?? ""
  );
}

export function isQualityItem(item) {
  if (item?.documentName !== "Item") return false;

  const traitType = getTraitType(item);
  return ["quality", "got-beautiful-sheet.quality"].includes(traitType)
    || getSheetClass(item) === `${MODULE_ID}.QualityItemSheet` && item?.type === "equippableItem";
}

export function isDefectItem(item) {
  return item?.documentName === "Item" && ["defect", "got-beautiful-sheet.defect"].includes(getTraitType(item));
}

export function isTraitItem(item) {
  return isQualityItem(item) || isDefectItem(item);
}

export function getTraitSystemView(itemOrSystem = {}) {
  const sourceSystem = getSourceSystem(itemOrSystem);
  const runtimeSystem = itemOrSystem?.system ?? {};
  const props = sourceSystem.props ?? runtimeSystem.props ?? {};
  const sourceFlags = normalizeObject(sourceSystem.flags);
  const propFlags = normalizeObject(props.flags);
  const flags = foundry.utils.mergeObject(propFlags, sourceFlags, {
    inplace: false,
    insertKeys: true,
    insertValues: true,
    overwrite: true
  });

  const systemView = {
    description: firstText(sourceSystem.description, runtimeSystem.description, props.description, flags.description),
    category: firstText(sourceSystem.category, runtimeSystem.category, props.category, flags.category),
    prerequisite: firstText(sourceSystem.prerequisite, runtimeSystem.prerequisite, props.prerequisite, flags.prerequisite),
    effects: normalizeArray(firstDefined(sourceSystem.effects, runtimeSystem.effects, props.effects)),
    flags,
    notes: normalizeArray(firstDefined(sourceSystem.notes, runtimeSystem.notes, props.notes)),
    configs: normalizeArray(firstDefined(sourceSystem.configs, runtimeSystem.configs, props.configs)),
    configValues: normalizeObject(firstDefined(sourceSystem.configValues, runtimeSystem.configValues, props.configValues)),
    automationVersion: firstText(sourceSystem.automationVersion, runtimeSystem.automationVersion, props.automationVersion)
  };

  return foundry.utils.mergeObject(cloneValue(DEFAULT_TRAIT_SYSTEM), systemView, {
    inplace: false,
    insertKeys: true,
    insertValues: true,
    overwrite: true
  });
}

export function getDefaultQualitySystem(system = {}) {
  return getTraitSystemView(system);
}

function getEquippableTraitUpdateData(item, formData) {
  if (item?.type !== "equippableItem") return formData;

  const updateData = foundry.utils.expandObject(formData);
  const system = updateData.system ?? {};
  const props = system.props ?? {};

  for (const key of ["category", "prerequisite", "description"]) {
    if (system[key] !== undefined) {
      props[key] = system[key];
    }
  }

  if (system.effects !== undefined) props.effects = system.effects;
  if (system.flags !== undefined) props.flags = system.flags;
  if (system.notes !== undefined) props.notes = system.notes;

  props.traitType = getTraitType(item) || getFlagValue(item, MODULE_ID, "traitType") || "quality";
  system.props = props;
  updateData.system = system;

  return foundry.utils.flattenObject(updateData);
}

export class QualityItemSheet extends ItemSheet {
  constructor(item, options = {}) {
    super(item, options);

    this.editingDescription = false;
    this._boundToggleDescriptionEdit = this._onToggleDescriptionEdit.bind(this);
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["got-beautiful-sheet", "got-quality-item-sheet"],
      template: "modules/got-beautiful-sheet/templates/quality-item-sheet.hbs",
      width: 600,
      height: 560,
      resizable: true
    });
  }

  get title() {
    const typeLabel = isDefectItem(this.item) ? "Defeito" : "Qualidade";
    return `${typeLabel}: ${this.item?.name ?? ""}`;
  }

  getData(options = {}) {
    const context = super.getData(options);

    context.system = getTraitSystemView(this.item);
    context.system.description = stripAutomationPlaceholderHtml(context.system.description);
    context.renderedDescription = context.system.description;
    context.descriptionForEdit = context.system.description;
    context.editingDescription = this.editingDescription;

    return context;
  }

  activateListeners(html) {
    super.activateListeners(html);

    bindClick(html, "[data-action='toggle-description-edit']", this._boundToggleDescriptionEdit);
  }

  async _onToggleDescriptionEdit(event) {
    event.preventDefault();
    event.stopPropagation();

    this.editingDescription = !this.editingDescription;
    this.render(false);
  }

  async _updateObject(event, formData) {
    if (formData["system.description"] !== undefined) {
      formData["system.description"] = stripAutomationPlaceholderHtml(formData["system.description"]);
    }

    const updateData = getEquippableTraitUpdateData(this.object, formData);

    await this.object.update(updateData);

    this.editingDescription = false;
  }
}
