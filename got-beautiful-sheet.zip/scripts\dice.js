import { getTraitAutomationByName } from "./data/trait-automation-data.js";
const MODULE_ID = "got-beautiful-sheet";
const CHARACTER_FLAG = "characterData";

function toNumber(value, fallback = 0) {
  const number = Number.parseInt(value, 10);
  return Number.isFinite(number) ? number : fallback;
}

function cloneData(value) {
  if (globalThis.foundry?.utils?.deepClone) {
    return foundry.utils.deepClone(value);
  }

  return JSON.parse(JSON.stringify(value ?? null));
}

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function repairMojibake(value) {
  return String(value ?? "")
    .replace(/\u00C3\u0192\u00C2\u0081/g, "Á")
    .replace(/\u00C3\u0192\u00C2\u00A1/g, "á")
    .replace(/\u00C3\u0192\u00C2\u0089/g, "É")
    .replace(/\u00C3\u0192\u00C2\u2030/g, "É")
    .replace(/\u00C3\u0192\u00C2\u00A9/g, "é")
    .replace(/\u00C3\u0192\u00C2\u008D/g, "Í")
    .replace(/\u00C3\u0192\u00C2\u00AD/g, "í")
    .replace(/\u00C3\u0192\u00C2\u0093/g, "Ó")
    .replace(/\u00C3\u0192\u00C2\u201C/g, "Ó")
    .replace(/\u00C3\u0192\u00C2\u00B3/g, "ó")
    .replace(/\u00C3\u0192\u00C2\u009A/g, "Ú")
    .replace(/\u00C3\u0192\u00C2\u0161/g, "Ú")
    .replace(/\u00C3\u0192\u00C2\u00BA/g, "ú")
    .replace(/\u00C3\u0192\u00C2\u0087/g, "Ç")
    .replace(/\u00C3\u0192\u00C2\u2021/g, "Ç")
    .replace(/\u00C3\u0192\u00C2\u00A7/g, "ç")
    .replace(/\u00C3\u0192\u00C2\u00A3/g, "ã")
    .replace(/\u00C3\u0192\u00C2\u00B5/g, "õ")
    .replace(/\u00C3\u0192\u00C2\u00A2/g, "â")
    .replace(/\u00C3\u0192\u00C2\u00AA/g, "ê")
    .replace(/\u00C3\u0192\u00C2\u00B4/g, "ô")
    .replace(/\u00C3\u0192\u00C2\u0082/g, "Â")
    .replace(/\u00C3\u0192\u00C2\u201A/g, "Â")
    .replace(/\u00C3\u0192\u00C2\u00A0/g, "à")
    .replace(/\u00C3\u0081/g, "Á")
    .replace(/\u00C3\u00A1/g, "á")
    .replace(/\u00C3\u0089/g, "É")
    .replace(/\u00C3\u2030/g, "É")
    .replace(/\u00C3\u00A9/g, "é")
    .replace(/\u00C3\u008D/g, "Í")
    .replace(/\u00C3\u00AD/g, "í")
    .replace(/\u00C3\u0093/g, "Ó")
    .replace(/\u00C3\u201C/g, "Ó")
    .replace(/\u00C3\u00B3/g, "ó")
    .replace(/\u00C3\u009A/g, "Ú")
    .replace(/\u00C3\u0161/g, "Ú")
    .replace(/\u00C3\u00BA/g, "ú")
    .replace(/\u00C3\u0087/g, "Ç")
    .replace(/\u00C3\u2021/g, "Ç")
    .replace(/\u00C3\u00A7/g, "ç")
    .replace(/\u00C3\u00A3/g, "ã")
    .replace(/\u00C3\u00B5/g, "õ")
    .replace(/\u00C3\u00A2/g, "â")
    .replace(/\u00C3\u00AA/g, "ê")
    .replace(/\u00C3\u00B4/g, "ô")
    .replace(/\u00C3\u0082/g, "Â")
    .replace(/\u00C3\u201A/g, "Â")
    .replace(/\u00C3\u00A0/g, "à");
}

function normalizeKey(value) {
  return repairMojibake(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[\u0000-\u001f\u007f-\u009f]/g, "")
    .replace(/[^a-zA-Z0-9\s*.]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function formatSigned(value, suffix = "") {
  const numericValue = toNumber(value, 0);
  const sign = numericValue >= 0 ? "+" : "";

  return `${sign}${numericValue}${suffix}`;
}

function getPersistentActor(document) {
  if (!document) return null;

  if (document.documentName === "Actor") {
    if (!document.isToken) return document;

    return document.token?.baseActor ?? game.actors?.get(document.id) ?? document;
  }

  if (document.documentName === "Item" && document.parent?.documentName === "Actor") {
    const actor = document.parent;

    if (!actor.isToken) return actor;

    return actor.token?.baseActor ?? game.actors?.get(actor.id) ?? actor;
  }

  return null;
}

function getSpeakerFromDocument(document) {
  if (!document) return ChatMessage.getSpeaker();

  const actor = getPersistentActor(document);

  if (actor) {
    return ChatMessage.getSpeaker({ actor });
  }

  return {
    alias: document.name ?? "Rolagem"
  };
}

function getCharacterDataFromDocument(document) {
  const actor = getPersistentActor(document);

  if (!actor) return {};

  return actor.getFlag(MODULE_ID, CHARACTER_FLAG) ?? {};
}

function getStoredTraitsFromDocument(document) {
  const data = getCharacterDataFromDocument(document);
  const qualities = Array.isArray(data?.traits?.qualities) ? data.traits.qualities : [];
  const defects = Array.isArray(data?.traits?.defects) ? data.traits.defects : [];

  return [
    ...qualities.map((trait) => ({
      ...trait,
      traitKind: "quality"
    })),
    ...defects.map((trait) => ({
      ...trait,
      traitKind: "defect"
    }))
  ];
}

function getTraitConfigValue(configValues, key) {
  if (!key || !configValues || typeof configValues !== "object") return "";

  return configValues[key] ?? "";
}

function resolveEffectForTraitConfig(effect, configValues = {}) {
  const nextEffect = cloneData(effect);

  if (nextEffect.targetFromConfig) {
    const value = getTraitConfigValue(configValues, nextEffect.targetFromConfig);

    if (value) nextEffect.target = value;

    delete nextEffect.targetFromConfig;
  }

  if (nextEffect.target && typeof nextEffect.target === "object") {
    if (nextEffect.target.abilityFromConfig) {
      const value = getTraitConfigValue(configValues, nextEffect.target.abilityFromConfig);

      if (value) nextEffect.target.ability = value;

      delete nextEffect.target.abilityFromConfig;
    }

    if (nextEffect.target.specializationFromConfig) {
      const value = getTraitConfigValue(configValues, nextEffect.target.specializationFromConfig);

      if (value) nextEffect.target.specialization = value;

      delete nextEffect.target.specializationFromConfig;
    }
  }

  if (nextEffect.valueFromAbilityFromConfig) {
    const value = getTraitConfigValue(configValues, nextEffect.valueFromAbilityFromConfig);

    if (value) nextEffect.valueFromAbility = value;

    delete nextEffect.valueFromAbilityFromConfig;
  }

  return nextEffect;
}

function shouldSkipLegacyTraitEffect(trait, effect) {
  const traitName = normalizeKey(trait?.name);
  const effectId = String(effect?.id ?? "");

  if (traitName === "sangue dos andalos" && effectId === "sangue-andalos-habilidade-escolhida-reroll-1") {
    return true;
  }

  return false;
}

function getTraitEffects(document) {
  const traits = getStoredTraitsFromDocument(document);
  const effects = [];

  for (const trait of traits) {
    const savedEffects = Array.isArray(trait.effects) ? trait.effects : [];
    const automation = getTraitAutomationByName(trait?.name);
    const automationEffects = Array.isArray(automation?.effects) ? automation.effects : [];
    const configValues = trait.configValues ?? {};

    const seenEffectKeys = new Set();
    const combinedEffects = [];

    const addEffect = (effect) => {
      if (!effect || typeof effect !== "object") return;
      if (shouldSkipLegacyTraitEffect(trait, effect)) return;

      const resolvedEffect = resolveEffectForTraitConfig(effect, configValues);
      const effectKey = resolvedEffect.id
        ? `id:${resolvedEffect.id}`
        : `raw:${JSON.stringify({
          type: resolvedEffect.type ?? resolvedEffect.kind ?? "",
          target: resolvedEffect.target ?? resolvedEffect.targetFromConfig ?? "",
          face: resolvedEffect.face ?? "",
          value: resolvedEffect.value ?? resolvedEffect.modifier ?? resolvedEffect.amount ?? "",
          prompt: resolvedEffect.prompt?.question ?? ""
        })}`;

      if (seenEffectKeys.has(effectKey)) return;

      seenEffectKeys.add(effectKey);
      combinedEffects.push(resolvedEffect);
    };

    for (const effect of savedEffects) addEffect(effect);
    for (const effect of automationEffects) addEffect(effect);

    for (const effect of combinedEffects) {
      if (!effect || typeof effect !== "object") continue;
      if (effect.enabled === false || effect.disabled === true) continue;

      effects.push({
        ...effect,
        sourceName: trait.name ?? "Característica",
        sourceKind: trait.traitKind ?? "trait"
      });
    }
  }

  return effects;
}

function parseRollLabel(label) {
  const text = String(label ?? "").trim();
  const [abilityRaw, ...specializationParts] = text.split(":");

  return {
    ability: abilityRaw.trim(),
    specialization: specializationParts.join(":").trim()
  };
}

function getEffectType(effect) {
  return normalizeKey(effect.type ?? effect.kind ?? "");
}

function getEffectMode(effect) {
  return normalizeKey(effect.mode ?? effect.operation ?? "");
}

function getEffectTargetAbility(effect) {
  if (typeof effect.target === "string") return effect.target;

  if (effect.target && typeof effect.target === "object") {
    return effect.target.ability ?? effect.target.skill ?? effect.target.habilidade ?? "";
  }

  return effect.ability ?? effect.skill ?? effect.habilidade ?? effect.targetAbility ?? "";
}

function getEffectTargetSpecialization(effect) {
  if (effect.target && typeof effect.target === "object") {
    return effect.target.specialization ?? effect.target.specialty ?? effect.target.especializacao ?? "";
  }

  return effect.specialization ?? effect.specialty ?? effect.especializacao ?? effect.targetSpecialization ?? "";
}

function isGlobalTarget(value) {
  const normalized = normalizeKey(value);

  return ["*", "all", "todas", "todos", "qualquer", "global"].includes(normalized);
}

function matchesRollTarget(effect, label) {
  const parsedLabel = parseRollLabel(label);
  const rollAbility = normalizeKey(parsedLabel.ability);
  const rollSpecialization = normalizeKey(parsedLabel.specialization);

  const targetAbilityRaw = getEffectTargetAbility(effect);
  const targetSpecializationRaw = getEffectTargetSpecialization(effect);

  const targetAbility = normalizeKey(targetAbilityRaw);
  const targetSpecialization = normalizeKey(targetSpecializationRaw);

  if (!targetAbility && !effect.global && !effect.always) {
    return false;
  }

  if (targetAbility && !isGlobalTarget(targetAbility) && targetAbility !== rollAbility) {
    return false;
  }

  if (targetSpecialization && !isGlobalTarget(targetSpecialization) && targetSpecialization !== rollSpecialization) {
    return false;
  }

  return true;
}

function isRankModifierEffect(effect) {
  const type = getEffectType(effect);
  const mode = getEffectMode(effect);

  return type === "roll.rank"
    || type === "rollrank"
    || type === "rank"
    || type === "rankmodifier"
    || type === "abilityrankmodifier"
    || type === "dicerankmodifier"
    || (type === "rollmodifier" && mode === "rank")
    || (type === "roll.modifier" && mode === "rank");
}

function isBonusDiceModifierEffect(effect) {
  const type = getEffectType(effect);
  const mode = getEffectMode(effect);

  return type === "roll.bonus"
    || type === "rollbonus"
    || type === "bonus"
    || type === "bonusdice"
    || type === "bonusdicemodifier"
    || type === "abilitybonusmodifier"
    || (type === "rollmodifier" && mode === "bonus")
    || (type === "roll.modifier" && mode === "bonus");
}

function isResultModifierEffect(effect) {
  const type = getEffectType(effect);
  const mode = getEffectMode(effect);

  return type === "roll.result"
    || type === "rollresult"
    || type === "result"
    || type === "resultmodifier"
    || type === "totalmodifier"
    || type === "roll.total"
    || (type === "rollmodifier" && mode === "result")
    || (type === "roll.modifier" && mode === "result");
}

function isRerollFaceEffect(effect) {
  const type = getEffectType(effect);
  const mode = getEffectMode(effect);

  return type === "roll.rerollface"
    || type === "rollrerollface"
    || type === "rerollface"
    || type === "rerollvalue"
    || type === "rerollsix"
    || type === "reroll6"
    || (type === "rollmodifier" && mode === "reroll")
    || (type === "roll.modifier" && mode === "reroll");
}

function isRerollAnyDieEffect(effect) {
  const type = getEffectType(effect);
  const mode = getEffectMode(effect);

  return type === "roll.rerollanydie"
    || type === "rollrerollanydie"
    || type === "rerollanydie"
    || type === "rerollone"
    || type === "rerollonedie"
    || type === "roll.rerollone"
    || type === "rollrerollone"
    || (type === "rollmodifier" && mode === "rerollanydie")
    || (type === "roll.modifier" && mode === "rerollanydie");
}

function isConvertBonusToRankEffect(effect) {
  const type = getEffectType(effect);
  const mode = getEffectMode(effect);

  return type === "roll.convertbonustorank"
    || type === "rollconvertbonustorank"
    || type === "convertbonustorank"
    || type === "bonus2rank"
    || type === "bonus-to-rank"
    || (type === "rollmodifier" && mode === "convertbonustorank")
    || (type === "roll.modifier" && mode === "convertbonustorank");
}

function getAbilityFromDocument(document, abilityName) {
  const data = getCharacterDataFromDocument(document);
  const wantedAbility = normalizeKey(abilityName);

  return (data.abilities ?? []).find((item) => {
    return normalizeKey(item?.name) === wantedAbility || normalizeKey(item?.id) === wantedAbility;
  }) ?? null;
}

function getAbilityRankFromDocument(document, abilityName) {
  const ability = getAbilityFromDocument(document, abilityName);

  return toNumber(ability?.rank, 0);
}

function getSpecializationBonusFromDocument(document, abilityName, specializationName) {
  const ability = getAbilityFromDocument(document, abilityName);
  const wantedSpecialization = normalizeKey(specializationName);

  if (!ability || !wantedSpecialization || !Array.isArray(ability.specializations)) {
    return 0;
  }

  const specialization = ability.specializations.find((item) => {
    return normalizeKey(item?.name) === wantedSpecialization;
  });

  return toNumber(specialization?.bonus, 0);
}

function getEffectValue(effect, document = null, fallback = 0) {
  if (effect.valueFromAbility) {
    const abilityRank = getAbilityRankFromDocument(document, effect.valueFromAbility);
    const multiplier = Number(effect.multiplier ?? 1);

    return Math.trunc(abilityRank * multiplier);
  }

  if (effect.valueFromSpecializationBonus && typeof effect.valueFromSpecializationBonus === "object") {
    const specializationBonus = getSpecializationBonusFromDocument(
      document,
      effect.valueFromSpecializationBonus.ability,
      effect.valueFromSpecializationBonus.specialization
    );
    const multiplier = Number(effect.multiplier ?? effect.valueFromSpecializationBonus.multiplier ?? 1);

    return Math.trunc(specializationBonus * multiplier);
  }

  return toNumber(effect.value ?? effect.modifier ?? effect.amount ?? effect.bonus ?? effect.penalty, fallback);
}

function getRerollFace(effect) {
  return toNumber(effect.face ?? effect.rerollValue ?? effect.value ?? 6, 6);
}

function getRerollLimit(effect, { document = null, baseBonusDice = 0 } = {}) {
  const minimum = Math.max(0, toNumber(effect.minimum ?? effect.min ?? 0, 0));

  let limit = Number.POSITIVE_INFINITY;

  if (effect.limit === "all" || effect.limit === undefined || effect.limit === null || effect.limit === "") {
    limit = Number.POSITIVE_INFINITY;
  } else {
    limit = toNumber(effect.limit, Number.POSITIVE_INFINITY);
  }

  if (effect.limitFromAbility) {
    limit = getAbilityRankFromDocument(document, effect.limitFromAbility);
  }

  if (effect.limitFromAbilityHalf) {
    limit = Math.floor(getAbilityRankFromDocument(document, effect.limitFromAbilityHalf) / 2);
  }

  if (effect.limitFromBonusDice || effect.limitFromSpecializationBonus === "current") {
    limit = Math.max(0, toNumber(baseBonusDice, 0));
  }

  if (effect.limitFromSpecializationBonus && typeof effect.limitFromSpecializationBonus === "object") {
    limit = getSpecializationBonusFromDocument(
      document,
      effect.limitFromSpecializationBonus.ability,
      effect.limitFromSpecializationBonus.specialization
    );
  }

  if (!Number.isFinite(limit)) {
    return Number.POSITIVE_INFINITY;
  }

  return Math.max(minimum, Math.max(0, Math.trunc(limit)));
}


function getConvertedBonusDice(effect, availableBonusDice) {
  const available = Math.max(0, toNumber(availableBonusDice, 0));
  const amount = effect.amount ?? effect.value ?? "all";

  if (available <= 0) return 0;

  let converted = 0;

  if (amount === "all") {
    converted = available;
  } else if (amount === "half") {
    const rawHalf = available / 2;
    const rounding = normalizeKey(effect.rounding ?? "floor");

    if (rounding === "ceil" || rounding === "up") {
      converted = Math.ceil(rawHalf);
    } else if (rounding === "round") {
      converted = Math.round(rawHalf);
    } else {
      converted = Math.floor(rawHalf);
    }
  } else {
    converted = toNumber(amount, 0);
  }

  if (effect.minimum !== undefined && available > 0) {
    converted = Math.max(converted, toNumber(effect.minimum, 0));
  }

  if (effect.maximum !== undefined) {
    converted = Math.min(converted, toNumber(effect.maximum, converted));
  }

  return Math.max(0, Math.min(available, converted));
}

function getEffectOwnText(effect, fallbackText) {
  return effect.label || effect.text || effect.description || fallbackText;
}

function buildAppliedEffectLabel(effect, text) {
  const sourceName = effect.sourceName ?? "Característica";
  const ownText = getEffectOwnText(effect, text);

  return `${sourceName}: ${ownText}`;
}

async function confirmPromptEffect(effect) {
  if (!effect.prompt || typeof effect.prompt !== "object") {
    return true;
  }

  const title = effect.prompt.title ?? effect.sourceName ?? "Efeito situacional";
  const question = effect.prompt.question ?? "Aplicar este efeito situacional?";
  const yesLabel = effect.prompt.yesLabel ?? "Aplicar";
  const noLabel = effect.prompt.noLabel ?? "Ignorar";

  return new Promise((resolve) => {
    let resolved = false;

    new Dialog({
      title,
      content: `
        <section class="got-roll-card">
          <header class="got-roll-header">
            <h2>${escapeHTML(title)}</h2>
          </header>

          <p>${escapeHTML(question)}</p>

          ${effect.label ? `<p><strong>Efeito:</strong> ${escapeHTML(effect.label)}</p>` : ""}
        </section>
      `,
      buttons: {
        yes: {
          label: yesLabel,
          callback: () => {
            resolved = true;
            resolve(true);
          }
        },
        no: {
          label: noLabel,
          callback: () => {
            resolved = true;
            resolve(false);
          }
        }
      },
      default: "no",
      close: () => {
        if (!resolved) resolve(false);
      }
    }, {
      width: 480
    }).render(true);
  });
}

async function getAppliedRollEffects({ document, label, baseBonusDice = 0 }) {
  const effects = getTraitEffects(document);
  const applied = [];
  const rerollEffects = [];

  let rankModifier = 0;
  let bonusDiceModifier = 0;
  let resultModifier = 0;
  let convertedBonusDice = 0;

  for (const effect of effects) {
    if (!matchesRollTarget(effect, label)) continue;

    if (isRerollAnyDieEffect(effect)) {
      rerollEffects.push({
        sourceName: effect.sourceName,
        anyDie: true,
        limit: Math.max(1, toNumber(effect.limit ?? effect.value ?? 1, 1)),
        prompt: effect.prompt ?? null,
        label: buildAppliedEffectLabel(effect, "rerrola um dado escolhido")
      });

      continue;
    }

    const shouldApply = await confirmPromptEffect(effect);

    if (!shouldApply) continue;

    if (isRankModifierEffect(effect)) {
      const value = getEffectValue(effect, document, 0);

      if (value === 0) continue;

      rankModifier += value;

      applied.push({
        sourceName: effect.sourceName,
        type: "rank",
        value,
        label: buildAppliedEffectLabel(effect, `${formatSigned(value, "D")} em ${getEffectTargetAbility(effect) || "rolagens"}`)
      });

      continue;
    }

    if (isBonusDiceModifierEffect(effect)) {
      const value = getEffectValue(effect, document, 0);

      if (value === 0) continue;

      bonusDiceModifier += value;

      applied.push({
        sourceName: effect.sourceName,
        type: "bonus",
        value,
        label: buildAppliedEffectLabel(effect, `${formatSigned(value, "B")} em ${getEffectTargetAbility(effect) || "rolagens"}`)
      });

      continue;
    }

    if (isResultModifierEffect(effect)) {
      const value = getEffectValue(effect, document, 0);

      if (value === 0) continue;

      resultModifier += value;

      applied.push({
        sourceName: effect.sourceName,
        type: "result",
        value,
        label: buildAppliedEffectLabel(effect, `${formatSigned(value)} no resultado`)
      });

      continue;
    }

    if (isRerollFaceEffect(effect)) {
      const face = getRerollFace(effect);
      const limit = getRerollLimit(effect, {
        document,
        baseBonusDice
      });
      const limitText = Number.isFinite(limit) ? ` até ${limit}` : "";

      rerollEffects.push({
        sourceName: effect.sourceName,
        face,
        limit,
        once: effect.once !== false,
        label: buildAppliedEffectLabel(effect, `rerrola${limitText} resultado(s) ${face}`)
      });

      applied.push({
        sourceName: effect.sourceName,
        type: "reroll",
        face,
        limit,
        label: buildAppliedEffectLabel(effect, `rerrola${limitText} resultado(s) ${face}`)
      });

      continue;
    }

    if (isConvertBonusToRankEffect(effect)) {
      const availableBonusDice = Math.max(0, baseBonusDice + bonusDiceModifier - convertedBonusDice);
      const converted = getConvertedBonusDice(effect, availableBonusDice);

      if (converted <= 0) continue;

      convertedBonusDice += converted;
      rankModifier += converted;
      bonusDiceModifier -= converted;

      applied.push({
        sourceName: effect.sourceName,
        type: "convertBonusToRank",
        value: converted,
        label: buildAppliedEffectLabel(effect, `converteu ${converted}B em ${converted}D`)
      });
    }
  }

  return {
    rankModifier,
    bonusDiceModifier,
    resultModifier,
    rerollEffects,
    applied
  };
}

async function rollSingleD6() {
  const roll = new Roll("1d6");
  await roll.evaluate({ async: true });

  const result = roll.dice?.[0]?.results?.[0]?.result ?? 1;

  return {
    roll,
    result
  };
}

async function promptRerollAnyDie(diceResults, effect) {
  if (!Array.isArray(diceResults) || diceResults.length <= 0) return null;

  const title = effect.prompt?.title ?? effect.sourceName ?? "Rerrolagem";
  const question = effect.prompt?.question ?? "Escolha um dado para rerrolar. O novo resultado deve ser aceito.";
  const yesLabel = effect.prompt?.yesLabel ?? "Rerrolar";
  const noLabel = effect.prompt?.noLabel ?? "Ignorar";
  const options = diceResults
    .map((value, index) => `<option value="${index}">Dado ${index + 1}: ${value}</option>`)
    .join("");

  return new Promise((resolve) => {
    let resolved = false;

    new Dialog({
      title,
      content: `
        <section class="got-roll-card">
          <header class="got-roll-header">
            <h2>${escapeHTML(title)}</h2>
          </header>

          <p>${escapeHTML(question)}</p>

          ${effect.label ? `<p><strong>Efeito:</strong> ${escapeHTML(effect.label)}</p>` : ""}

          <div class="form-group">
            <label>Dado</label>
            <select name="dieIndex">${options}</select>
          </div>
        </section>
      `,
      buttons: {
        yes: {
          label: yesLabel,
          callback: (html) => {
            resolved = true;
            const selectedIndex = Number(html.find("[name='dieIndex']").val());
            resolve(Number.isInteger(selectedIndex) ? selectedIndex : null);
          }
        },
        no: {
          label: noLabel,
          callback: () => {
            resolved = true;
            resolve(null);
          }
        }
      },
      default: "no",
      close: () => {
        if (!resolved) resolve(null);
      }
    }, {
      width: 480
    }).render(true);
  });
}

async function applyRerollEffects(diceResults, rerollEffects) {
  const finalResults = [...diceResults];
  const rerollDetails = [];
  const extraRolls = [];

  for (const effect of rerollEffects) {
    if (effect.anyDie) {
      const limit = Number.isFinite(effect.limit) ? Math.max(1, toNumber(effect.limit, 1)) : 1;

      for (let rerolledCount = 0; rerolledCount < limit; rerolledCount += 1) {
        const index = await promptRerollAnyDie(finalResults, effect);

        if (index === null || index === undefined) break;
        if (index < 0 || index >= finalResults.length) break;

        const reroll = await rollSingleD6();

        extraRolls.push(reroll.roll);

        rerollDetails.push({
          index,
          oldValue: finalResults[index],
          newValue: reroll.result,
          sourceName: effect.sourceName ?? "Característica"
        });

        finalResults[index] = reroll.result;
      }

      continue;
    }

    const face = toNumber(effect.face, 6);
    const limit = Number.isFinite(effect.limit) ? Math.max(0, toNumber(effect.limit, 0)) : Number.POSITIVE_INFINITY;
    let rerolledCount = 0;

    if (limit <= 0) continue;

    for (let index = 0; index < finalResults.length; index += 1) {
      if (rerolledCount >= limit) break;
      if (finalResults[index] !== face) continue;

      const reroll = await rollSingleD6();

      extraRolls.push(reroll.roll);

      rerollDetails.push({
        index,
        oldValue: finalResults[index],
        newValue: reroll.result,
        sourceName: effect.sourceName ?? "Característica"
      });

      finalResults[index] = reroll.result;
      rerolledCount += 1;
    }
  }

  return {
    diceResults: finalResults,
    rerollDetails,
    extraRolls
  };
}

function buildDiceResultHtml({
  label,
  rank,
  bonusDice,
  baseRank,
  baseBonusDice,
  diceResults,
  keptResults,
  keptIndexes,
  totalBeforeResultModifiers,
  resultModifier,
  total,
  flavor,
  appliedEffects = [],
  rerollDetails = []
}) {
  const diceList = diceResults.length > 0
    ? diceResults
      .map((die, index) => {
        const kept = keptIndexes.has(index);
        const reroll = rerollDetails.find((detail) => detail.index === index);
        const title = reroll
          ? `Rerolado por ${escapeHTML(reroll.sourceName)}: ${reroll.oldValue} → ${reroll.newValue}`
          : "";

        return `<span class="got-die ${kept ? "kept" : "dropped"}" title="${title}">${die}</span>`;
      })
      .join("")
    : `<span class="got-roll-no-dice">Nenhum dado rolado.</span>`;

  const changedDicePool = rank !== baseRank || bonusDice !== baseBonusDice;
  const changedTotal = resultModifier !== 0;

  const effectsHtml = appliedEffects.length > 0
    ? `
      <div class="got-roll-effects">
        <strong>Modificadores:</strong>
        <ul>
          ${appliedEffects.map((effect) => `<li>${escapeHTML(effect.label)}</li>`).join("")}
        </ul>
      </div>
    `
    : "";

  const rerollHtml = rerollDetails.length > 0
    ? `
      <div class="got-roll-effects">
        <strong>Rerolagens:</strong>
        <ul>
          ${rerollDetails.map((detail) => `
            <li>${escapeHTML(detail.sourceName)}: ${detail.oldValue} → ${detail.newValue}</li>
          `).join("")}
        </ul>
      </div>
    `
    : "";

  const resultModifierHtml = changedTotal
    ? `
      <div class="got-roll-effects">
        <strong>Total antes do modificador:</strong> ${totalBeforeResultModifiers}<br>
        <strong>Modificador no resultado:</strong> ${formatSigned(resultModifier)}
      </div>
    `
    : "";

  const keptText = keptResults.length > 0 ? escapeHTML(keptResults.join(", ")) : "Nenhum";

  return `
    <div class="got-roll-card">
      <header class="got-roll-header">
        <h2>${escapeHTML(label)}</h2>
        <span>
          ${rank}D + ${bonusDice}B
          ${changedDicePool ? `<small>(base ${baseRank}D + ${baseBonusDice}B)</small>` : ""}
        </span>
      </header>

      ${flavor ? `<p class="got-roll-flavor">${escapeHTML(flavor)}</p>` : ""}

      ${effectsHtml}

      <div class="got-roll-dice">
        ${diceList}
      </div>

      ${rerollHtml}

      ${resultModifierHtml}

      <div class="got-roll-summary">
        <span>Mantidos: ${keptText}</span>
        <strong>Total: ${total}</strong>
      </div>
    </div>
  `;
}

export async function rollKeepHighest({
  document = null,
  label = "Rolagem",
  rank = 2,
  bonusDice = 0,
  flavor = ""
} = {}) {
  const baseRank = Math.max(1, toNumber(rank, 2));
  const baseBonus = Math.max(0, toNumber(bonusDice, 0));

  const rollEffects = await getAppliedRollEffects({
    document,
    label,
    baseBonusDice: baseBonus
  });

  const safeRank = Math.max(1, baseRank + rollEffects.rankModifier);
  const safeBonus = Math.max(0, baseBonus + rollEffects.bonusDiceModifier);
  const totalDice = safeRank + safeBonus;

  const roll = new Roll(`${totalDice}d6`);
  await roll.evaluate({ async: true });

  const rawDiceResults = roll.dice?.[0]?.results?.map((result) => result.result) ?? [];

  const rerolled = await applyRerollEffects(rawDiceResults, rollEffects.rerollEffects);
  const diceResults = rerolled.diceResults;

  const sorted = diceResults
    .map((value, index) => ({ value, index }))
    .sort((a, b) => b.value - a.value || a.index - b.index);

  const keptDice = sorted.slice(0, safeRank);
  const keptIndexes = new Set(keptDice.map((die) => die.index));
  const keptResults = keptDice.map((die) => die.value);
  const totalBeforeResultModifiers = keptResults.reduce((sum, value) => sum + value, 0);
  const total = totalBeforeResultModifiers + rollEffects.resultModifier;

  const content = buildDiceResultHtml({
    label,
    rank: safeRank,
    bonusDice: safeBonus,
    baseRank,
    baseBonusDice: baseBonus,
    diceResults,
    keptResults,
    keptIndexes,
    totalBeforeResultModifiers,
    resultModifier: rollEffects.resultModifier,
    total,
    flavor,
    appliedEffects: rollEffects.applied,
    rerollDetails: rerolled.rerollDetails
  });

  await ChatMessage.create({
    speaker: getSpeakerFromDocument(document),
    flavor: escapeHTML(label),
    content,
    rolls: [
      roll,
      ...rerolled.extraRolls
    ]
  });

  return {
    rank: safeRank,
    bonusDice: safeBonus,
    baseRank,
    baseBonusDice: baseBonus,
    totalDice,
    diceResults,
    keptResults,
    totalBeforeResultModifiers,
    resultModifier: rollEffects.resultModifier,
    total,
    appliedEffects: rollEffects.applied,
    rerollDetails: rerolled.rerollDetails
  };
}

export function parseBonusDiceFromText(text) {
  if (!text) return 0;

  const match = String(text).match(/(\d+)\s*B/i);
  if (!match) return 0;

  return toNumber(match[1], 0);
}

export function parseRankAndBonusFromTest(testText) {
  const text = String(testText ?? "").trim();

  const match = text.match(/(\d+)\s*d6\s*\+\s*(\d+)\s*B/i);
  if (match) {
    return {
      rank: toNumber(match[1], 2),
      bonusDice: toNumber(match[2], 0)
    };
  }

  const onlyRank = text.match(/(\d+)\s*d6/i);
  if (onlyRank) {
    return {
      rank: toNumber(onlyRank[1], 2),
      bonusDice: 0
    };
  }

  return {
    rank: 2,
    bonusDice: 0
  };
}

export async function rollFromTestText({
  document = null,
  label = "Rolagem",
  testText = "",
  flavor = ""
} = {}) {
  const parsed = parseRankAndBonusFromTest(testText);

  return rollKeepHighest({
    document,
    label,
    rank: parsed.rank,
    bonusDice: parsed.bonusDice,
    flavor
  });
}
