// Gerado a partir das tabelas enviadas pelo Iu. Não editar manualmente sem regenerar.
export const GOT_WEAPON_COMPENDIUM_SEED_VERSION = "2026-06-24-gear-v1";

export const GOT_WEAPONS = [
  {
    "grupo": "Armas de Contusão",
    "nome": "Bola com Corrente",
    "especialidade": "Armas de Contusão",
    "treinamento": "1B",
    "dano": "Atletismo",
    "qualidades": "Estilhaçadora 1|Poderosa",
    "peso": "4 kg",
    "preco": "40 gp",
    "notas": "",
    "qualidadesLista": [
      "Estilhaçadora 1",
      "Poderosa"
    ],
    "id": "arma-armas-de-contusao-bola-com-corrente"
  },
  {
    "grupo": "Armas de Contusão",
    "nome": "Cajado",
    "especialidade": "Armas de Contusão",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "Duas Mãos|Rápida",
    "peso": "2 kg",
    "preco": "",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Rápida"
    ],
    "id": "arma-armas-de-contusao-cajado"
  },
  {
    "grupo": "Armas de Contusão",
    "nome": "Maça",
    "especialidade": "Armas de Contusão",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "",
    "peso": "5 kg",
    "preco": "50 gp",
    "notas": "",
    "qualidadesLista": [],
    "id": "arma-armas-de-contusao-maca"
  },
  {
    "grupo": "Armas de Contusão",
    "nome": "Mangual",
    "especialidade": "Armas de Contusão",
    "treinamento": "2B",
    "dano": "Atletismo + 3",
    "qualidades": "Duas Mãos|Estilhaçadora 1|Poderosa",
    "peso": "6 kg",
    "preco": "100 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Estilhaçadora 1",
      "Poderosa"
    ],
    "id": "arma-armas-de-contusao-mangual"
  },
  {
    "grupo": "Armas de Contusão",
    "nome": "Mangual com Cravos",
    "especialidade": "Armas de Contusão",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "Cruel|Estilhaçadora 1",
    "peso": "4 kg",
    "preco": "80 gp",
    "notas": "",
    "qualidadesLista": [
      "Cruel",
      "Estilhaçadora 1"
    ],
    "id": "arma-armas-de-contusao-mangual-com-cravos"
  },
  {
    "grupo": "Armas de Contusão",
    "nome": "Marreta",
    "especialidade": "Armas de Contusão",
    "treinamento": "",
    "dano": "Atletismo + 1",
    "qualidades": "Atordoante|Duas Mãos|Estilhaçadora 1|Lenta|Volume 1",
    "peso": "6,5 kg",
    "preco": "80 gp",
    "notas": "",
    "qualidadesLista": [
      "Atordoante",
      "Duas Mãos",
      "Estilhaçadora 1",
      "Lenta",
      "Volume 1"
    ],
    "id": "arma-armas-de-contusao-marreta"
  },
  {
    "grupo": "Armas de Contusão",
    "nome": "Martelo de Guerra",
    "especialidade": "Armas de Contusão",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "Duas Mãos|Estilhaçadora 2|Lenta|Poderosa|Volume 1",
    "peso": "4 kg",
    "preco": "100 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Estilhaçadora 2",
      "Lenta",
      "Poderosa",
      "Volume 1"
    ],
    "id": "arma-armas-de-contusao-martelo-de-guerra"
  },
  {
    "grupo": "Armas de Contusão",
    "nome": "Porrete/Bordão",
    "especialidade": "Armas de Contusão",
    "treinamento": "",
    "dano": "Atletismo - 1",
    "qualidades": "Mão Inábil +1",
    "peso": "1,5 kg",
    "preco": "20 gp",
    "notas": "",
    "qualidadesLista": [
      "Mão Inábil +1"
    ],
    "id": "arma-armas-de-contusao-porrete-bordao"
  },
  {
    "grupo": "Armas de Haste",
    "nome": "Alabarda",
    "especialidade": "Armas de Haste",
    "treinamento": "1B",
    "dano": "Atletismo + 3",
    "qualidades": "Duas Mãos|Poderosa|Volume 1",
    "peso": "5,5 kg",
    "preco": "100 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Poderosa",
      "Volume 1"
    ],
    "id": "arma-armas-de-haste-alabarda"
  },
  {
    "grupo": "Armas de Haste",
    "nome": "Ferramenta de Aldeão",
    "especialidade": "Armas de Haste",
    "treinamento": "",
    "dano": "Atletismo + 2",
    "qualidades": "Duas Mãos|Desajeitada|Frágil",
    "peso": "4,5 kg",
    "preco": "10 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Desajeitada",
      "Frágil"
    ],
    "id": "arma-armas-de-haste-ferramenta-de-aldeao"
  },
  {
    "grupo": "Armas de Haste",
    "nome": "Machado de Haste",
    "especialidade": "Armas de Haste",
    "treinamento": "1B",
    "dano": "Atletismo + 3",
    "qualidades": "Comprida|Desajeitada|Duas Mãos|Poderosa|Volume 1",
    "peso": "4,5 kg",
    "preco": "80 gp",
    "notas": "",
    "qualidadesLista": [
      "Comprida",
      "Desajeitada",
      "Duas Mãos",
      "Poderosa",
      "Volume 1"
    ],
    "id": "arma-armas-de-haste-machado-de-haste"
  },
  {
    "grupo": "Briga",
    "nome": "Chicote",
    "especialidade": "Briga",
    "treinamento": "2B",
    "dano": "Agilidade - 1",
    "qualidades": "Comprida|Enredar",
    "peso": "1 kg",
    "preco": "5 gp",
    "notas": "",
    "qualidadesLista": [
      "Comprida",
      "Enredar"
    ],
    "id": "arma-briga-chicote"
  },
  {
    "grupo": "Briga",
    "nome": "Faca",
    "especialidade": "Briga",
    "treinamento": "",
    "dano": "Atletismo - 2",
    "qualidades": "Mão Inábil +1|Rápida",
    "peso": "0,5 kg",
    "preco": "5 gp",
    "notas": "",
    "qualidadesLista": [
      "Mão Inábil +1",
      "Rápida"
    ],
    "id": "arma-briga-faca"
  },
  {
    "grupo": "Briga",
    "nome": "Improvisada",
    "especialidade": "Briga",
    "treinamento": "",
    "dano": "Atletismo - 1",
    "qualidades": "Lenta",
    "peso": "",
    "preco": "",
    "notas": "Não aparece na Tabela 7-5 de preços desta imagem.",
    "qualidadesLista": [
      "Lenta"
    ],
    "id": "arma-briga-improvisada"
  },
  {
    "grupo": "Briga",
    "nome": "Manopla",
    "especialidade": "Briga",
    "treinamento": "",
    "dano": "Atletismo - 2",
    "qualidades": "Agarrar|Mão Inábil +1",
    "peso": "",
    "preco": "",
    "notas": "Não aparece na Tabela 7-5 de preços desta imagem.",
    "qualidadesLista": [
      "Agarrar",
      "Mão Inábil +1"
    ],
    "id": "arma-briga-manopla"
  },
  {
    "grupo": "Briga",
    "nome": "Punho",
    "especialidade": "Briga",
    "treinamento": "",
    "dano": "Atletismo - 3",
    "qualidades": "Agarrar|Mão Inábil +1",
    "peso": "",
    "preco": "",
    "notas": "Não aparece na Tabela 7-5 de preços desta imagem.",
    "qualidadesLista": [
      "Agarrar",
      "Mão Inábil +1"
    ],
    "id": "arma-briga-punho"
  },
  {
    "grupo": "Escudos",
    "nome": "Broquel",
    "especialidade": "Escudos",
    "treinamento": "",
    "dano": "Atletismo - 2",
    "qualidades": "Defensiva +1|Mão Inábil +1",
    "peso": "1,5 kg",
    "preco": "25 gp",
    "notas": "",
    "qualidadesLista": [
      "Defensiva +1",
      "Mão Inábil +1"
    ],
    "id": "arma-escudos-broquel"
  },
  {
    "grupo": "Escudos",
    "nome": "Escudo",
    "especialidade": "Escudos",
    "treinamento": "",
    "dano": "Atletismo - 2",
    "qualidades": "Defensiva +2",
    "peso": "2,5 kg",
    "preco": "30 gp",
    "notas": "",
    "qualidadesLista": [
      "Defensiva +2"
    ],
    "id": "arma-escudos-escudo"
  },
  {
    "grupo": "Escudos",
    "nome": "Escudo de Corpo",
    "especialidade": "Escudos",
    "treinamento": "2B",
    "dano": "Atletismo - 2",
    "qualidades": "Defensiva +6|Volume 2",
    "peso": "5 kg",
    "preco": "60 gp",
    "notas": "",
    "qualidadesLista": [
      "Defensiva +6",
      "Volume 2"
    ],
    "id": "arma-escudos-escudo-de-corpo"
  },
  {
    "grupo": "Escudos",
    "nome": "Escudo Grande",
    "especialidade": "Escudos",
    "treinamento": "1B",
    "dano": "Atletismo - 2",
    "qualidades": "Defensiva +4|Volume 1",
    "peso": "3 kg",
    "preco": "40 gp",
    "notas": "",
    "qualidadesLista": [
      "Defensiva +4",
      "Volume 1"
    ],
    "id": "arma-escudos-escudo-grande"
  },
  {
    "grupo": "Esgrima",
    "nome": "Adaga de Mão Esquerda",
    "especialidade": "Esgrima",
    "treinamento": "1B",
    "dano": "Agilidade - 1",
    "qualidades": "Defensiva +2|Mão Inábil +1",
    "peso": "0,5 kg",
    "preco": "20 gp",
    "notas": "",
    "qualidadesLista": [
      "Defensiva +2",
      "Mão Inábil +1"
    ],
    "id": "arma-esgrima-adaga-de-mao-esquerda"
  },
  {
    "grupo": "Esgrima",
    "nome": "Espada Pequena",
    "especialidade": "Esgrima",
    "treinamento": "",
    "dano": "Agilidade - 1",
    "qualidades": "Rápida",
    "peso": "1,5 kg",
    "preco": "300 gp",
    "notas": "",
    "qualidadesLista": [
      "Rápida"
    ],
    "id": "arma-esgrima-espada-pequena"
  },
  {
    "grupo": "Esgrima",
    "nome": "Lâmina Braavosi",
    "especialidade": "Esgrima",
    "treinamento": "1B",
    "dano": "Agilidade",
    "qualidades": "Defensiva +1|Rápida",
    "peso": "1,5 kg",
    "preco": "800 gp",
    "notas": "Arma exótica em Westeros; preço sugerido e pode variar muito.",
    "qualidadesLista": [
      "Defensiva +1",
      "Rápida"
    ],
    "id": "arma-esgrima-lamina-braavosi"
  },
  {
    "grupo": "Lâminas Curtas",
    "nome": "Adaga",
    "especialidade": "Lâminas Curtas",
    "treinamento": "",
    "dano": "Agilidade - 2",
    "qualidades": "Defensiva +1|Mão Inábil +1",
    "peso": "0,5 kg",
    "preco": "20 gp",
    "notas": "",
    "qualidadesLista": [
      "Defensiva +1",
      "Mão Inábil +1"
    ],
    "id": "arma-laminas-curtas-adaga"
  },
  {
    "grupo": "Lâminas Curtas",
    "nome": "Estilete",
    "especialidade": "Lâminas Curtas",
    "treinamento": "1B",
    "dano": "Agilidade",
    "qualidades": "Perfurante 2",
    "peso": "250 g",
    "preco": "30 gp",
    "notas": "",
    "qualidadesLista": [
      "Perfurante 2"
    ],
    "id": "arma-laminas-curtas-estilete"
  },
  {
    "grupo": "Lâminas Curtas",
    "nome": "Punhal",
    "especialidade": "Lâminas Curtas",
    "treinamento": "",
    "dano": "Agilidade - 2",
    "qualidades": "Mão Inábil +2",
    "peso": "0,5 kg",
    "preco": "20 gp",
    "notas": "",
    "qualidadesLista": [
      "Mão Inábil +2"
    ],
    "id": "arma-laminas-curtas-punhal"
  },
  {
    "grupo": "Lâminas Longas",
    "nome": "Arakh",
    "especialidade": "Lâminas Longas",
    "treinamento": "1B",
    "dano": "Atletismo",
    "qualidades": "Adaptável|Rápida",
    "peso": "2 kg",
    "preco": "450 gp",
    "notas": "Arma exótica em Westeros; preço sugerido e pode variar muito.",
    "qualidadesLista": [
      "Adaptável",
      "Rápida"
    ],
    "id": "arma-laminas-longas-arakh"
  },
  {
    "grupo": "Lâminas Longas",
    "nome": "Espada Bastarda",
    "especialidade": "Lâminas Longas",
    "treinamento": "1B",
    "dano": "Atletismo + 1",
    "qualidades": "Adaptável",
    "peso": "5 kg",
    "preco": "700 gp",
    "notas": "",
    "qualidadesLista": [
      "Adaptável"
    ],
    "id": "arma-laminas-longas-espada-bastarda"
  },
  {
    "grupo": "Lâminas Longas",
    "nome": "Espada Longa",
    "especialidade": "Lâminas Longas",
    "treinamento": "",
    "dano": "Atletismo + 1",
    "qualidades": "",
    "peso": "2 kg",
    "preco": "500 gp",
    "notas": "",
    "qualidadesLista": [],
    "id": "arma-laminas-longas-espada-longa"
  },
  {
    "grupo": "Lâminas Longas",
    "nome": "Montante",
    "especialidade": "Lâminas Longas",
    "treinamento": "",
    "dano": "Atletismo + 3",
    "qualidades": "Cruel|Desajeitada|Duas Mãos|Lenta|Poderosa",
    "peso": "7,5 kg",
    "preco": "800 gp",
    "notas": "",
    "qualidadesLista": [
      "Cruel",
      "Desajeitada",
      "Duas Mãos",
      "Lenta",
      "Poderosa"
    ],
    "id": "arma-laminas-longas-montante"
  },
  {
    "grupo": "Lanças",
    "nome": "Lança",
    "especialidade": "Lanças",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "Rápida",
    "peso": "3 kg",
    "preco": "50 gp",
    "notas": "",
    "qualidadesLista": [
      "Rápida"
    ],
    "id": "arma-lancas-lanca"
  },
  {
    "grupo": "Lanças",
    "nome": "Lança de Guerra",
    "especialidade": "Lanças",
    "treinamento": "1B",
    "dano": "Lidar com Animais + 4",
    "qualidades": "Cruel|Empalar|Lenta|Montada|Poderosa|Volume 2",
    "peso": "5 kg",
    "preco": "60 gp",
    "notas": "",
    "qualidadesLista": [
      "Cruel",
      "Empalar",
      "Lenta",
      "Montada",
      "Poderosa",
      "Volume 2"
    ],
    "id": "arma-lancas-lanca-de-guerra"
  },
  {
    "grupo": "Lanças",
    "nome": "Lança de Javali",
    "especialidade": "Lanças",
    "treinamento": "1B",
    "dano": "Atletismo + 1",
    "qualidades": "Duas Mãos|Empalar|Lenta|Poderosa",
    "peso": "4,5 kg",
    "preco": "40 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Empalar",
      "Lenta",
      "Poderosa"
    ],
    "id": "arma-lancas-lanca-de-javali"
  },
  {
    "grupo": "Lanças",
    "nome": "Lança de Sapo",
    "especialidade": "Lanças",
    "treinamento": "1B",
    "dano": "Agilidade + 1",
    "qualidades": "Adaptável",
    "peso": "4,5 kg",
    "preco": "25 gp",
    "notas": "Também aparece como Arma Arremessada na Tabela 9-3.",
    "qualidadesLista": [
      "Adaptável"
    ],
    "id": "arma-lancas-lanca-de-sapo"
  },
  {
    "grupo": "Lanças",
    "nome": "Lança de Torneio",
    "especialidade": "Lanças",
    "treinamento": "1B",
    "dano": "Lidar com Animais + 3",
    "qualidades": "Comprida|Frágil|Lenta|Montada|Poderosa|Volume 1",
    "peso": "4 kg",
    "preco": "40 gp",
    "notas": "",
    "qualidadesLista": [
      "Comprida",
      "Frágil",
      "Lenta",
      "Montada",
      "Poderosa",
      "Volume 1"
    ],
    "id": "arma-lancas-lanca-de-torneio"
  },
  {
    "grupo": "Lanças",
    "nome": "Pique",
    "especialidade": "Lanças",
    "treinamento": "",
    "dano": "Atletismo + 2",
    "qualidades": "Contra Carga|Desajeitada|Duas Mãos|Empalar|Lenta",
    "peso": "4,5 kg",
    "preco": "80 gp",
    "notas": "",
    "qualidadesLista": [
      "Contra Carga",
      "Desajeitada",
      "Duas Mãos",
      "Empalar",
      "Lenta"
    ],
    "id": "arma-lancas-pique"
  },
  {
    "grupo": "Lanças",
    "nome": "Tridente",
    "especialidade": "Lanças",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "Adaptável|Lenta",
    "peso": "2,5 kg",
    "preco": "30 gp",
    "notas": "Também aparece como Arma Arremessada na Tabela 9-3.",
    "qualidadesLista": [
      "Adaptável",
      "Lenta"
    ],
    "id": "arma-lancas-tridente"
  },
  {
    "grupo": "Machados",
    "nome": "Bico de Corvo",
    "especialidade": "Machados",
    "treinamento": "",
    "dano": "Atletismo - 1",
    "qualidades": "Estilhaçadora 1",
    "peso": "3 kg",
    "preco": "60 gp",
    "notas": "",
    "qualidadesLista": [
      "Estilhaçadora 1"
    ],
    "id": "arma-machados-bico-de-corvo"
  },
  {
    "grupo": "Machados",
    "nome": "Machadinha",
    "especialidade": "Machados",
    "treinamento": "",
    "dano": "Atletismo - 1",
    "qualidades": "Defensiva +1|Mão Inábil +1",
    "peso": "2 kg",
    "preco": "30 gp",
    "notas": "Também aparece como Arma Arremessada na Tabela 9-3.",
    "qualidadesLista": [
      "Defensiva +1",
      "Mão Inábil +1"
    ],
    "id": "arma-machados-machadinha"
  },
  {
    "grupo": "Machados",
    "nome": "Machado de Batalha",
    "especialidade": "Machados",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "Adaptável",
    "peso": "3,5 kg",
    "preco": "50 gp",
    "notas": "",
    "qualidadesLista": [
      "Adaptável"
    ],
    "id": "arma-machados-machado-de-batalha"
  },
  {
    "grupo": "Machados",
    "nome": "Machado de Lenhador",
    "especialidade": "Machados",
    "treinamento": "",
    "dano": "Atletismo + 1",
    "qualidades": "Duas Mãos",
    "peso": "3 kg",
    "preco": "40 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos"
    ],
    "id": "arma-machados-machado-de-lenhador"
  },
  {
    "grupo": "Machados",
    "nome": "Machado Longo",
    "especialidade": "Machados",
    "treinamento": "1B",
    "dano": "Atletismo + 3",
    "qualidades": "Comprida|Cruel|Duas Mãos|Poderosa|Volume 1",
    "peso": "10 kg",
    "preco": "500 gp",
    "notas": "",
    "qualidadesLista": [
      "Comprida",
      "Cruel",
      "Duas Mãos",
      "Poderosa",
      "Volume 1"
    ],
    "id": "arma-machados-machado-longo"
  },
  {
    "grupo": "Machados",
    "nome": "Picareta",
    "especialidade": "Machados",
    "treinamento": "",
    "dano": "Atletismo + 1",
    "qualidades": "Duas Mãos|Lenta|Poderosa",
    "peso": "5 kg",
    "preco": "50 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Lenta",
      "Poderosa"
    ],
    "id": "arma-machados-picareta"
  },
  {
    "grupo": "Arcos",
    "nome": "Arco de Curvatura Dupla",
    "especialidade": "Arcos",
    "treinamento": "1B",
    "dano": "Agilidade + 1",
    "qualidades": "Duas Mãos|Longo Alcance|Poderosa",
    "peso": "1 kg",
    "preco": "500 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Longo Alcance",
      "Poderosa"
    ],
    "id": "arma-arcos-arco-de-curvatura-dupla"
  },
  {
    "grupo": "Arcos",
    "nome": "Arco de Caça",
    "especialidade": "Arcos",
    "treinamento": "",
    "dano": "Agilidade",
    "qualidades": "Duas Mãos|Longo Alcance",
    "peso": "1,5 kg",
    "preco": "100 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Longo Alcance"
    ],
    "id": "arma-arcos-arco-de-caca"
  },
  {
    "grupo": "Arcos",
    "nome": "Arco Longo",
    "especialidade": "Arcos",
    "treinamento": "1B",
    "dano": "Agilidade + 2",
    "qualidades": "Desajeitada|Duas Mãos|Longo Alcance|Perfurante 1",
    "peso": "1,5 kg",
    "preco": "900 gp",
    "notas": "",
    "qualidadesLista": [
      "Desajeitada",
      "Duas Mãos",
      "Longo Alcance",
      "Perfurante 1"
    ],
    "id": "arma-arcos-arco-longo"
  },
  {
    "grupo": "Armas Arremessadas",
    "nome": "Lança de Sapo",
    "especialidade": "Armas Arremessadas",
    "treinamento": "1B",
    "dano": "Agilidade + 1",
    "qualidades": "Curto Alcance",
    "peso": "4,5 kg",
    "preco": "25 gp",
    "notas": "Também aparece como Lança na Tabela 9-3.",
    "qualidadesLista": [
      "Curto Alcance"
    ],
    "id": "arma-armas-arremessadas-lanca-de-sapo"
  },
  {
    "grupo": "Armas Arremessadas",
    "nome": "Machadinha",
    "especialidade": "Armas Arremessadas",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "Curto Alcance",
    "peso": "2 kg",
    "preco": "30 gp",
    "notas": "Também aparece como Machado na Tabela 9-3.",
    "qualidadesLista": [
      "Curto Alcance"
    ],
    "id": "arma-armas-arremessadas-machadinha"
  },
  {
    "grupo": "Armas Arremessadas",
    "nome": "Azagaia",
    "especialidade": "Armas Arremessadas",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "Curto Alcance",
    "peso": "1,5 kg",
    "preco": "20 gp",
    "notas": "",
    "qualidadesLista": [
      "Curto Alcance"
    ],
    "id": "arma-armas-arremessadas-azagaia"
  },
  {
    "grupo": "Armas Arremessadas",
    "nome": "Faca",
    "especialidade": "Armas Arremessadas",
    "treinamento": "",
    "dano": "Agilidade - 1",
    "qualidades": "Curto Alcance|Rápido",
    "peso": "0,5 kg",
    "preco": "5 gp",
    "notas": "Também aparece como Briga na Tabela 9-3.",
    "qualidadesLista": [
      "Curto Alcance",
      "Rápida"
    ],
    "id": "arma-armas-arremessadas-faca"
  },
  {
    "grupo": "Armas Arremessadas",
    "nome": "Rede",
    "especialidade": "Armas Arremessadas",
    "treinamento": "1B",
    "dano": "Nenhum",
    "qualidades": "Curto Alcance|Enredar",
    "peso": "2 kg",
    "preco": "20 gp",
    "notas": "",
    "qualidadesLista": [
      "Curto Alcance",
      "Enredar"
    ],
    "id": "arma-armas-arremessadas-rede"
  },
  {
    "grupo": "Armas Arremessadas",
    "nome": "Funda",
    "especialidade": "Armas Arremessadas",
    "treinamento": "",
    "dano": "Atletismo - 1",
    "qualidades": "Longo Alcance",
    "peso": "100 g",
    "preco": "",
    "notas": "",
    "qualidadesLista": [
      "Longo Alcance"
    ],
    "id": "arma-armas-arremessadas-funda"
  },
  {
    "grupo": "Armas Arremessadas",
    "nome": "Lança",
    "especialidade": "Armas Arremessadas",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "Curto Alcance",
    "peso": "3 kg",
    "preco": "50 gp",
    "notas": "Também aparece como Lança na Tabela 9-3.",
    "qualidadesLista": [
      "Curto Alcance"
    ],
    "id": "arma-armas-arremessadas-lanca"
  },
  {
    "grupo": "Armas Arremessadas",
    "nome": "Tridente",
    "especialidade": "Armas Arremessadas",
    "treinamento": "",
    "dano": "Atletismo",
    "qualidades": "Curto Alcance",
    "peso": "2,5 kg",
    "preco": "30 gp",
    "notas": "Também aparece como Lança na Tabela 9-3.",
    "qualidadesLista": [
      "Curto Alcance"
    ],
    "id": "arma-armas-arremessadas-tridente"
  },
  {
    "grupo": "Bestas",
    "nome": "Besta Pesada",
    "especialidade": "Bestas",
    "treinamento": "",
    "dano": "Agilidade + 2",
    "qualidades": "Cruel|Duas Mãos|Lenta|Longo Alcance|Perfurante 2|Recarga (Maior)",
    "peso": "4,5 kg",
    "preco": "950 gp",
    "notas": "",
    "qualidadesLista": [
      "Cruel",
      "Duas Mãos",
      "Lenta",
      "Longo Alcance",
      "Perfurante 2",
      "Recarga (Maior)"
    ],
    "id": "arma-bestas-besta-pesada"
  },
  {
    "grupo": "Bestas",
    "nome": "Besta Leve",
    "especialidade": "Bestas",
    "treinamento": "",
    "dano": "Agilidade + 1",
    "qualidades": "Lenta|Longo Alcance|Recarga (Menor)",
    "peso": "3 kg",
    "preco": "150 gp",
    "notas": "",
    "qualidadesLista": [
      "Lenta",
      "Longo Alcance",
      "Recarga (Menor)"
    ],
    "id": "arma-bestas-besta-leve"
  },
  {
    "grupo": "Bestas",
    "nome": "Besta Média",
    "especialidade": "Bestas",
    "treinamento": "",
    "dano": "Agilidade + 1",
    "qualidades": "Duas Mãos|Lenta|Longo Alcance|Perfurante 1|Recarga (Menor)",
    "peso": "4 kg",
    "preco": "400 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Lenta",
      "Longo Alcance",
      "Perfurante 1",
      "Recarga (Menor)"
    ],
    "id": "arma-bestas-besta-media"
  },
  {
    "grupo": "Bestas",
    "nome": "Besta Myresa",
    "especialidade": "Bestas",
    "treinamento": "1B",
    "dano": "Agilidade + 1",
    "qualidades": "Duas Mãos|Longo Alcance|Perfurante 1|Rápida|Recarga (Menor)",
    "peso": "4,5 kg",
    "preco": "2000 gp",
    "notas": "",
    "qualidadesLista": [
      "Duas Mãos",
      "Longo Alcance",
      "Perfurante 1",
      "Rápida",
      "Recarga (Menor)"
    ],
    "id": "arma-bestas-besta-myresa"
  }
];

export const GOT_WEAPON_QUALITIES = [
  {
    "nome": "Adaptável",
    "tipo": "automático",
    "efeito": "+1 dano ao usar com duas mãos",
    "descricao": "A arma pode ser usada com uma ou duas mãos. Quando usada com duas mãos, aumenta o dano da arma em +1.",
    "notas": "",
    "id": "qualidade-arma-adaptavel"
  },
  {
    "nome": "Agarrar",
    "tipo": "manual",
    "efeito": "agarrar alvo ao acertar e vencer Atletismo passivo",
    "descricao": "Ao atingir um oponente com uma arma de Agarrar e igualar ou exceder o resultado passivo de Atletismo dele, com Força se aplicando, você pode agarrá-lo. Um oponente agarrado não pode se mover até ser solto como ação livre ou vencer você em um teste oposto de Luta, com Briga se aplicando, como ação menor. O alvo agarrado só pode atacar com armas de Briga ou lâminas curtas e sofre -5 na Defesa em Combate, mínimo 1. Enquanto agarra, você não pode se mover e só pode atacar o alvo agarrado usando uma arma de Agarrar ou de Mão Inábil.",
    "notas": "",
    "id": "qualidade-arma-agarrar"
  },
  {
    "nome": "Atordoante",
    "tipo": "manual",
    "efeito": "sacrifica 1 grau de sucesso para tirar ação maior do alvo",
    "descricao": "Quando você obtém dois ou mais graus de sucesso em um teste de Luta com uma arma Atordoante, pode sacrificar um grau de sucesso para impedir que o inimigo use uma ação maior no próximo turno dele.",
    "notas": "",
    "id": "qualidade-arma-atordoante"
  },
  {
    "nome": "Comprida",
    "tipo": "manual",
    "efeito": "ataque a até 3 metros; múltiplos alvos com penalidade",
    "descricao": "Uma arma Comprida pode atacar oponentes que não estejam adjacentes. Você pode fazer testes de Luta contra cada oponente a até 3 metros de distância. Atacar qualquer inimigo a menos de 3 metros de distância com uma arma Comprida impõe -1D no teste de Luta.",
    "notas": "Veio cortada da página anterior e foi completada aqui.",
    "id": "qualidade-arma-comprida"
  },
  {
    "nome": "Contra Carga",
    "tipo": "manual",
    "efeito": "permite ação contra-atacar contra carga",
    "descricao": "Uma arma Contra Carga é desajeitada demais para combate normal, mas funciona bem para conter cargas. Ela permite preparar contra carga usando a ação contra-atacar.",
    "notas": "A regra remete à página 216.",
    "id": "qualidade-arma-contra-carga"
  },
  {
    "nome": "Cruel",
    "tipo": "manual",
    "efeito": "força o alvo a gastar Ponto de Destino para evitar morte",
    "descricao": "Armas Cruéis são tão boas no que fazem que lutar com elas pode gerar resultados horrendos. Se você derrotar um inimigo com uma arma Cruel, a consequência da derrota é sempre a morte. A vítima pode queimar um Ponto de Destino para evitar esse fim, como normal.",
    "notas": "",
    "id": "qualidade-arma-cruel"
  },
  {
    "nome": "Curto Alcance",
    "tipo": "automático",
    "efeito": "alcance efetivo 10 metros; até 20 metros com -1D",
    "descricao": "Uma arma de Curto Alcance tem alcance efetivo de 10 metros, ou seja, pode atacar oponentes a até 10 metros sem penalidade. Também pode atacar até 10 metros adicionais, sofrendo -1D para cada 10 metros extras. Assim, atacar um oponente a 11 metros impõe -1D no teste de Pontaria.",
    "notas": "",
    "id": "qualidade-arma-curto-alcance"
  },
  {
    "nome": "Defensiva +1",
    "tipo": "automático",
    "efeito": "+1 Bônus de Defesa",
    "descricao": "Armas Defensivas podem ser usadas para atacar, mas também são eficientes para desviar ataques. Se você estiver empunhando uma arma Defensiva e não atacar com ela, adiciona o valor de Defensiva da arma à sua Defesa em Combate. Muitas armas Defensivas também possuem Mão Inábil, permitindo somar seu bônus com o bônus defensivo de uma arma principal.",
    "notas": "O valor varia conforme a arma, por exemplo Defensiva +1, +2, +4 ou +6.",
    "valor": 1,
    "id": "qualidade-arma-defensiva-1"
  },
  {
    "nome": "Defensiva +2",
    "tipo": "automático",
    "efeito": "+2 Bônus de Defesa",
    "descricao": "Armas Defensivas podem ser usadas para atacar, mas também são eficientes para desviar ataques. Se você estiver empunhando uma arma Defensiva e não atacar com ela, adiciona o valor de Defensiva da arma à sua Defesa em Combate. Muitas armas Defensivas também possuem Mão Inábil, permitindo somar seu bônus com o bônus defensivo de uma arma principal.",
    "notas": "O valor varia conforme a arma, por exemplo Defensiva +1, +2, +4 ou +6.",
    "valor": 2,
    "id": "qualidade-arma-defensiva-2"
  },
  {
    "nome": "Defensiva +4",
    "tipo": "automático",
    "efeito": "+4 Bônus de Defesa",
    "descricao": "Armas Defensivas podem ser usadas para atacar, mas também são eficientes para desviar ataques. Se você estiver empunhando uma arma Defensiva e não atacar com ela, adiciona o valor de Defensiva da arma à sua Defesa em Combate. Muitas armas Defensivas também possuem Mão Inábil, permitindo somar seu bônus com o bônus defensivo de uma arma principal.",
    "notas": "O valor varia conforme a arma, por exemplo Defensiva +1, +2, +4 ou +6.",
    "valor": 4,
    "id": "qualidade-arma-defensiva-4"
  },
  {
    "nome": "Defensiva +6",
    "tipo": "automático",
    "efeito": "+6 Bônus de Defesa",
    "descricao": "Armas Defensivas podem ser usadas para atacar, mas também são eficientes para desviar ataques. Se você estiver empunhando uma arma Defensiva e não atacar com ela, adiciona o valor de Defensiva da arma à sua Defesa em Combate. Muitas armas Defensivas também possuem Mão Inábil, permitindo somar seu bônus com o bônus defensivo de uma arma principal.",
    "notas": "O valor varia conforme a arma, por exemplo Defensiva +1, +2, +4 ou +6.",
    "valor": 6,
    "id": "qualidade-arma-defensiva-6"
  },
  {
    "nome": "Desajeitada",
    "tipo": "manual",
    "efeito": "penalidade em uso montado ou ataque à distância",
    "descricao": "Ao usar uma arma Desajeitada enquanto estiver montado, você sofre uma penalidade de -2D em qualquer teste relacionado à arma. Para armas de combate corpo-a-corpo, a penalidade se aplica aos testes de Luta. Para armas de ataque à distância, a penalidade se aplica aos testes de Pontaria.",
    "notas": "",
    "id": "qualidade-arma-desajeitada"
  },
  {
    "nome": "Duas Mãos",
    "tipo": "automático",
    "efeito": "exige duas mãos; -2D se usada com uma mão",
    "descricao": "Armas grandes precisam de duas mãos para serem empunhadas corretamente. Se puder usar apenas uma mão, você sofre -2D em seus testes de Luta.",
    "notas": "",
    "id": "qualidade-arma-duas-maos"
  },
  {
    "nome": "Empalar",
    "tipo": "manual",
    "efeito": "com 3+ graus, atravessa o alvo e pode imobilizar",
    "descricao": "Sempre que você obtiver três ou mais graus de sucesso com uma arma de Empalar, atravessa seu oponente com ela. O alvo pode tentar resistir com um teste de Atletismo Desafiador (9). Em caso de falha, fica empalado, a arma fica presa no corpo dele e ele não pode se mover. Se for bem-sucedido, o oponente não pode se mover, mas você também não pode atacar com a arma. Para soltar a arma, você deve vencer um teste de Atletismo contra uma dificuldade igual a 3 + o Valor de Armadura do oponente. Um sucesso liberta a arma, e cada grau adicional causa dano da arma mais uma vez. Para imobilizar um oponente empalado, fixe-o ao chão, parede ou outra superfície e role Atletismo contra o Vigor passivo do oponente, com Resistência se aplicando. Um sucesso impede que o oponente se mova até se libertar. Um oponente empalado pode remover a arma com uma ação maior e um teste de Atletismo Desafiador (9), sofrendo 1 ferimento, ou 1 lesão se não puder sofrer mais ferimentos. Um aliado pode remover a arma com segurança com um teste de Cura Formidável (12) como ação maior. Uma falha remove a arma, mas causa 1 ponto de dano para cada 5 pontos pelos quais o teste falhou, mínimo 1.",
    "notas": "Inclui as regras de Imobilizando um Oponente e Libertando-se.",
    "id": "qualidade-arma-empalar"
  },
  {
    "nome": "Enredar",
    "tipo": "manual",
    "efeito": "prende o alvo e reduz movimento",
    "descricao": "Uma arma de Enredar prende seu adversário. Um oponente atingido por esta arma reduz seu movimento a 1 metro e sofre -5 de penalidade em todos os testes. O alvo pode se libertar gastando uma ação maior e sendo bem-sucedido em um teste de Atletismo Desafiador (9), usando dados de bônus de Força, ou em um teste de Agilidade Desafiador (9), usando dados de bônus de Contorcionismo. Você não pode fazer outros ataques com uma arma de Enredar enquanto o alvo estiver preso.",
    "notas": "",
    "id": "qualidade-arma-enredar"
  },
  {
    "nome": "Estilhaçadora 1",
    "tipo": "manual",
    "efeito": "reduz Bônus Defensivo ou Valor de Armadura em 1",
    "descricao": "Armas Estilhaçadoras são feitas para esmagar escudos, armas usadas para aparar e armaduras. Sempre que você obtiver dois ou mais graus de sucesso em um teste de Luta com uma arma Estilhaçadora, reduza o Bônus Defensivo ou o Valor de Armadura do oponente na quantidade indicada. A arma afeta primeiro armas com Bônus Defensivo. Reduzir o Bônus Defensivo de uma arma ou o Valor de Armadura de uma armadura a 0 destrói o item.",
    "notas": "Criado como variação numérica da qualidade Estilhaçadora.",
    "id": "qualidade-arma-estilhacadora-1",
    "valor": 1
  },
  {
    "nome": "Estilhaçadora 2",
    "tipo": "manual",
    "efeito": "reduz Bônus Defensivo ou Valor de Armadura em 2",
    "descricao": "Armas Estilhaçadoras são feitas para esmagar escudos, armas usadas para aparar e armaduras. Sempre que você obtiver dois ou mais graus de sucesso em um teste de Luta com uma arma Estilhaçadora, reduza o Bônus Defensivo ou o Valor de Armadura do oponente na quantidade indicada. A arma afeta primeiro armas com Bônus Defensivo. Reduzir o Bônus Defensivo de uma arma ou o Valor de Armadura de uma armadura a 0 destrói o item.",
    "notas": "Criado como variação numérica da qualidade Estilhaçadora.",
    "id": "qualidade-arma-estilhacadora-2",
    "valor": 2
  },
  {
    "nome": "Frágil",
    "tipo": "automático",
    "efeito": "quebra com 2+ graus de sucesso",
    "descricao": "Sempre que você obtém dois ou mais graus de sucesso com uma arma Frágil, ela se quebra automaticamente.",
    "notas": "",
    "id": "qualidade-arma-fragil"
  },
  {
    "nome": "Lenta",
    "tipo": "automático",
    "efeito": "não permite Ataques Divididos",
    "descricao": "Uma arma Lenta é pesada e difícil de usar com velocidade e graça. Você não pode fazer Ataques Divididos com estas armas.",
    "notas": "",
    "id": "qualidade-arma-lenta"
  },
  {
    "nome": "Longo Alcance",
    "tipo": "automático",
    "efeito": "alcance até 100 metros; -1D por 100 metros extras",
    "descricao": "Se você tiver uma linha de tiro, pode disparar uma arma de Longo Alcance contra alvos a até 100 metros. Para cada 100 metros de distância entre você e o alvo, você sofre -1D em seu teste de Pontaria.",
    "notas": "",
    "id": "qualidade-arma-longo-alcance"
  },
  {
    "nome": "Mão Inábil +1",
    "tipo": "manual",
    "efeito": "+1 dano na arma principal em ataque com duas armas",
    "descricao": "Uma arma de Mão Inábil pode ser usada em sua mão inábil, permitindo que você adicione seu modificador de Mão Inábil ao dano da sua arma principal com um teste de Luta bem-sucedido. Para receber este benefício, você deve gastar uma ação maior e fazer um ataque com duas armas.",
    "notas": "Criado como variação numérica da qualidade Mão Inábil.",
    "id": "qualidade-arma-mao-inabil-1",
    "valor": 1
  },
  {
    "nome": "Mão Inábil +2",
    "tipo": "manual",
    "efeito": "+2 dano na arma principal em ataque com duas armas",
    "descricao": "Uma arma de Mão Inábil pode ser usada em sua mão inábil, permitindo que você adicione seu modificador de Mão Inábil ao dano da sua arma principal com um teste de Luta bem-sucedido. Para receber este benefício, você deve gastar uma ação maior e fazer um ataque com duas armas.",
    "notas": "Criado como variação numérica da qualidade Mão Inábil.",
    "id": "qualidade-arma-mao-inabil-2",
    "valor": 2
  },
  {
    "nome": "Montada",
    "tipo": "automático",
    "efeito": "feita para uso montado; -2D se usada a pé",
    "descricao": "Armas Montadas são grandes e volumosas demais para serem usadas a pé. São feitas para uso sobre um cavalo ou outra montaria. Usar estas armas a pé impõe -2D em seus testes de Luta.",
    "notas": "",
    "id": "qualidade-arma-montada"
  },
  {
    "nome": "Perfurante 1",
    "tipo": "automático",
    "efeito": "ignora 1 VA",
    "descricao": "Armas perfurantes penetram em armaduras. Sempre que você atingir um oponente com uma arma Perfurante, seu dano ignora uma quantidade de Valor de Armadura igual ao número listado.",
    "notas": "Criado como variação numérica da qualidade Perfurante.",
    "id": "qualidade-arma-perfurante-1",
    "valor": 1
  },
  {
    "nome": "Perfurante 2",
    "tipo": "automático",
    "efeito": "ignora 2 VA",
    "descricao": "Armas perfurantes penetram em armaduras. Sempre que você atingir um oponente com uma arma Perfurante, seu dano ignora uma quantidade de Valor de Armadura igual ao número listado.",
    "notas": "Criado como variação numérica da qualidade Perfurante.",
    "id": "qualidade-arma-perfurante-2",
    "valor": 2
  },
  {
    "nome": "Poderosa",
    "tipo": "automático",
    "efeito": "+1 dano por dado de bônus em Força",
    "descricao": "Personagens fortes podem usar uma parte maior de seu poderio muscular com armas Poderosas. Para cada dado de bônus investido em Força, você pode aumentar o dano de uma arma Poderosa em +1.",
    "notas": "",
    "id": "qualidade-arma-poderosa"
  },
  {
    "nome": "Rápida",
    "tipo": "automático",
    "efeito": "+1B em cada teste de Ataque Dividido",
    "descricao": "Uma arma Rápida é feita para evitar as defesas do oponente e permitir que o usuário ataque com rapidez. Quando você faz um ataque dividido usando uma arma Rápida, recebe +1B em cada teste. Os dados de bônus pela qualidade Rápida podem exceder os limites normais.",
    "notas": "",
    "id": "qualidade-arma-rapida"
  },
  {
    "nome": "Recarga (Menor)",
    "tipo": "automático",
    "efeito": "exige ação menor para recarregar",
    "descricao": "Uma arma de Pontaria com a qualidade Recarga exige uma ação para ser recarregada após ser disparada. A qualidade especifica o tipo de ação necessária para recarregar a arma.",
    "notas": "Criado como variação da qualidade Recarga.",
    "id": "qualidade-arma-recarga-menor"
  },
  {
    "nome": "Recarga (Maior)",
    "tipo": "automático",
    "efeito": "exige ação maior para recarregar",
    "descricao": "Uma arma de Pontaria com a qualidade Recarga exige uma ação para ser recarregada após ser disparada. A qualidade especifica o tipo de ação necessária para recarregar a arma.",
    "notas": "Criado como variação da qualidade Recarga.",
    "id": "qualidade-arma-recarga-maior"
  },
  {
    "nome": "Volume 1",
    "tipo": "automático",
    "efeito": "Volume 1",
    "descricao": "A arma possui Volume 1. Algumas armas são pesadas ou incômodas e deixam o personagem mais lento em combate. Se uma arma tiver um valor de Volume, ele se aplica ao Volume total para reduzir Movimento.",
    "notas": "Criado como variação numérica da qualidade Volume.",
    "id": "qualidade-arma-volume-1",
    "valor": 1
  },
  {
    "nome": "Volume 2",
    "tipo": "automático",
    "efeito": "Volume 2",
    "descricao": "A arma possui Volume 2. Algumas armas são pesadas ou incômodas e deixam o personagem mais lento em combate. Se uma arma tiver um valor de Volume, ele se aplica ao Volume total para reduzir Movimento.",
    "notas": "Criado como variação numérica da qualidade Volume.",
    "id": "qualidade-arma-volume-2",
    "valor": 2
  }
];
