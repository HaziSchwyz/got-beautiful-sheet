export const TRAIT_AUTOMATION_VERSION = "0.2.13-quality-batch-v5e-companions";

function cloneData(value) {
  if (globalThis.foundry?.utils?.deepClone) {
    return foundry.utils.deepClone(value);
  }

  return JSON.parse(JSON.stringify(value ?? null));
}

export function normalizeTraitName(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}

const DEFECT_AUTOMATION = {
  "Aleijado": {
    configs: [
      {
        type: "trait.config",
        key: "lostMember",
        label: "Membro perdido",
        input: "select",
        required: true,
        options: [
          {
            value: "leg",
            label: "Perna"
          },
          {
            value: "arm",
            label: "Braço"
          }
        ]
      }
    ],
    effects: [
      {
        id: "aleijado-persuasao-reroll-6",
        type: "roll.rerollFace",
        target: "Persuasão",
        face: 6,
        label: "Rerrola resultados 6 em Persuasão."
      },
      {
        id: "aleijado-perna-movimento-metade",
        type: "stat.modifier",
        target: "movement",
        mode: "multiply",
        value: 0.5,
        minimum: 1,
        whenConfig: {
          key: "lostMember",
          value: "leg"
        },
        label: "Movimento pela metade por perda de perna."
      },
      {
        id: "aleijado-perna-atletismo-menos-1d",
        type: "roll.rank",
        target: "Atletismo",
        value: -1,
        whenConfig: {
          key: "lostMember",
          value: "leg"
        },
        label: "-1D em Atletismo por perda de perna."
      },
      {
        id: "aleijado-braco-duas-maos-menos-2d",
        type: "roll.rank",
        target: "*",
        value: -2,
        whenConfig: {
          key: "lostMember",
          value: "arm"
        },
        prompt: {
          title: "Aleijado: Braço",
          question: "Este teste exige o uso das duas mãos?",
          yesLabel: "Aplicar -2D",
          noLabel: "Ignorar"
        },
        label: "-2D em testes que exigem duas mãos."
      }
    ],
    notes: [
      {
        id: "aleijado-braco-armas-nota",
        type: "note",
        target: "equipment",
        whenConfig: {
          key: "lostMember",
          value: "arm"
        },
        text: "Não pode usar armas de duas mãos."
      }
    ]
  },

  "Amaldiçoado": {
    notes: [
      {
        id: "amaldicoado-destino-nota",
        type: "note",
        target: "destiny",
        text: "Quando gastar Ponto de Destino, role 1d6. Em 1, o Ponto de Destino é desperdiçado e não tem efeito."
      }
    ]
  },

  "Ameaçador": {
    effects: [
      {
        id: "ameacador-charme-menos-2d",
        type: "roll.rank",
        target: {
          ability: "Persuasão",
          specialization: "Charme"
        },
        value: -2,
        label: "-2D em Persuasão: Charme."
      },
      {
        id: "ameacador-seduzir-menos-2d",
        type: "roll.rank",
        target: {
          ability: "Persuasão",
          specialization: "Seduzir"
        },
        value: -2,
        label: "-2D em Persuasão: Seduzir."
      }
    ],
    notes: [
      {
        id: "ameacador-intriga-nota",
        type: "note",
        target: "intrigue",
        text: "Durante uma intriga, se o primeiro teste de Persuasão não usar Intimidar, aplique manualmente -2 em Defesa em Intriga até o fim da cena."
      }
    ]
  },

  "Anão": {
    effects: [
      {
        id: "anao-movimento-menos-1",
        type: "stat.modifier",
        target: "movement",
        mode: "add",
        value: -1,
        minimum: 1,
        label: "Movimento -1."
      },
      {
        id: "anao-charme-menos-1d",
        type: "roll.rank",
        target: {
          ability: "Persuasão",
          specialization: "Charme"
        },
        value: -1,
        label: "-1D em Persuasão: Charme."
      },
      {
        id: "anao-seduzir-menos-1d",
        type: "roll.rank",
        target: {
          ability: "Persuasão",
          specialization: "Seduzir"
        },
        value: -1,
        label: "-1D em Persuasão: Seduzir."
      }
    ]
  },

  "Arrogância Suprema": {
    effects: [
      {
        id: "arrogancia-suprema-percepcao-status",
        type: "roll.result",
        target: "Percepção",
        valueFromAbility: "Status",
        multiplier: -1,
        label: "Penalidade em Percepção igual ao Status."
      }
    ]
  },

  "Assombrado": {
    effects: [
      {
        id: "assombrado-percepcao-menos-1d",
        type: "roll.rank",
        target: "Percepção",
        value: -1,
        label: "-1D em Percepção."
      }
    ],
    notes: [
      {
        id: "assombrado-primeira-rodada-nota",
        type: "note",
        target: "combat",
        text: "Na primeira rodada de combate, adicione manualmente aos resultados de Luta um valor igual aos dados de bônus de Memória."
      }
    ]
  },

  "Bastardo": {
    effects: [
      {
        id: "bastardo-persuasao-status-maior",
        type: "roll.rank",
        target: "Persuasão",
        value: -1,
        prompt: {
          title: "Bastardo",
          question: "O personagem está interagindo com alguém de Status maior?",
          yesLabel: "Aplicar -1D",
          noLabel: "Ignorar"
        },
        label: "-1D em Persuasão contra personagens com Status maior."
      }
    ],
    notes: [
      {
        id: "bastardo-sobrenome-nota",
        type: "note",
        target: "story",
        text: "Não usa o nome da família; recebe sobrenome regional de bastardo."
      }
    ]
  },

  "Colérico": {
    effects: [
      {
        id: "colerico-seduzir-menos-2d",
        type: "roll.rank",
        target: {
          ability: "Persuasão",
          specialization: "Seduzir"
        },
        value: -2,
        label: "-2D em Persuasão: Seduzir."
      }
    ],
    notes: [
      {
        id: "colerico-primeiro-teste-nota",
        type: "note",
        target: "intrigue",
        text: "O primeiro teste de Persuasão em uma intriga deve usar Intimidar."
      }
    ]
  },

  "Covarde": {
    effects: [
      {
        id: "covarde-combate-intriga-menos-1d",
        type: "roll.rank",
        target: "*",
        value: -1,
        prompt: {
          title: "Covarde",
          question: "O personagem está em combate ou intriga e ainda sofre a penalidade de Covarde?",
          yesLabel: "Aplicar -1D",
          noLabel: "Ignorar"
        },
        label: "-1D em todos os testes durante combate ou intriga."
      }
    ],
    notes: [
      {
        id: "covarde-vontade-nota",
        type: "note",
        target: "combat",
        text: "A cada rodada, como ação livre, pode testar Vontade Formidável (12). Em sucesso, remove a penalidade e recebe +1B em todos os testes."
      }
    ]
  },

  "Defeito": {
    configs: [
      {
        type: "trait.config",
        key: "chosenAbility",
        label: "Habilidade",
        input: "ability",
        required: true
      }
    ],
    effects: [
      {
        id: "defeito-habilidade-escolhida-menos-1d",
        type: "roll.rank",
        targetFromConfig: "chosenAbility",
        value: -1,
        label: "-1D na habilidade escolhida."
      }
    ],
    notes: [
      {
        id: "defeito-passivo-derivado-nota",
        type: "note",
        target: "manual",
        text: "Também reduz o teste passivo da habilidade e características derivadas ligadas a ela em 1. Automatização de passivos fica para etapa futura."
      }
    ]
  },

  "Desastrado": {
    effects: [
      {
        id: "desastrado-reroll-agilidade-6",
        type: "roll.rerollFace",
        target: "Agilidade",
        face: 6,
        label: "Rerrola resultados 6 em Agilidade."
      }
    ]
  },

  "Distraído": {
    effects: [
      {
        id: "distraido-reroll-astucia-6",
        type: "roll.rerollFace",
        target: "Astúcia",
        face: 6,
        label: "Rerrola resultados 6 em Astúcia."
      }
    ]
  },

  "Dívida": {
    notes: [
      {
        id: "divida-nota",
        type: "note",
        target: "economy",
        text: "Todas as compras custam o dobro. Resolver manualmente até existir sistema econômico."
      }
    ]
  },

  "Doença na Infância": {
    effects: [
      {
        id: "doenca-infancia-saude-menos-2",
        type: "stat.modifier",
        target: "health",
        mode: "add",
        value: -2,
        label: "Saúde -2."
      }
    ]
  },

  "Doente": {
    effects: [
      {
        id: "doente-vigor-perigos-doencas-menos-1d",
        type: "roll.rank",
        target: "Vigor",
        value: -1,
        prompt: {
          title: "Doente",
          question: "Este teste de Vigor é para resistir a perigos ou doenças?",
          yesLabel: "Aplicar -1D",
          noLabel: "Ignorar"
        },
        label: "-1D em Vigor para resistir a perigos e doenças."
      }
    ],
    notes: [
      {
        id: "doente-inconsistencia-nota",
        type: "note",
        target: "rules",
        text: "Usando o efeito mecânico: -1D em Vigor. A descrição curta pode mencionar outro valor em algumas versões."
      }
    ]
  },

  "Empolado": {
    effects: [
      {
        id: "empolado-empatia-menos-1d",
        type: "roll.rank",
        target: {
          ability: "Percepção",
          specialization: "Empatia"
        },
        value: -1,
        label: "-1D em Percepção: Empatia."
      }
    ],
    notes: [
      {
        id: "empolado-postura-nota",
        type: "note",
        target: "intrigue",
        text: "Ao lidar com alguém socialmente inferior ou que viole normas aceitas, a postura inicial deve ser Desgostoso ou pior."
      }
    ]
  },

  "Eunuco": {
    effects: [
      {
        id: "eunuco-persuasao-menos-1d",
        type: "roll.rank",
        target: "Persuasão",
        value: -1,
        label: "-1D em Persuasão."
      }
    ],
    notes: [
      {
        id: "eunuco-nota",
        type: "note",
        target: "manual",
        text: "Inimigos não podem usar Seduzir para influenciá-lo. Não pode ter filhos ou herdeiros."
      }
    ]
  },

  "Fragil": {
    effects: [
      {
        id: "fragil-astucia-mais-1d",
        type: "roll.rank",
        target: "Astúcia",
        value: 1,
        label: "+1D em Astúcia."
      },
      {
        id: "fragil-conhecimento-mais-1d",
        type: "roll.rank",
        target: "Conhecimento",
        value: 1,
        label: "+1D em Conhecimento."
      }
    ],
    notes: [
      {
        id: "fragil-restricoes-nota",
        type: "note",
        target: "manual",
        text: "Não pode fazer testes de Agilidade, Atletismo, Luta ou Pontaria. Como roll.block foi removido, o mestre controla isso manualmente."
      },
      {
        id: "fragil-veneravel-nota",
        type: "note",
        target: "character",
        text: "Conta como até três dos defeitos exigidos para personagens Veneráveis."
      }
    ]
  },

  "Frágil": {
    effects: [
      {
        id: "fragil-astucia-mais-1d",
        type: "roll.rank",
        target: "Astúcia",
        value: 1,
        label: "+1D em Astúcia."
      },
      {
        id: "fragil-conhecimento-mais-1d",
        type: "roll.rank",
        target: "Conhecimento",
        value: 1,
        label: "+1D em Conhecimento."
      }
    ],
    notes: [
      {
        id: "fragil-restricoes-nota",
        type: "note",
        target: "manual",
        text: "Não pode fazer testes de Agilidade, Atletismo, Luta ou Pontaria. Como roll.block foi removido, o mestre controla isso manualmente."
      },
      {
        id: "fragil-veneravel-nota",
        type: "note",
        target: "character",
        text: "Conta como até três dos defeitos exigidos para personagens Veneráveis."
      }
    ]
  },

  "Hábito Perturbador": {
    effects: [
      {
        id: "habito-perturbador-intimidar-mais-1d",
        type: "roll.rank",
        target: {
          ability: "Persuasão",
          specialization: "Intimidar"
        },
        value: 1,
        prompt: {
          title: "Hábito Perturbador",
          question: "O personagem foi reconhecido e o hábito favorece esta tentativa de Intimidar?",
          yesLabel: "Aplicar +1D",
          noLabel: "Ignorar"
        },
        label: "+1D em Persuasão: Intimidar quando reconhecido."
      },
      {
        id: "habito-perturbador-outros-usos-persuasao-menos-1d",
        type: "roll.rank",
        target: "Persuasão",
        value: -1,
        prompt: {
          title: "Hábito Perturbador",
          question: "Este uso de Persuasão não é Intimidar e deve sofrer -1D pelo hábito?",
          yesLabel: "Aplicar -1D",
          noLabel: "Ignorar"
        },
        label: "-1D nos outros usos de Persuasão."
      }
    ]
  },

  "Honrado": {
    effects: [
      {
        id: "honrado-reroll-enganacao-6",
        type: "roll.rerollFace",
        target: "Enganação",
        face: 6,
        label: "Rerrola resultados 6 em Enganação."
      }
    ]
  },

  "Ignóbil": {
    effects: [
      {
        id: "ignobil-persuasao-menos-1d",
        type: "roll.rank",
        target: "Persuasão",
        value: -1,
        label: "-1D em Persuasão."
      },
      {
        id: "ignobil-status-menos-1d",
        type: "roll.rank",
        target: "Status",
        value: -1,
        label: "-1D em Status."
      }
    ]
  },

  "Ingênuo": {
    effects: [
      {
        id: "ingenuo-defesa-intriga-menos-3",
        type: "stat.modifier",
        target: "intrigueDefense",
        mode: "add",
        value: -3,
        label: "Defesa em Intriga -3."
      }
    ],
    notes: [
      {
        id: "ingenuo-enganacao-nota",
        type: "note",
        target: "intrigue",
        text: "Também sofre -3 contra testes de Enganação. Automatização de passivos/defesas específicas fica para etapa futura."
      }
    ]
  },

  "Inimigo": {
    notes: [
      {
        id: "inimigo-nota",
        type: "note",
        target: "story",
        text: "Defeito narrativo. Registrar inimigo mortal e resolver em jogo."
      }
    ]
  },

  "Insanidade Cruel": {
    effects: [
      {
        id: "insanidade-cruel-empatia-menos-2d",
        type: "roll.rank",
        target: {
          ability: "Percepção",
          specialization: "Empatia"
        },
        value: -2,
        label: "-2D em Percepção: Empatia."
      }
    ],
    notes: [
      {
        id: "insanidade-cruel-postura-nota",
        type: "note",
        target: "intrigue",
        text: "Em intrigas, se o oponente reconhecer o que o personagem é, a postura do oponente é um passo pior."
      }
    ]
  },

  "Lascivo": {
    effects: [
      {
        id: "lascivo-charme-menos-2d",
        type: "roll.rank",
        target: {
          ability: "Persuasão",
          specialization: "Charme"
        },
        value: -2,
        label: "-2D em Persuasão: Charme."
      }
    ],
    notes: [
      {
        id: "lascivo-restricao-nota",
        type: "note",
        target: "intrigue",
        text: "Durante uma intriga, o primeiro teste de Persuasão deve usar Seduzir. Se não usar, aplique manualmente -2 em Defesa em Intriga até o fim da cena."
      }
    ]
  },

  "Manco": {
    effects: [
      {
        id: "manco-movimento-menos-2",
        type: "stat.modifier",
        target: "movement",
        mode: "add",
        value: -2,
        minimum: 1,
        label: "Movimento -2, mínimo 1."
      }
    ]
  },

  "Marcado": {
    effects: [
      {
        id: "marcado-reroll-persuasao-6",
        type: "roll.rerollFace",
        target: "Persuasão",
        face: 6,
        label: "Rerrola resultados 6 em Persuasão."
      }
    ]
  },

  "Medo": {
    configs: [
      {
        type: "trait.config",
        key: "fearSource",
        label: "Fonte do medo",
        input: "text",
        required: true,
        placeholder: "Ex.: fogo, cobras, lobos, sangue, multidões"
      }
    ],
    effects: [
      {
        id: "medo-fonte-presente-menos-1d",
        type: "roll.rank",
        target: "*",
        value: -1,
        prompt: {
          title: "Medo",
          question: "A fonte do medo está presente e deve aplicar -1D?",
          yesLabel: "Aplicar -1D",
          noLabel: "Ignorar"
        },
        label: "-1D enquanto a fonte do medo estiver presente."
      }
    ],
    notes: [
      {
        id: "medo-superar-nota",
        type: "note",
        target: "encounter",
        text: "A cada rodada, no turno do personagem, role 1d6. Em 6, supera o medo e remove a penalidade até o fim do encontro."
      }
    ]
  },

  "Mudo": {
    effects: [
      {
        id: "mudo-intriga-menos-2d",
        type: "roll.rank",
        target: "*",
        value: -2,
        prompt: {
          title: "Mudo",
          question: "Esta rolagem acontece durante uma intriga?",
          yesLabel: "Aplicar -2D",
          noLabel: "Ignorar"
        },
        label: "-2D em testes durante intrigas."
      }
    ],
    notes: [
      {
        id: "mudo-oponentes-nota",
        type: "note",
        target: "intrigue",
        text: "Oponentes sofrem -2D para descobrir sua postura."
      }
    ]
  },

  "Odiado": {
    effects: [
      {
        id: "odiado-status-menos-1d",
        type: "roll.rank",
        target: "Status",
        value: -1,
        label: "-1D em Status."
      }
    ],
    notes: [
      {
        id: "odiado-postura-nota",
        type: "note",
        target: "intrigue",
        text: "Durante intrigas, a postura do oponente é um passo pior que o normal."
      }
    ]
  },

  "Preso à Garrafa": {
    effects: [
      {
        id: "preso-garrafa-bebado-menos-2-resultado",
        type: "roll.result",
        target: "*",
        value: -2,
        prompt: {
          title: "Preso à Garrafa",
          question: "O personagem está bêbado, mas não está bebendo junto com outras pessoas?",
          yesLabel: "Aplicar -2",
          noLabel: "Ignorar"
        },
        label: "-2 no resultado enquanto bêbado."
      },
      {
        id: "preso-garrafa-bebendo-com-outros-menos-2d",
        type: "roll.rank",
        target: "*",
        value: -2,
        prompt: {
          title: "Preso à Garrafa",
          question: "O personagem está bebendo junto com outras pessoas e deve sofrer -2D?",
          yesLabel: "Aplicar -2D",
          noLabel: "Ignorar"
        },
        label: "-2D em todos os testes ao beber junto com outras pessoas."
      }
    ],
    notes: [
      {
        id: "preso-garrafa-vontade-nota",
        type: "note",
        target: "manual",
        text: "Em situação perturbadora, teste Vontade Formidável (12) para evitar recorrer ao álcool."
      },
      {
        id: "preso-garrafa-sobriedade-nota",
        type: "note",
        target: "manual",
        text: "A cada hora após beber, teste Vigor Desafiador (9). Sucesso reduz a penalidade em -1 ou -1D."
      }
    ]
  },

  "Proscrito": {
    effects: [
      {
        id: "proscrito-status-menos-2d",
        type: "roll.rank",
        target: "Status",
        value: -2,
        label: "-2D em Status."
      }
    ]
  },

  "Protegido": {
    configs: [
      {
        type: "trait.config",
        key: "birthHouse",
        label: "Casa natal",
        input: "text",
        required: true
      },
      {
        type: "trait.config",
        key: "fosterHouse",
        label: "Casa onde foi criado",
        input: "text",
        required: true
      }
    ],
    effects: [
      {
        id: "protegido-persuasao-casas-menos-1d",
        type: "roll.rank",
        target: "Persuasão",
        value: -1,
        prompt: {
          title: "Protegido",
          question: "A rolagem envolve membros da casa natal ou da casa que criou o personagem?",
          yesLabel: "Aplicar -1D",
          noLabel: "Ignorar"
        },
        label: "-1D em Persuasão com membros das duas casas ligadas ao defeito."
      }
    ],
    notes: [
      {
        id: "protegido-retaliacao-nota",
        type: "note",
        target: "story",
        text: "Se a casa natal tomar atitude hostil contra a casa que criou o personagem, ele pode sofrer retaliação."
      }
    ]
  },

  "Saúde Frágil": {
    effects: [
      {
        id: "saude-fragil-vigor-ferimentos-lesoes-menos-3",
        type: "roll.result",
        target: "Vigor",
        value: -3,
        prompt: {
          title: "Saúde Frágil",
          question: "Este teste de Vigor é para remover ferimentos ou lesões?",
          yesLabel: "Aplicar -3",
          noLabel: "Ignorar"
        },
        label: "-3 no resultado de Vigor para remover ferimentos ou lesões."
      }
    ]
  },

  "Sentido Deficiente": {
    configs: [
      {
        type: "trait.config",
        key: "impairedSense",
        label: "Sentido deficiente",
        input: "select",
        required: true,
        options: [
          {
            value: "blind",
            label: "Cegueira"
          },
          {
            value: "deaf",
            label: "Surdez"
          }
        ]
      }
    ],
    effects: [
      {
        id: "sentido-deficiente-movimento-menos-1",
        type: "stat.modifier",
        target: "movement",
        mode: "add",
        value: -1,
        minimum: 1,
        label: "Movimento -1 por Sentido Deficiente."
      }
    ],
    notes: [
      {
        id: "sentido-deficiente-percepcao-nota",
        type: "note",
        target: "perception",
        text: "Falha automaticamente em testes de Percepção que dependam do sentido ausente. O mestre decide quando o teste depende desse sentido."
      }
    ]
  }
};

const QUALITY_AUTOMATION = {
  "Companheiro": {
    configs: [
      {
        type: "trait.config",
        key: "companionName",
        label: "Nome do companheiro",
        input: "text",
        required: true,
        placeholder: "Ex.: Sor Davos"
      },
      {
        type: "trait.config",
        key: "companionNotes",
        label: "Observacoes rapidas",
        input: "text",
        required: false,
        placeholder: "Ex.: escudeiro leal, guarda-costas, aliado juramentado..."
      }
    ],
    notes: [
      {
        id: "companheiro-adjacente-defesas-nota",
        type: "note",
        target: "combat-intrigue",
        text: "Enquanto o companheiro estiver adjacente, +2 Defesa em Combate e +2 Defesa em Intriga. O companheiro recebe metade da Experiencia do personagem."
      },
      {
        id: "companheiro-status-xp-nota",
        type: "note",
        target: "manual",
        text: "O Status do companheiro nao pode ser maior que o do personagem. Este bloco nao cria Actor automaticamente."
      }
    ]
  },

  "Companheiro Animal": {
    configs: [
      {
        type: "trait.config",
        key: "animalType",
        label: "Tipo do animal",
        input: "choice",
        required: true,
        options: [
          {
            value: "Aguia",
            label: "Aguia"
          },
          {
            value: "Cao",
            label: "Cao"
          },
          {
            value: "Cavalo",
            label: "Cavalo"
          },
          {
            value: "Corvo",
            label: "Corvo"
          },
          {
            value: "Gato sombrio",
            label: "Gato sombrio"
          },
          {
            value: "Lobo",
            label: "Lobo"
          }
        ]
      },
      {
        type: "trait.config",
        key: "animalName",
        label: "Nome do animal",
        input: "text",
        required: false,
        placeholder: "Ex.: Cinzento"
      }
    ],
    effects: [
      {
        id: "companheiro-animal-luta-adjacente-mais-1d",
        type: "roll.rank",
        target: "Luta",
        value: 1,
        prompt: {
          title: "Companheiro Animal",
          question: "Seu Companheiro Animal esta adjacente a voce ou ao oponente?",
          yesLabel: "Aplicar +1D",
          noLabel: "Ignorar"
        },
        label: "+1D em Luta enquanto o animal estiver adjacente a voce ou ao oponente."
      }
    ],
    notes: [
      {
        id: "companheiro-animal-adjacente-nota",
        type: "note",
        target: "combat",
        text: "Enquanto o animal estiver adjacente a voce ou ao oponente, +1D em Luta."
      },
      {
        id: "companheiro-animal-destino-nota",
        type: "note",
        target: "manual",
        text: "Caso o animal morra, o beneficio e perdido e o Ponto de Destino investido tambem."
      }
    ]
  },

  "Ágil": {
    effects: [
      {
        id: "agil-agilidade-reroll-1",
        type: "roll.rerollFace",
        target: "Agilidade",
        face: 1,
        limitFromBonusDice: true,
        minimum: 1,
        prompt: {
          title: "Ágil",
          question: "Usar Ágil para rerrolar resultados 1 em Agilidade?",
          yesLabel: "Rerrolar 1",
          noLabel: "Ignorar"
        },
        label: "Rerrola resultados 1 em Agilidade, mínimo 1."
      }
    ]
  },

  "Atraente": {
    effects: [
      {
        id: "atraente-persuasao-reroll-1",
        type: "roll.rerollFace",
        target: "Persuasão",
        face: 1,
        limitFromAbilityHalf: "Persuasão",
        minimum: 1,
        label: "Rerrola resultados 1 em Persuasão, limitado à metade de Persuasão."
      }
    ]
  },

  "Rato das Ruas": {
    effects: [
      {
        id: "rato-ruas-ladinagem-reroll-1",
        type: "roll.rerollFace",
        target: "Ladinagem",
        face: 1,
        limitFromBonusDice: true,
        minimum: 1,
        prompt: {
          title: "Rato das Ruas",
          question: "Usar Rato das Ruas para rerrolar resultados 1 neste teste de Ladinagem?",
          yesLabel: "Rerrolar 1",
          noLabel: "Ignorar"
        },
        label: "Rerrola resultados 1 em Ladinagem, mínimo 1."
      }
    ]
  },

  "Sentido do Perigo": {
    effects: [
      {
        id: "sentido-perigo-agilidade-iniciativa-reroll-1",
        type: "roll.rerollFace",
        target: "Agilidade",
        face: 1,
        limit: "all",
        prompt: {
          title: "Sentido do Perigo",
          question: "Este teste de Agilidade é de iniciativa?",
          yesLabel: "Rerrolar todos os 1",
          noLabel: "Ignorar"
        },
        label: "Rerrola todos os resultados 1 em Agilidade para iniciativa."
      }
    ],
    notes: [
      {
        id: "sentido-perigo-surpresa-nota",
        type: "note",
        target: "combat",
        text: "Se uma unidade da qual você faz parte for surpreendida em combate, o oponente não recebe +1D em Luta ou Pontaria pela surpresa."
      }
    ]
  },

  "Sentidos Aguçados": {
    effects: [
      {
        id: "sentidos-agucados-percepcao-notar-reroll-1",
        type: "roll.rerollFace",
        target: "Percepção",
        face: 1,
        limitFromSpecializationBonus: {
          ability: "Percepção",
          specialization: "Notar"
        },
        minimum: 1,
        prompt: {
          title: "Sentidos Aguçados",
          question: "Este teste de Percepção é para Notar?",
          yesLabel: "Rerrolar 1",
          noLabel: "Ignorar"
        },
        label: "Rerrola resultados 1 em Percepção para Notar."
      }
    ],
    notes: [
      {
        id: "sentidos-agucados-passivo-nota",
        type: "note",
        target: "manual",
        text: "Aumente Percepção passiva em número igual às graduações de Astúcia."
      }
    ]
  },

  "Sangue dos Homens de Ferro": {
    effects: [
      {
        id: "sangue-homens-ferro-luta-mais-1d",
        type: "roll.rank",
        target: "Luta",
        value: 1,
        prompt: {
          title: "Sangue dos Homens de Ferro",
          question: "Usar Sangue dos Homens de Ferro? Uma vez por encontro: +1D em Luta.",
          yesLabel: "Aplicar +1D",
          noLabel: "Ignorar"
        },
        label: "+1D em Luta uma vez por encontro."
      },
      {
        id: "sangue-homens-ferro-atletismo-mar-reroll-1",
        type: "roll.rerollFace",
        target: "Atletismo",
        face: 1,
        limitFromBonusDice: true,
        minimum: 1,
        prompt: {
          title: "Sangue dos Homens de Ferro",
          question: "Este teste de Atletismo ocorre no mar ou em um navio?",
          yesLabel: "Rerrolar 1",
          noLabel: "Ignorar"
        },
        label: "Rerrola resultados 1 em Atletismo no mar ou em navios."
      }
    ],
    notes: [
      {
        id: "sangue-homens-ferro-controle-nota",
        type: "note",
        target: "manual",
        text: "Controle manual: +1D em Luta apenas uma vez por encontro de combate."
      }
    ]
  },

  "Herdeiro": {
    effects: [
      {
        id: "herdeiro-status-mais-1-resultado",
        type: "roll.result",
        target: "Status",
        value: 1,
        label: "+1 no resultado de Status."
      }
    ]
  },

  "Líder de Casa": {
    effects: [
      {
        id: "lider-casa-status-mais-2-resultado",
        type: "roll.result",
        target: "Status",
        value: 2,
        label: "+2 no resultado de Status."
      }
    ]
  },

  "Sangue dos Primeiros Homens": {
    effects: [
      {
        id: "sangue-primeiros-homens-vigor-mais-2-resultado",
        type: "roll.result",
        target: "Vigor",
        value: 2,
        label: "+2 no resultado de Vigor."
      },
      {
        id: "sangue-primeiros-homens-saude-mais-2",
        type: "stat.modifier",
        target: "health",
        mode: "add",
        value: 2,
        label: "Saúde +2."
      }
    ]
  },

  "Sangue do Roinar": {
    effects: [
      {
        id: "sangue-roinar-defesa-combate-mais-2",
        type: "stat.modifier",
        target: "combatDefense",
        mode: "add",
        value: 2,
        label: "Defesa em Combate +2."
      },
      {
        id: "sangue-roinar-guerra-tatica-reroll-1",
        type: "roll.rerollFace",
        target: "Guerra",
        face: 1,
        limitFromAbility: "Astúcia",
        prompt: {
          title: "Sangue do Roinar",
          question: "Este teste de Guerra é de Tática?",
          yesLabel: "Rerrolar 1",
          noLabel: "Ignorar"
        },
        label: "Rerrola resultados 1 em Tática, limitado por Astúcia."
      }
    ],
    notes: [
      {
        id: "sangue-roinar-tatica-nota",
        type: "note",
        target: "roll",
        text: "Ao testar Tática, pode rolar novamente resultados 1 em quantidade igual à Astúcia."
      }
    ]
  },
  "Rápido": {
    effects: [
      {
        id: "rapido-movimento-base-5",
        type: "stat.modifier",
        target: "movement",
        mode: "set",
        value: 5,
        label: "Movimento inicial 5m."
      },
      {
        id: "rapido-corrida-multiplicador-5",
        type: "stat.modifier",
        target: "runMultiplier",
        mode: "set",
        value: 5,
        label: "Corrida = 5 x Movimento."
      }
    ],
    notes: [
      {
        id: "rapido-movimento-nota",
        type: "note",
        target: "movement",
        text: "Movimento inicial 5m; corrida = 5 x Movimento."
      }
    ]
  },

  "Sagrado": {
    effects: [
      {
        id: "sagrado-status-mais-2-resultado",
        type: "roll.result",
        target: "Status",
        value: 2,
        label: "+2 no resultado de Status."
      }
    ],
    notes: [
      {
        id: "sagrado-manobra-diaria-nota",
        type: "note",
        target: "manual",
        text: "Uma vez por dia, ação livre: Defesa em Combate, Defesa em Intriga e resultados passivos +5 até o início do próximo turno."
      }
    ]
  },

  "Irmão da Patrulha da Noite": {
    effects: [
      {
        id: "irmao-patrulha-noite-status-menos-2d",
        type: "roll.rank",
        target: "Status",
        value: -2,
        label: "-2D em Status."
      }
    ],
    notes: [
      {
        id: "irmao-patrulha-beneficios-nota",
        type: "note",
        target: "manual",
        text: "Benefícios da ordem ficam manuais por enquanto: Patrulheiro usa Astúcia em Sobrevivência; Construtor recebe Ofício; Intendente usa Administração em Persuasão."
      }
    ]
  },

  "Membro da Guarda Real": {
    effects: [
      {
        id: "membro-guarda-real-compostura-mais-2",
        type: "stat.modifier",
        target: "composure",
        mode: "add",
        value: 2,
        label: "Compostura +2."
      }
    ],
    notes: [
      {
        id: "membro-guarda-real-status-nota",
        type: "note",
        target: "manual",
        text: "Status deve ser ajustado para 5 manualmente se ainda não for."
      },
      {
        id: "membro-guarda-real-protecao-nota",
        type: "note",
        target: "combat",
        text: "Ao proteger o rei, rainha ou família real: +2 em Luta."
      }
    ]
  },

  "Meistre": {
    effects: [
      {
        id: "meistre-conhecimento-astucia-resultado",
        type: "roll.result",
        target: "Conhecimento",
        valueFromAbility: "Astúcia",
        label: "Adiciona Astúcia ao resultado de Conhecimento."
      },
      {
        id: "meistre-vontade-astucia-resultado",
        type: "roll.result",
        target: "Vontade",
        valueFromAbility: "Astúcia",
        label: "Adiciona Astúcia ao resultado de Vontade."
      }
    ],
    notes: [
      {
        id: "meistre-sorte-casa-nota",
        type: "note",
        target: "story",
        text: "É imune à sorte da casa onde nasceu, mas sofre a sorte da casa à qual foi designado."
      },
      {
        id: "meistre-fortuna-nota",
        type: "note",
        target: "destiny",
        text: "Escolher esta qualidade resulta na perda das outras Qualidades de Fortuna, recuperando Pontos de Destino investidos nelas."
      }
    ]
  },

  "Dançarino da Água I": {
    effects: [
      {
        id: "dancarino-agua-i-percepcao-luta-resultado",
        type: "roll.result",
        target: "Percepção",
        valueFromAbility: "Luta",
        label: "Adiciona Luta ao resultado de Percepção."
      }
    ],
    notes: [
      {
        id: "dancarino-agua-i-passivo-percepcao-nota",
        type: "note",
        target: "manual",
        text: "Também adiciona Luta ao resultado passivo de Percepção."
      }
    ]
  },

  "Dançarino da Água II": {
    effects: [
      {
        id: "dancarino-agua-ii-agilidade-luta-resultado",
        type: "roll.result",
        target: "Agilidade",
        valueFromAbility: "Luta",
        label: "Adiciona Luta ao resultado de Agilidade."
      }
    ]
  },

  "Dançarino da Água III": {
    effects: [
      {
        id: "dancarino-agua-iii-defesa-combate-esgrima",
        type: "stat.modifier",
        target: "combatDefense",
        mode: "add",
        valueFromSpecializationBonus: {
          ability: "Luta",
          specialization: "Esgrima"
        },
        label: "Defesa em Combate + bônus de Esgrima enquanto estiver com arma de Esgrima e sem armadura de Volume 1+."
      }
    ],
    notes: [
      {
        id: "dancarino-agua-iii-condicoes-nota",
        type: "note",
        target: "combatDefense",
        text: "Dançarino da Água III só vale se estiver armado com uma arma de Esgrima, puder adicionar Percepção à Defesa em Combate e não estiver usando armadura com Volume 1 ou maior."
      }
    ]
  },

  "Defesa Acrobática": {
    notes: [
      {
        id: "defesa-acrobatica-manobra-nota",
        type: "note",
        target: "combatDefense",
        text: "Na aba Combate, use o controle Defesa Acrobática para ativar a manobra. Ela adiciona 2 × o bônus de Acrobacia à Defesa em Combate até o início do próximo turno. Não funciona com armadura ou escudo de Volume 1 ou maior."
      }
    ]
  },


  "Traiçoeiro": {
    effects: [
      {
        id: "traicoeiro-enganacao-astucia-intriga-resultado",
        type: "roll.result",
        target: "Enganação",
        valueFromAbility: "Astúcia",
        prompt: {
          title: "Traiçoeiro",
          question: "Está em uma intriga?",
          yesLabel: "Aplicar Astúcia",
          noLabel: "Ignorar"
        },
        label: "Adiciona Astúcia ao resultado de Enganação durante intrigas."
      }
    ]
  },

  "Furtivo": {
    effects: [
      {
        id: "furtivo-furtividade-reroll-1",
        type: "roll.rerollFace",
        target: "Furtividade",
        face: 1,
        label: "Rerrola resultados 1 em Furtividade."
      },
      {
        id: "furtivo-esgueirar-agilidade-resultado",
        type: "roll.result",
        target: "Furtividade",
        valueFromAbility: "Agilidade",
        prompt: {
          title: "Furtivo",
          question: "Este teste é para Esgueirar-se?",
          yesLabel: "Aplicar Agilidade",
          noLabel: "Ignorar"
        },
        label: "Adiciona Agilidade ao resultado de Furtividade para Esgueirar-se."
      }
    ]
  },

  "Rosto na Multidão": {
    effects: [
      {
        id: "rosto-multidao-mesclar-astucia-resultado",
        type: "roll.result",
        target: "Furtividade",
        valueFromAbility: "Astúcia",
        prompt: {
          title: "Rosto na Multidão",
          question: "Este teste é para Mesclar-se?",
          yesLabel: "Aplicar Astúcia",
          noLabel: "Ignorar"
        },
        label: "Adiciona Astúcia ao resultado de Furtividade para Mesclar-se."
      }
    ],
    notes: [
      {
        id: "rosto-multidao-acao-livre-nota",
        type: "note",
        target: "manual",
        text: "Usar Furtividade para Mesclar-se é uma ação livre."
      }
    ]
  },

  "Grande Caçador": {
    effects: [
      {
        id: "grande-cacador-luta-animal-sobrevivencia-resultado",
        type: "roll.result",
        target: "Luta",
        valueFromAbility: "Sobrevivência",
        prompt: {
          title: "Grande Caçador",
          question: "Este ataque é contra um animal?",
          yesLabel: "Aplicar Sobrevivência",
          noLabel: "Ignorar"
        },
        label: "Adiciona Sobrevivência ao resultado de Luta contra animais."
      },
      {
        id: "grande-cacador-pontaria-animal-sobrevivencia-resultado",
        type: "roll.result",
        target: "Pontaria",
        valueFromAbility: "Sobrevivência",
        prompt: {
          title: "Grande Caçador",
          question: "Este ataque é contra um animal?",
          yesLabel: "Aplicar Sobrevivência",
          noLabel: "Ignorar"
        },
        label: "Adiciona Sobrevivência ao resultado de Pontaria contra animais."
      }
    ],
    notes: [
      {
        id: "grande-cacador-cacar-nota",
        type: "note",
        target: "manual",
        text: "Em testes de Sobrevivência para caçar, pode tratar 1 dado de bônus como dado de teste."
      }
    ]
  },

  "Pugilista II": {
    effects: [
      {
        id: "pugilista-ii-luta-punhos-atletismo-resultado",
        type: "roll.result",
        target: "Luta",
        valueFromAbility: "Atletismo",
        prompt: {
          title: "Pugilista II",
          question: "Este ataque é com os punhos?",
          yesLabel: "Aplicar Atletismo",
          noLabel: "Ignorar"
        },
        label: "Adiciona Atletismo ao resultado de Luta em ataques com os punhos."
      }
    ],
    notes: [
      {
        id: "pugilista-ii-poderoso-nota",
        type: "note",
        target: "combat",
        text: "Ataques com os punhos recebem Poderoso."
      }
    ]
  },

  "Sangue de Valyria": {
    effects: [
      {
        id: "sangue-valyria-persuasao-mais-2-resultado",
        type: "roll.result",
        target: "Persuasão",
        value: 2,
        label: "+2 no resultado de Persuasão, incluindo Intimidar."
      }
    ],
    notes: [
      {
        id: "sangue-valyria-fogo-calor-nota",
        type: "note",
        target: "manual",
        text: "Vigor passivo +2 contra fogo ou calor."
      },
      {
        id: "sangue-valyria-intriga-status-nota",
        type: "note",
        target: "intrigue",
        text: "Antes de entrar em intriga, Status conta como 1 graduação a mais para iniciar intriga verdadeira."
      }
    ]
  },

  "Talentoso": {
    allowMultiple: true,
    configs: [
      {
        type: "trait.config",
        key: "chosenAbility",
        label: "Habilidade afetada",
        input: "ability",
        required: true
      }
    ],
    effects: [
      {
        id: "talentoso-habilidade-escolhida-mais-1-resultado",
        type: "roll.result",
        targetFromConfig: "chosenAbility",
        value: 1,
        label: "+1 no resultado da habilidade escolhida."
      }
    ]
  },

  "Carismático": {
    allowMultiple: true,
    configs: [
      {
        type: "trait.config",
        key: "chosenSpecialty",
        label: "Especialidade de Persuasão",
        input: "specialty",
        ability: "Persuasão",
        required: true
      }
    ],
    effects: [
      {
        id: "carismatico-persuasao-especialidade-mais-2-resultado",
        type: "roll.result",
        target: {
          ability: "Persuasão",
          specializationFromConfig: "chosenSpecialty"
        },
        value: 2,
        label: "+2 no resultado de Persuasão com a especialidade escolhida."
      }
    ]
  },

  "Especialista": {
    allowMultiple: true,
    configs: [
      {
        type: "trait.config",
        key: "chosenAbility",
        label: "Habilidade",
        input: "ability",
        required: true
      },
      {
        type: "trait.config",
        key: "chosenSpecialty",
        label: "Especialidade",
        input: "specialty",
        required: true,
        placeholder: "Ex.: Espadas, Memória, Esgueirar-se"
      }
    ],
    effects: [
      {
        id: "especialista-especialidade-mais-1d",
        type: "roll.rank",
        target: {
          abilityFromConfig: "chosenAbility",
          specializationFromConfig: "chosenSpecialty"
        },
        value: 1,
        label: "+1D em testes da especialidade escolhida."
      }
    ]
  },

  "Atleta Nato": {
    allowMultiple: true,
    configs: [
      {
        type: "trait.config",
        key: "chosenSpecialty",
        label: "Especialidade de Atletismo",
        input: "specialty",
        ability: "Atletismo",
        required: true
      }
    ],
    effects: [
      {
        id: "atleta-nato-converter-bonus-atletismo",
        type: "roll.convertBonusToRank",
        target: {
          ability: "Atletismo",
          specializationFromConfig: "chosenSpecialty"
        },
        amount: "half",
        rounding: "floor",
        minimum: 1,
        label: "Converte metade dos dados de bônus da especialidade escolhida em dados de teste."
      }
    ]
  },

  "Contatos": {
    allowMultiple: true,
    configs: [
      {
        type: "trait.config",
        key: "chosenLocation",
        label: "Região ou cidade",
        input: "text",
        required: true,
        placeholder: "Ex.: Porto Real, Vilavelha, Braavos"
      }
    ],
    effects: [
      {
        id: "contatos-conhecimento-local-mais-1d",
        type: "roll.rank",
        target: "Conhecimento",
        value: 1,
        prompt: {
          title: "Contatos",
          question: "Este teste de Conhecimento é no local dos seus Contatos?",
          yesLabel: "Aplicar +1D",
          noLabel: "Ignorar"
        },
        label: "+1D em Conhecimento no local escolhido."
      }
    ]
  },

  "Especialista em Terreno": {
    allowMultiple: true,
    configs: [
      {
        type: "trait.config",
        key: "chosenTerrain",
        label: "Terreno escolhido",
        input: "choice",
        required: true,
        options: [
          { value: "Colinas", label: "Colinas" },
          { value: "Desertos", label: "Desertos" },
          { value: "Florestas", label: "Florestas" },
          { value: "Montanhas", label: "Montanhas" },
          { value: "Pântanos", label: "Pântanos" },
          { value: "Planícies", label: "Planícies" },
          { value: "Terras Costeiras", label: "Terras Costeiras" }
        ]
      }
    ],
    effects: [
      {
        id: "especialista-terreno-sobrevivencia-educacao-resultado",
        type: "roll.result",
        target: "Sobrevivência",
        valueFromSpecializationBonus: {
          ability: "Conhecimento",
          specialization: "Educação"
        },
        prompt: {
          title: "Especialista em Terreno",
          question: "Este teste de Sobrevivência ocorre no terreno escolhido por Especialista em Terreno?",
          yesLabel: "Aplicar Educação",
          noLabel: "Ignorar"
        },
        label: "Adiciona os dados de bônus de Educação ao resultado de Sobrevivência no terreno escolhido."
      }
    ],
    notes: [
      {
        id: "especialista-terreno-movimento-nota",
        type: "note",
        target: "movement",
        text: "Não sofre penalidades em Movimento ao mover-se pelo terreno escolhido."
      }
    ]
  },

  "Durão": {
    effects: [
      {
        id: "durao-saude-resistencia",
        type: "stat.modifier",
        target: "health",
        mode: "add",
        valueFromSpecializationBonus: {
          ability: "Vigor",
          specialization: "Resistência"
        },
        label: "Saúde + bônus de Resistência."
      }
    ]
  },

  "Teimoso": {
    effects: [
      {
        id: "teimoso-compostura-dedicacao",
        type: "stat.modifier",
        target: "composure",
        mode: "add",
        valueFromSpecializationBonus: {
          ability: "Vontade",
          specialization: "Dedicação"
        },
        label: "Compostura + bônus de Dedicação."
      }
    ]
  },

  "Sinistro": {
    notes: [
      {
        id: "sinistro-primeira-rodada-nota",
        type: "note",
        target: "combat-intrigue",
        text: "Na primeira rodada de cada combate ou intriga, adicione manualmente +2 à Defesa em Combate e à Defesa em Intriga. Não foi automatizado como bônus permanente para não ficar ativo fora da primeira rodada."
      }
    ]
  },

  "Foco em Conhecimento": {
    allowMultiple: true,
    configs: [
      {
        type: "trait.config",
        key: "chosenSpecialty",
        label: "Área de estudo",
        input: "choice",
        required: true,
        options: [
          { value: "Alquimia", label: "Alquimia" },
          { value: "Arquitetura", label: "Arquitetura" },
          { value: "Astronomia", label: "Astronomia" },
          { value: "Geografia", label: "Geografia" },
          { value: "Heráldica", label: "Heráldica" },
          { value: "História e Lendas", label: "História e Lendas" },
          { value: "Magia", label: "Magia" },
          { value: "Natureza", label: "Natureza" },
          { value: "Religião", label: "Religião" },
          { value: "Submundo", label: "Submundo" }
        ]
      }
    ],
    effects: [
      {
        id: "foco-conhecimento-converter-bonus",
        type: "roll.convertBonusToRank",
        target: {
          ability: "Conhecimento",
          specializationFromConfig: "chosenSpecialty"
        },
        amount: "all",
        label: "Converte todos os dados de bônus da área escolhida em dados de teste."
      }
    ]
  },


  "Maestria em Arma": {
    allowMultiple: true,
    configs: [
      {
        type: "trait.config",
        key: "chosenWeapon",
        label: "Arma escolhida",
        input: "weapon",
        required: true
      }
    ],
    effects: [
      {
        id: "maestria-arma-dano-mais-1",
        type: "weapon.damage",
        targetFromConfig: "chosenWeapon",
        value: 1,
        label: "Maestria em Arma: +1 dano efetivo."
      }
    ]
  },

  "Maestria em Arma Aprimorada": {
    allowMultiple: true,
    configs: [
      {
        type: "trait.config",
        key: "chosenWeapon",
        label: "Arma aprimorada",
        input: "weaponWithMastery",
        required: true
      }
    ],
    effects: [
      {
        id: "maestria-arma-aprimorada-dano-mais-1",
        type: "weapon.damage",
        targetFromConfig: "chosenWeapon",
        value: 1,
        label: "Maestria em Arma Aprimorada: +1 dano efetivo adicional."
      }
    ]
  },

  "Maestria em Armadura": {
    effects: [
      {
        id: "maestria-armadura-va-mais-1",
        type: "stat.modifier",
        target: "armorValue",
        mode: "add",
        value: 1,
        label: "+1 VA da armadura."
      },
      {
        id: "maestria-armadura-volume-armadura-menos-1",
        type: "stat.modifier",
        target: "armorBulk",
        mode: "add",
        value: -1,
        minimum: 0,
        label: "Volume da armadura -1 para calcular movimento."
      }
    ]
  },

  "Maestria em Armadura Aprimorada": {
    effects: [
      {
        id: "maestria-armadura-aprimorada-va-mais-1",
        type: "stat.modifier",
        target: "armorValue",
        mode: "add",
        value: 1,
        label: "+1 VA adicional da armadura."
      },
      {
        id: "maestria-armadura-aprimorada-penalidade-menos-1",
        type: "stat.modifier",
        target: "armorPenalty",
        mode: "add",
        value: -1,
        minimum: 0,
        label: "Penalidade de Armadura -1."
      }
    ]
  },

  "Maestria em Escudo": {
    effects: [
      {
        id: "maestria-escudo-bonus-defesa-escudos",
        type: "stat.modifier",
        target: "defenseBonus",
        mode: "add",
        valueFromSpecializationBonus: {
          ability: "Luta",
          specialization: "Escudos"
        },
        capByBaseValue: true,
        label: "Bônus Defensivo do escudo + Escudos, até no máximo dobrar o bônus base."
      }
    ]
  },
  "Memória Eidética": {
    effects: [
      {
        id: "memoria-eidetica-converter-bonus-memoria",
        type: "roll.convertBonusToRank",
        target: {
          ability: "Astúcia",
          specialization: "Memória"
        },
        amount: "all",
        label: "Converte os dados de bônus de Memória em dados de teste."
      }
    ]
  },

  "Cosmopolita": {
    effects: [
      {
        id: "cosmopolita-persuasao-nao-nativo-mais-2b",
        type: "roll.bonus",
        target: "Persuasão",
        value: 2,
        prompt: {
          title: "Cosmopolita",
          question: "O alvo não é nativo dos Sete Reinos?",
          yesLabel: "Aplicar +2B",
          noLabel: "Ignorar"
        },
        label: "+2B em Persuasão com pessoas que não sejam nativas dos Sete Reinos."
      }
    ]
  },

  "Favorito da Nobreza": {
    effects: [
      {
        id: "favorito-nobreza-persuasao-status-4-mais-1b",
        type: "roll.bonus",
        target: "Persuasão",
        value: 1,
        prompt: {
          title: "Favorito da Nobreza",
          question: "O alvo tem Status 4 ou maior?",
          yesLabel: "Aplicar +1B",
          noLabel: "Ignorar"
        },
        label: "+1B em Persuasão com personagens de Status 4 ou maior."
      }
    ]
  },

  "Favorito da Plebe": {
    effects: [
      {
        id: "favorito-plebe-persuasao-status-3-menor-mais-1b",
        type: "roll.bonus",
        target: "Persuasão",
        value: 1,
        prompt: {
          title: "Favorito da Plebe",
          question: "O alvo tem Status 3 ou menor?",
          yesLabel: "Aplicar +1B",
          noLabel: "Ignorar"
        },
        label: "+1B em Persuasão com personagens de Status 3 ou menor."
      }
    ]
  },

  "Pio": {
    configs: [
      {
        type: "trait.config",
        key: "chosenFaith",
        label: "Fé, deus ou princípio",
        input: "text",
        required: true,
        placeholder: "Ex.: Os Sete, R'hllor, o Antigo Caminho"
      }
    ],
    notes: [
      {
        id: "pio-bencao-diaria-nota",
        type: "note",
        target: "manual",
        text: "Uma vez por dia, antes de fazer um teste, pode receber +1D."
      }
    ]
  },

  "Sangue dos Ândalos": {
    configs: [
      {
        type: "trait.config",
        key: "chosenAbility",
        label: "Habilidade escolhida",
        input: "ability",
        required: true,
        abilityMinimum: 3
      }
    ],
    effects: [
      {
        id: "sangue-andalos-mais-2-diario-resultado",
        type: "roll.result",
        target: "*",
        value: 2,
        prompt: {
          title: "Sangue dos Ândalos",
          question: "Usar Sangue dos Ândalos para adicionar +2 ao resultado deste teste? Controle manual: uma vez por dia.",
          yesLabel: "Adicionar +2",
          noLabel: "Ignorar"
        },
        label: "Uma vez por dia, adiciona +2 ao resultado de um teste."
      },
      {
        id: "sangue-andalos-habilidade-escolhida-reroll-any",
        type: "roll.rerollAnyDie",
        targetFromConfig: "chosenAbility",
        limit: 1,
        prompt: {
          title: "Sangue dos Ândalos",
          question: "Usar Sangue dos Ândalos para rerrolar um dado da habilidade escolhida? Você deve aceitar o segundo resultado, mesmo se for pior.",
          yesLabel: "Escolher dado",
          noLabel: "Ignorar"
        },
        label: "Rerrola um dado da habilidade escolhida e aceita o segundo resultado."
      }
    ],
    notes: [
      {
        id: "sangue-andalos-mais-2-diario-nota",
        type: "note",
        target: "manual",
        text: "Controle manual: o bônus de +2 deve ser usado apenas uma vez por dia."
      },
      {
        id: "sangue-andalos-rerrolagem-nota",
        type: "note",
        target: "manual",
        text: "Na habilidade escolhida, pode rerrolar um único dado e deve aceitar o segundo resultado, mesmo se for pior."
      }
    ]
  }
};

const TRAIT_AUTOMATION = {
  ...DEFECT_AUTOMATION,
  ...QUALITY_AUTOMATION
};

const AUTOMATION_BY_NORMALIZED_NAME = Object.entries(TRAIT_AUTOMATION).reduce((accumulator, [name, automation]) => {
  accumulator[normalizeTraitName(name)] = {
    name,
    ...automation
  };

  return accumulator;
}, {});

export function getTraitAutomationByName(name) {
  const normalizedName = normalizeTraitName(name);
  const automation = AUTOMATION_BY_NORMALIZED_NAME[normalizedName];

  if (!automation) {
    return {
      effects: [],
      configs: [],
      notes: []
    };
  }

  return {
    effects: cloneData(automation.effects ?? []),
    configs: cloneData(automation.configs ?? []),
    notes: cloneData(automation.notes ?? []),
    allowMultiple: Boolean(automation.allowMultiple)
  };
}

export function hasTraitAutomation(name) {
  const normalizedName = normalizeTraitName(name);

  return Boolean(AUTOMATION_BY_NORMALIZED_NAME[normalizedName]);
}

export function hydrateTraitAutomation(trait) {
  const automation = getTraitAutomationByName(trait?.name);

  const existingEffects = Array.isArray(trait?.effects) ? trait.effects : [];
  const existingConfigs = Array.isArray(trait?.configs) ? trait.configs : [];
  const existingNotes = Array.isArray(trait?.notes) ? trait.notes : [];

  return {
    effects: existingEffects.length > 0 ? cloneData(existingEffects) : automation.effects,
    configs: existingConfigs.length > 0 ? cloneData(existingConfigs) : automation.configs,
    notes: existingNotes.length > 0 ? cloneData(existingNotes) : automation.notes,
    allowMultiple: Boolean(automation.allowMultiple),
    automationVersion: TRAIT_AUTOMATION_VERSION
  };
}