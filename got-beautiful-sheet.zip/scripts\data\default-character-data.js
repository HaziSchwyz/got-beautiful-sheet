export function getDefaultCharacterData() {
  return {
    meta: {
      schemaVersion: 5,
      sheetType: "character",
      createdByModule: "got-beautiful-sheet"
    },

    visuals: {
      portrait: "",
      mapToken: "",

      /*
       * Campos antigos mantidos por compatibilidade temporária.
       * A interface nova vai trocar "Brasão" por "Estandarte",
       * mas manter este campo evita quebrar ficha antiga antes da migração completa.
       */
      houseCrest: "",

      theme: "royal-dark",
      frameStyle: "simple",

      /*
       * Sistema novo de Heráldica.
       *
       * themeBanner:
       * - usado como marca d'água/fundo do tema.
       *
       * houseBanner:
       * - estandarte da casa do personagem.
       *
       * personalBanner:
       * - estandarte próprio do personagem.
       *
       * bannerDisplaySource:
       * - define qual aparece no topo direito da ficha.
       * - valores possíveis: "theme", "house", "personal".
       */
      themeBanner: "",
      houseBanner: "",
      personalBanner: "",
      bannerDisplaySource: "theme",

      colors: {
        primary: "#07111C",
        secondary: "#0A1D2C",
        accent: "#8A2E24",
        coldAccent: "#2AA6B8",
        textMain: "#F2E7D8"
      }
    },

    identity: {
      name: "",
      house: "",
      player: "",
      age: "",
      sex: "",
      concept: "",
      description: "",
      statusTitle: ""
    },

    personality: {
      objective: "",
      motivation: "",
      virtue: "",
      vice: "",
      notes: ""
    },

    valyrian: {
      enabled: false,
      hasValyrianBlood: false,
      canRideDragon: false,
      lineage: "",
      valyrianHouse: "",
      linkedDragonUuid: "",
      linkedDragonName: "",
      draconicBondNotes: ""
    },

    destinyPoints: {
      total: 0,
      available: 0,
      spent: 0,
      invested: 0
    },

    abilities: [
      { id: "agilidade", name: "Agilidade", group: "Físicas", rank: 2, specialties: "", specializations: [] },
      { id: "atletismo", name: "Atletismo", group: "Físicas", rank: 2, specialties: "", specializations: [] },
      { id: "furtividade", name: "Furtividade", group: "Físicas", rank: 2, specialties: "", specializations: [] },
      { id: "luta", name: "Luta", group: "Físicas", rank: 2, specialties: "", specializations: [] },
      { id: "pontaria", name: "Pontaria", group: "Físicas", rank: 2, specialties: "", specializations: [] },
      { id: "vigor", name: "Vigor", group: "Físicas", rank: 2, specialties: "", specializations: [] },

      { id: "astucia", name: "Astúcia", group: "Mentais", rank: 2, specialties: "", specializations: [] },
      { id: "conhecimento", name: "Conhecimento", group: "Mentais", rank: 2, specialties: "", specializations: [] },
      { id: "cura", name: "Cura", group: "Mentais", rank: 2, specialties: "", specializations: [] },
      { id: "guerra", name: "Guerra", group: "Mentais", rank: 2, specialties: "", specializations: [] },
      { id: "percepcao", name: "Percepção", group: "Mentais", rank: 2, specialties: "", specializations: [] },
      { id: "sobrevivencia", name: "Sobrevivência", group: "Mentais", rank: 2, specialties: "", specializations: [] },
      { id: "vontade", name: "Vontade", group: "Mentais", rank: 2, specialties: "", specializations: [] },

      { id: "enganacao", name: "Enganação", group: "Sociais", rank: 2, specialties: "", specializations: [] },
      { id: "idioma", name: "Idioma", group: "Sociais", rank: 2, specialties: "", specializations: [] },
      { id: "ladinagem", name: "Ladinagem", group: "Sociais", rank: 2, specialties: "", specializations: [] },
      { id: "lidar-com-animais", name: "Lidar com Animais", group: "Sociais", rank: 2, specialties: "", specializations: [] },
      { id: "persuasao", name: "Persuasão", group: "Sociais", rank: 2, specialties: "", specializations: [] },
      { id: "status", name: "Status", group: "Sociais", rank: 2, specialties: "", specializations: [] }
    ],

    derived: {
      movementBase: 4,
      runMultiplier: 4,
      defenseBonus: 0
    },

    combat: {
      combatDefense: { value: 6, max: 6 },
      health: { value: 6, max: 6 },
      movement: 4,
      run: 16,
      wounds: { value: 0, max: 0 },
      injuries: { value: 0, max: 0 },

      armor: {
        name: "",
        value: "",
        penalty: "",
        bulk: ""
      },

      weapons: [
        {
          id: crypto.randomUUID(),
          name: "",
          ability: "",
          specialty: "",
          test: "",
          damage: "",
          qualities: "",
          bulk: 0,
          carried: true,
          notes: ""
        }
      ]
    },

    intrigue: {
      intrigueDefense: { value: 6, max: 6 },
      composure: { value: 6, max: 6 },
      victories: { value: 0, max: 0 },
      frustrations: { value: 0, max: 2 },
      techniques: "",
      notes: ""
    },

    flaws: [],

    traits: {
      qualities: [],
      defects: []
    },

    inventory: {
      items: [
        {
          id: crypto.randomUUID(),
          name: "",
          category: "Equipamento",
          quantity: 1,
          price: "",
          bulk: 0,
          carried: true,
          notes: ""
        }
      ],

      personalEquipment: "",
      possessions: "",
      money: "",
      importantItems: "",
      notes: ""
    },

    appearance: {
      height: "",
      weight: "",
      eyes: "",
      hair: "",
      distinguishingMarks: "",
      details: ""
    },

    story: {
      history: "",
      oaths: "",
      obligations: "",
      allies: "",
      enemies: "",
      notes: ""
    }
  };
}