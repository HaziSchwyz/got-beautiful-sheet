import { DragonSheetApp } from "./apps/dragon-sheet-app.js";
import { CharacterSheetApp } from "./apps/character-sheet-app.js";
import { QualityItemSheet, getDefaultQualitySystem, isTraitItem } from "./apps/quality-item-sheet.js";

const MODULE_ID = "got-beautiful-sheet";

class GotDragonActorSheet extends ActorSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["got-beautiful-sheet", "got-dragon-actor-sheet"],
      width: 980,
      height: 820,
      resizable: true
    });
  }

  render(force = false, options = {}) {
    new DragonSheetApp(this.actor).render(true);
    return this;
  }
}

class GotCharacterActorSheet extends ActorSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["got-beautiful-sheet", "got-character-actor-sheet"],
      width: 940,
      height: 820,
      resizable: true
    });
  }

  render(force = false, options = {}) {
    new CharacterSheetApp(this.actor).render(true);
    return this;
  }
}

Hooks.once("init", () => {
  console.log(`${MODULE_ID} | Inicializando mÃ³dulo.`);

  Actors.registerSheet(MODULE_ID, GotDragonActorSheet, {
    types: ["dragon", `${MODULE_ID}.dragon`],
    makeDefault: true,
    label: "DossiÃª DracÃ´nico"
  });

  Actors.registerSheet(MODULE_ID, GotCharacterActorSheet, {
    types: ["character", `${MODULE_ID}.character`],
    makeDefault: true,
    label: "Ficha de Personagem GOT"
  });

  Items.registerSheet(MODULE_ID, QualityItemSheet, {
    types: ["quality", `${MODULE_ID}.quality`, "defect", `${MODULE_ID}.defect`],
    makeDefault: true,
    label: "Qualidade/Defeito"
  });

  Items.registerSheet(MODULE_ID, QualityItemSheet, {
    types: ["equippableItem"],
    makeDefault: false,
    canBeDefault: false,
    label: "Qualidade/Defeito GOT"
  });
});

Hooks.on("preCreateItem", (item) => {
  if (!isTraitItem(item)) return;

  item.updateSource({
    system: getDefaultQualitySystem(item.toObject().system)
  });
});

Hooks.once("ready", () => {
  console.log(`${MODULE_ID} | Pronto. Sistema ativo: ${game.system.id}`);

  if (game.system.id !== "worldbuilding") {
    ui.notifications.warn("GOT Beautiful Sheet foi criado para o sistema worldbuilding.");
  }
});