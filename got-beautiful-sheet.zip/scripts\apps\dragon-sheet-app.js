import { getDefaultDragonData } from "../data/default-dragon-data.js";
import { rollFromTestText } from "../dice.js";

const MODULE_ID = "got-beautiful-sheet";
const DRAGON_FLAG = "dragonData";

function cloneData(data) {
  return foundry.utils.deepClone(data);
}

function mergeWithDefault(data) {
  const defaults = getDefaultDragonData();

  return foundry.utils.mergeObject(defaults, data ?? {}, {
    inplace: false,
    insertKeys: true,
    insertValues: true,
    overwrite: true
  });
}

function getPropertyPathFromInput(input) {
  return input?.dataset?.path ?? input?.name ?? "";
}

function readInputValue(input) {
  if (input.type === "checkbox") return input.checked;
  if (input.type === "number") return Number(input.value || 0);
  return input.value;
}

function setByPath(object, path, value) {
  if (!path) return;

  const parts = path.split(".");
  let target = object;

  while (parts.length > 1) {
    const part = parts.shift();

    if (!target[part] || typeof target[part] !== "object") {
      target[part] = {};
    }

    target = target[part];
  }

  target[parts[0]] = value;
}

function getPlacedTokenDocumentsForActor(actor) {
  if (!canvas?.scene || !actor) return [];

  return canvas.scene.tokens.filter((tokenDocument) => {
    return tokenDocument.actor?.id === actor.id || tokenDocument.actorId === actor.id;
  });
}


function normalizeDragonVisualText(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeDragonVisualKey(value) {
  return normalizeDragonVisualText(value).toLowerCase();
}

function normalizeDragonVisualNumber(value, fallback = 0) {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : fallback;
  }

  const cleaned = String(value ?? "")
    .trim()
    .replace(",", ".")
    .replace(/[^\d.+-]/g, "");

  if (!cleaned) return fallback;

  const numericValue = Number(cleaned);

  return Number.isFinite(numericValue) ? numericValue : fallback;
}

function normalizeDragonColor(value, fallback) {
  const text = String(value ?? "").trim();

  if (/^#[0-9a-fA-F]{6}$/.test(text)) {
    return text;
  }

  return fallback;
}

function getDragonVisualFlags(item) {
  return foundry.utils.getProperty(item, `flags.${MODULE_ID}`) ?? item?.flags?.[MODULE_ID] ?? {};
}

function getDragonVisualFieldValue(item, keys, fallback = "") {
  const flags = getDragonVisualFlags(item);
  const system = item?.system ?? {};

  for (const key of keys) {
    const fromFlags = foundry.utils.getProperty(flags, key);

    if (fromFlags !== undefined && fromFlags !== null && fromFlags !== "") {
      return fromFlags;
    }

    const fromSystem = foundry.utils.getProperty(system, key);

    if (fromSystem !== undefined && fromSystem !== null && fromSystem !== "") {
      return fromSystem;
    }
  }

  return fallback;
}

function isDragonVisualItem(item) {
  const gearType = normalizeDragonVisualKey(getDragonVisualFieldValue(item, [
    "gearType",
    "visualType",
    "tipo",
    "type"
  ]));

  return [
    "dragonvisual",
    "dragon visual",
    "visualdedragao",
    "visual de dragao",
    "visual de dragão",
    "escamasdedragao",
    "escamas de dragao",
    "escamas de dragão"
  ].includes(gearType);
}

function createDragonVisualFromItem(item) {
  if (!item || !isDragonVisualItem(item)) {
    return null;
  }

  const primary = normalizeDragonColor(getDragonVisualFieldValue(item, [
    "colors.primary",
    "primary",
    "corPrincipal",
    "cor principal"
  ]), "#07111c");

  const secondary = normalizeDragonColor(getDragonVisualFieldValue(item, [
    "colors.secondary",
    "secondary",
    "corSecundaria",
    "cor secundária",
    "cor secundaria"
  ]), "#0a1d2c");

  const accent = normalizeDragonColor(getDragonVisualFieldValue(item, [
    "colors.accent",
    "accent",
    "corDestaque",
    "cor de destaque"
  ]), "#d4472f");

  const coldAccent = normalizeDragonColor(getDragonVisualFieldValue(item, [
    "colors.coldAccent",
    "coldAccent",
    "cold",
    "corFria",
    "cor fria",
    "ciano"
  ]), "#2aa6b8");

  const textMain = normalizeDragonColor(getDragonVisualFieldValue(item, [
    "colors.textMain",
    "textMain",
    "textoPrincipal",
    "texto principal"
  ]), "#f2e7d8");

  const scaleOpacity = Math.max(0, Math.min(1, normalizeDragonVisualNumber(getDragonVisualFieldValue(item, [
    "scaleOpacity",
    "opacity",
    "opacidade",
    "forcaTextura",
    "força textura"
  ]), 0.26)));

  const scaleSize = Math.max(8, Math.min(96, Math.trunc(normalizeDragonVisualNumber(getDragonVisualFieldValue(item, [
    "scaleSize",
    "size",
    "tamanhoEscamas",
    "tamanho das escamas"
  ]), 32))));

  return {
    name: normalizeDragonVisualText(item.name) || "Visual de Dragão",
    colors: {
      primary,
      secondary,
      accent,
      coldAccent,
      textMain
    },
    scaleTexture: String(getDragonVisualFieldValue(item, [
      "scaleTexture",
      "texture",
      "textura",
      "texturaEscamas",
      "textura de escamas"
    ], "") ?? "").trim(),
    scaleOpacity,
    scaleSize,
    sourceUuid: String(item.uuid ?? ""),
    sourcePack: String(item.pack ?? "")
  };
}

export class DragonSheetApp extends Application {
  constructor(document, options = {}) {
    super(options);

    this.document = document;
    this.data = mergeWithDefault(this.document.getFlag(MODULE_ID, DRAGON_FLAG));
    this.activeTab = "perfil";
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "got-dragon-dossier",
      classes: ["got-beautiful-sheet", "got-dragon-dossier"],
      title: "Dossiê Dracônico",
      template: "modules/got-beautiful-sheet/templates/dragon-sheet.hbs",
      width: 980,
      height: 820,
      resizable: true
    });
  }

  get title() {
    const name = this.data?.identity?.name || this.document?.name || "Dragão";
    return `Dossiê Dracônico: ${name}`;
  }

  async getData() {
    const linkedRider = await this.getLinkedRider();

    const tabs = {
      perfil: this.activeTab === "perfil",
      combate: this.activeTab === "combate",
      habilidades: this.activeTab === "habilidades",
      qualidades: this.activeTab === "qualidades",
      ferimentos: this.activeTab === "ferimentos",
      visuais: this.activeTab === "visuais",
      notas: this.activeTab === "notas"
    };

    return {
      document: this.document,
      documentName: this.document?.name ?? "",
      data: this.data,
      activeTab: this.activeTab,
      tabs,
      linkedRider,
      isGM: game.user.isGM
    };
  }

  activateListeners(html) {
    super.activateListeners(html);

    html.find("[data-tab-button]").on("click", this._onChangeTab.bind(this));
    html.find("[data-path]").on("change", this._onFieldChange.bind(this));

    html.find("[data-action='save']").on("click", this._onSaveClick.bind(this));
    html.find("[data-action='reset']").on("click", this._onResetClick.bind(this));

    html.find("[data-action='open-rider']").on("click", this._onOpenRider.bind(this));
    html.find("[data-action='pick-image']").on("click", this._onPickImage.bind(this));

    html.find("[data-action='roll-attack']").on("click", this._onRollAttack.bind(this));
    html.find("[data-action='add-attack']").on("click", this._onAddAttack.bind(this));
    html.find("[data-action='remove-attack']").on("click", this._onRemoveAttack.bind(this));

    html.find("[data-action='add-quality']").on("click", this._onAddQuality.bind(this));
    html.find("[data-action='remove-quality']").on("click", this._onRemoveQuality.bind(this));

    html.find("[data-action='add-flaw']").on("click", this._onAddFlaw.bind(this));
    html.find("[data-action='remove-flaw']").on("click", this._onRemoveFlaw.bind(this));

    html.on("dragover", (event) => {
      event.preventDefault();
    });

    html.on("drop", this._onDrop.bind(this));
  }

  async _onDrop(event) {
    const originalEvent = event?.originalEvent ?? event;

    originalEvent?.preventDefault?.();

    let dragData = null;

    try {
      dragData = TextEditor.getDragEventData(originalEvent);
    } catch (error) {
      try {
        dragData = JSON.parse(originalEvent?.dataTransfer?.getData("text/plain") ?? "{}");
      } catch (parseError) {
        dragData = null;
      }
    }

    if (!dragData || dragData.type !== "Item" || !dragData.uuid) {
      return;
    }

    const item = await fromUuid(dragData.uuid);

    if (!item) {
      ui.notifications.warn("Item visual não encontrado.");
      return;
    }

    const dragonVisual = createDragonVisualFromItem(item);

    if (!dragonVisual) {
      ui.notifications.warn("Esse item não é um Visual de Dragão.");
      return;
    }

    if (!this.data.visuals || typeof this.data.visuals !== "object") {
      this.data.visuals = {};
    }

    if (!this.data.visuals.colors || typeof this.data.visuals.colors !== "object") {
      this.data.visuals.colors = {};
    }

    this.data.visuals.dragonVisualName = dragonVisual.name;
    this.data.visuals.sourceUuid = dragonVisual.sourceUuid;
    this.data.visuals.sourcePack = dragonVisual.sourcePack;
    this.data.visuals.scaleTexture = dragonVisual.scaleTexture;
    this.data.visuals.scaleOpacity = dragonVisual.scaleOpacity;
    this.data.visuals.scaleSize = dragonVisual.scaleSize;

    this.data.visuals.colors.primary = dragonVisual.colors.primary;
    this.data.visuals.colors.secondary = dragonVisual.colors.secondary;
    this.data.visuals.colors.accent = dragonVisual.colors.accent;
    this.data.visuals.colors.coldAccent = dragonVisual.colors.coldAccent;
    this.data.visuals.colors.textMain = dragonVisual.colors.textMain;

    this.activeTab = "visuais";

    await this.saveData();

    ui.notifications.info(`Visual de Dragão aplicado: ${dragonVisual.name}`);
    this.render(true);
  }
  async saveData({ notify = false } = {}) {
    await this.document.setFlag(MODULE_ID, DRAGON_FLAG, cloneData(this.data));
    await this.syncActorVisuals();

    if (notify) {
      ui.notifications.info("Dossiê Dracônico salvo e token sincronizado.");
    }
  }

  async syncActorVisuals() {
    if (this.document?.documentName !== "Actor") {
      console.warn(`${MODULE_ID} | O dossiê não está vinculado a um Actor. Token não sincronizado.`);
      return;
    }

    const actor = this.document;

    const actorName = String(this.data?.identity?.name ?? "").trim();
    const mainImage = String(this.data?.visuals?.mainImage ?? "").trim();
    const mapToken = String(this.data?.visuals?.mapToken ?? "").trim();

    const desiredActorImage = mainImage || actor.img;
    const desiredTokenImage = mapToken || mainImage || actor.prototypeToken?.texture?.src || actor.img;

    const actorUpdates = {};

    if (actorName && actor.name !== actorName) {
      actorUpdates.name = actorName;
    }

    if (desiredActorImage && actor.img !== desiredActorImage) {
      actorUpdates.img = desiredActorImage;
    }

    if (desiredTokenImage) {
      actorUpdates["prototypeToken.texture.src"] = desiredTokenImage;
      actorUpdates["prototypeToken.name"] = actorName || actor.name;
      actorUpdates["prototypeToken.actorLink"] = false;
      actorUpdates["prototypeToken.disposition"] = actor.prototypeToken?.disposition ?? 0;
    }

    if (Object.keys(actorUpdates).length > 0) {
      await actor.update(actorUpdates);
      console.log(`${MODULE_ID} | Actor/token prototype atualizado`, actorUpdates);
    }

    const placedTokenDocuments = getPlacedTokenDocumentsForActor(actor);

    for (const tokenDocument of placedTokenDocuments) {
      const tokenUpdates = {};

      if (desiredTokenImage) {
        tokenUpdates["texture.src"] = desiredTokenImage;
      }

      if (actorName) {
        tokenUpdates.name = actorName;
      }

      if (Object.keys(tokenUpdates).length > 0) {
        await tokenDocument.update(tokenUpdates);
      }
    }

    if (placedTokenDocuments.length > 0) {
      console.log(`${MODULE_ID} | Tokens já colocados no mapa atualizados: ${placedTokenDocuments.length}`);
    }
  }

  async getLinkedRider() {
    const uuid = this.data?.rider?.documentUuid;

    if (!uuid) return null;

    try {
      return await fromUuid(uuid);
    } catch (error) {
      console.warn(`${MODULE_ID} | Não foi possível carregar montador vinculado`, error);
      return null;
    }
  }

  async _onChangeTab(event) {
    event.preventDefault();

    const tab = event.currentTarget.dataset.tabButton;
    if (!tab) return;

    this.activeTab = tab;
    this.render(false);
  }

  async _onFieldChange(event) {
    const input = event.currentTarget;
    const path = getPropertyPathFromInput(input);

    if (!path) return;

    const value = readInputValue(input);

    setByPath(this.data, path, value);

    await this.saveData();
  }

  async _onSaveClick(event) {
    event.preventDefault();
    await this.saveData({ notify: true });
  }

  async _onResetClick(event) {
    event.preventDefault();

    const confirmed = await Dialog.confirm({
      title: "Resetar Dossiê Dracônico",
      content: "<p>Isso vai apagar os dados novos salvos nas flags deste dossiê. O Actor original não será apagado.</p>",
      yes: () => true,
      no: () => false,
      defaultYes: false
    });

    if (!confirmed) return;

    this.data = getDefaultDragonData();
    await this.saveData({ notify: true });
    this.render(true);
  }

  async _onOpenRider(event) {
    event.preventDefault();

    const rider = await this.getLinkedRider();

    if (!rider) {
      ui.notifications.warn("Nenhum montador vinculado ou montador inacessível.");
      return;
    }

    rider.sheet?.render(true);
  }

  async _onPickImage(event) {
    event.preventDefault();

    const targetPath = event.currentTarget.dataset.path;
    if (!targetPath) return;

    const current = foundry.utils.getProperty(this.data, targetPath) ?? "";

    new FilePicker({
      type: "image",
      current,
      callback: async (selectedPath) => {
        setByPath(this.data, targetPath, selectedPath);
        await this.saveData({ notify: targetPath === "visuals.mapToken" });
        this.render(false);
      }
    }).render(true);
  }

  async _onRollAttack(event) {
    event.preventDefault();

    const attackId = event.currentTarget.dataset.attackId;
    const attack = this.data.combat.attacks.find((item) => item.id === attackId);

    if (!attack) return;

    await rollFromTestText({
      document: this.document,
      label: attack.name || "Ataque de Dragão",
      testText: attack.test,
      flavor: attack.qualities || ""
    });
  }

  async _onAddAttack(event) {
    event.preventDefault();

    this.data.combat.attacks.push({
      id: crypto.randomUUID(),
      name: "Novo Ataque",
      test: "",
      damage: "",
      qualities: "",
      notes: ""
    });

    await this.saveData();
    this.render(false);
  }

  async _onRemoveAttack(event) {
    event.preventDefault();

    const attackId = event.currentTarget.dataset.attackId;
    this.data.combat.attacks = this.data.combat.attacks.filter((attack) => attack.id !== attackId);

    await this.saveData();
    this.render(false);
  }

  async _onAddQuality(event) {
    event.preventDefault();

    this.data.qualities.push({
      id: crypto.randomUUID(),
      name: "Nova Qualidade",
      type: "Q",
      description: "",
      notes: ""
    });

    await this.saveData();
    this.render(false);
  }

  async _onRemoveQuality(event) {
    event.preventDefault();

    const qualityId = event.currentTarget.dataset.qualityId;
    this.data.qualities = this.data.qualities.filter((quality) => quality.id !== qualityId);

    await this.saveData();
    this.render(false);
  }

  async _onAddFlaw(event) {
    event.preventDefault();

    this.data.flaws.push({
      id: crypto.randomUUID(),
      name: "Novo Defeito",
      type: "D",
      description: "",
      notes: ""
    });

    await this.saveData();
    this.render(false);
  }

  async _onRemoveFlaw(event) {
    event.preventDefault();

    const flawId = event.currentTarget.dataset.flawId;
    this.data.flaws = this.data.flaws.filter((flaw) => flaw.id !== flawId);

    await this.saveData();
    this.render(false);
  }
}