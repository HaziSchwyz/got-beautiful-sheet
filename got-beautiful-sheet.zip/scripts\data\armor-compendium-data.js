export const ARMOR_COMPENDIUM_DATA = [
  {
    grupo: "Armaduras",
    nome: "Roupas",
    valor: 0,
    penalidade: 0,
    volume: 0,
    peso: "—",
    preco: "—",
    notas: "—"
  },
  {
    grupo: "Armaduras",
    nome: "Robes ou Hábito",
    valor: 1,
    penalidade: 0,
    volume: 1,
    peso: "10 kg",
    preco: "3 gp",
    notas: "Na Tabela 7-6 aparece como “Robes”."
  },
  {
    grupo: "Armaduras",
    nome: "Acolchoada",
    valor: 1,
    penalidade: 0,
    volume: 0,
    peso: "5 kg",
    preco: "200 gp",
    notas: "-"
  },
  {
    grupo: "Armaduras",
    nome: "Couro Macio",
    valor: 2,
    penalidade: -1,
    volume: 0,
    peso: "7,5 kg",
    preco: "300 gp",
    notas: "-"
  },
  {
    grupo: "Armaduras",
    nome: "Couro Rígido",
    valor: 3,
    penalidade: -2,
    volume: 0,
    peso: "9 kg",
    preco: "400 gp",
    notas: "-"
  },
  {
    grupo: "Armaduras",
    nome: "Ossos ou Madeira",
    valor: 4,
    penalidade: -3,
    volume: 1,
    peso: "12,5 kg",
    preco: "300 gp",
    notas: "-"
  },
  {
    grupo: "Armaduras",
    nome: "Cota de Anéis",
    valor: 4,
    penalidade: -2,
    volume: 1,
    peso: "10 kg",
    preco: "600 gp",
    notas: "-"
  },
  {
    grupo: "Armaduras",
    nome: "Peles",
    valor: 5,
    penalidade: -3,
    volume: 3,
    peso: "12,5 kg",
    preco: "400 gp",
    notas: "-"
  },
  {
    grupo: "Armaduras",
    nome: "Cota de Malha",
    valor: 5,
    penalidade: -3,
    volume: 2,
    peso: "20 kg",
    preco: "800 gp",
    notas: "-"
  },
  {
    grupo: "Armaduras",
    nome: "Placa de Peito",
    valor: 5,
    penalidade: -2,
    volume: 3,
    peso: "25 kg",
    preco: "800 gp",
    notas: "Na Tabela 7-6 aparece como “Couraça”."
  },
  {
    grupo: "Armaduras",
    nome: "Cota de Escamas",
    valor: 6,
    penalidade: -3,
    volume: 2,
    peso: "15 kg",
    preco: "600 gp",
    notas: "Na Tabela 7-6 aparece como “Cota de Escamas/Moedas”."
  },
  {
    grupo: "Armaduras",
    nome: "Talas",
    valor: 7,
    penalidade: -3,
    volume: 3,
    peso: "25 kg",
    preco: "1.000 gp",
    notas: "-"
  },
  {
    grupo: "Armaduras",
    nome: "Brigantina",
    valor: 8,
    penalidade: -4,
    volume: 3,
    peso: "25 kg",
    preco: "1.200 gp",
    notas: "-"
  },
  {
    grupo: "Armaduras",
    nome: "Meia Armadura",
    valor: 9,
    penalidade: -5,
    volume: 3,
    peso: "20 kg",
    preco: "2.000 gp",
    notas: "-"
  },
  {
    grupo: "Armaduras",
    nome: "Placas",
    valor: 10,
    penalidade: -6,
    volume: 3,
    peso: "25 kg",
    preco: "3.000 gp",
    notas: "-"
  }
];