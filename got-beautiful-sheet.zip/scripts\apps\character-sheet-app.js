﻿import { getDefaultCharacterData } from "../data/default-character-data.js";
import { rollKeepHighest } from "../dice.js";
import { buildDerivedStatsView } from "../data/stat-modifier-engine.js";
import { getTraitAutomationByName, TRAIT_AUTOMATION_VERSION } from "../data/trait-automation-data.js";
import { getTraitSystemView, isDefectItem, isQualityItem, isTraitItem } from "./quality-item-sheet.js";

const MODULE_ID = "got-beautiful-sheet";
const CHARACTER_FLAG = "characterData";

const VALID_BANNER_DISPLAY_SOURCES = ["theme", "house", "personal"];
const VALID_CHARACTER_TABS = ["geral", "habilidades", "combate", "intriga", "qualidades", "inventario", "visuais"];
const REPEATABLE_TRAIT_NAMES = new Set([
  "talentoso",
  "carismático",
  "carismatico",
  "especialista",
  "atleta nato",
  "contatos",
  "especialista em terreno",
  "foco em conhecimento",
  "maestria em arma",
  "maestria em arma aprimorada"
]);
const PENDING_CONFIGURATION_NOTE = "Configuração pendente. A automação desta Qualidade pode precisar ser ajustada manualmente.";
const FALLBACK_ABILITY_OPTIONS = [
  "Agilidade",
  "Astúcia",
  "Atletismo",
  "Conhecimento",
  "Cura",
  "Enganação",
  "Furtividade",
  "Lidar com Animais",
  "Luta",
  "Percepção",
  "Persuasão",
  "Pontaria",
  "Status",
  "Sobrevivência",
  "Vigor",
  "Vontade"
];
const TERRAIN_CONFIG_OPTIONS = [
  "Colinas",
  "Desertos",
  "Florestas",
  "Montanhas",
  "Pântanos",
  "Planícies",
  "Terras Costeiras"
];
const KNOWLEDGE_FOCUS_OPTIONS = [
  "Alquimia",
  "Arquitetura",
  "Astronomia",
  "Geografia",
  "Heráldica",
  "História e Lendas",
  "Magia",
  "Natureza",
  "Religião",
  "Submundo"
];
const ACTIVE_TAB_BY_DOCUMENT = new Map();

function cloneData(data) {
  return foundry.utils.deepClone(data);
}

function normalizeCharacterTab(tab) {
  if (tab === "historia") return "geral";
  return VALID_CHARACTER_TABS.includes(tab) ? tab : "geral";
}

function getActiveTabStorageKey(document) {
  return document?.uuid ?? document?.id ?? "default";
}

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}


function stripAutomationPlaceholderHtml(value) {
  let html = String(value ?? "");

  const placeholderPatterns = [
    /<hr\s*\/?>\s*<p>\s*<em>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/em>\s*<\/p>/gi,
    /<p>\s*<em>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/em>\s*<\/p>/gi,
    /<hr\s*\/?>\s*<p>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/p>/gi,
    /<p>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/p>/gi,
    /<hr\s*\/?>\s*<em>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/em>/gi,
    /<em>\s*Efeitos autom[aá]ticos ainda n[aã]o configurados\.?\s*<\/em>/gi,
    /Efeitos autom[aá]ticos ainda n[aã]o configurados\.?/gi
  ];

  for (const pattern of placeholderPatterns) {
    html = html.replace(pattern, "");
  }

  return html.trim();
}

function createId() {
  return foundry.utils.randomID?.() ?? crypto.randomUUID();
}

function getPersistentActor(document) {
  if (!document || document.documentName !== "Actor") {
    return document;
  }

  if (!document.isToken) {
    return document;
  }

  const baseActor = document.token?.baseActor ?? game.actors?.get(document.id);

  if (baseActor) {
    console.log(`${MODULE_ID} | Actor sintético detectado. Usando Actor real.`, {
      syntheticUuid: document.uuid,
      baseUuid: baseActor.uuid,
      name: baseActor.name
    });

    return baseActor;
  }

  console.warn(`${MODULE_ID} | Actor sintético sem baseActor encontrado. Usando documento original.`, {
    uuid: document.uuid,
    name: document.name
  });

  return document;
}

function mergeWithDefault(data) {
  const defaults = getDefaultCharacterData();

  return foundry.utils.mergeObject(defaults, data ?? {}, {
    inplace: false,
    insertKeys: true,
    insertValues: true,
    overwrite: true
  });
}

function normalizeBannerDisplaySource(value) {
  const source = String(value ?? "theme").trim();

  if (VALID_BANNER_DISPLAY_SOURCES.includes(source)) {
    return source;
  }

  return "theme";
}

function getBannerPathBySource(data, source) {
  const visuals = data?.visuals ?? {};

  if (source === "house") {
    return String(visuals.houseBanner || visuals.houseCrest || "").trim();
  }

  if (source === "personal") {
    return String(visuals.personalBanner || "").trim();
  }

  return String(visuals.themeBanner || "").trim();
}

function getResolvedMainBanner(data) {
  const visuals = data?.visuals ?? {};
  const preferredSource = normalizeBannerDisplaySource(visuals.bannerDisplaySource);

  const preferredPath = getBannerPathBySource(data, preferredSource);

  if (preferredPath) {
    return {
      source: preferredSource,
      path: preferredPath
    };
  }

  const fallbackOrder = ["theme", "house", "personal"];

  for (const source of fallbackOrder) {
    const path = getBannerPathBySource(data, source);

    if (path) {
      return {
        source,
        path
      };
    }
  }

  return {
    source: preferredSource,
    path: ""
  };
}

function getThemeWatermarkBanner(data) {
  return String(data?.visuals?.themeBanner || "").trim();
}

function getBannerSourceLabel(source) {
  switch (source) {
    case "theme":
      return "Estandarte do Tema";

    case "house":
      return "Estandarte da Casa";

    case "personal":
      return "Estandarte Pessoal";

    default:
      return "Estandarte";
  }
}

function cssUrlValue(path) {
  const value = String(path ?? "").trim();

  if (!value) {
    return "none";
  }

  const safeValue = value
    .replaceAll("\\", "/")
    .replaceAll("'", "\\'")
    .replaceAll("\n", "")
    .replaceAll("\r", "");

  return `url('${safeValue}')`;
}

function normalizeCharacterData(data) {
  let migrated = false;

  if (!data.visuals || typeof data.visuals !== "object") {
    data.visuals = {};
    migrated = true;
  }

  if (typeof data.visuals.theme !== "string" || !data.visuals.theme.trim()) {
    data.visuals.theme = "royal-dark";
    migrated = true;
  }

  if (typeof data.visuals.frameStyle !== "string" || !data.visuals.frameStyle.trim()) {
    data.visuals.frameStyle = "simple";
    migrated = true;
  }

  for (const key of ["portrait", "mapToken", "houseCrest", "themeBanner", "houseBanner", "personalBanner"]) {
    if (data.visuals[key] === undefined || data.visuals[key] === null) {
      data.visuals[key] = "";
      migrated = true;
    }
  }

  if (!data.visuals.houseBanner && data.visuals.houseCrest) {
    data.visuals.houseBanner = data.visuals.houseCrest;
    migrated = true;
  }

  const normalizedBannerDisplaySource = normalizeBannerDisplaySource(data.visuals.bannerDisplaySource);

  if (data.visuals.bannerDisplaySource !== normalizedBannerDisplaySource) {
    data.visuals.bannerDisplaySource = normalizedBannerDisplaySource;
    migrated = true;
  }

  if (!data.visuals.colors || typeof data.visuals.colors !== "object") {
    data.visuals.colors = {};
    migrated = true;
  }

  const defaultColors = {
    primary: "#07111C",
    secondary: "#0A1D2C",
    accent: "#8A2E24",
    coldAccent: "#2AA6B8",
    textMain: "#F2E7D8"
  };

  for (const [key, value] of Object.entries(defaultColors)) {
    if (typeof data.visuals.colors[key] !== "string" || !data.visuals.colors[key]) {
      data.visuals.colors[key] = value;
      migrated = true;
    }
  }

  if (!data.derived || typeof data.derived !== "object") {
    data.derived = {};
    migrated = true;
  }

  if (typeof data.derived.movementBase !== "number") {
    const movementBase = Number(data.derived.movementBase);
    data.derived.movementBase = Number.isFinite(movementBase) && movementBase > 0 ? movementBase : 4;
    migrated = true;
  }

  if (typeof data.derived.runMultiplier !== "number") {
    const runMultiplier = Number(data.derived.runMultiplier);
    data.derived.runMultiplier = Number.isFinite(runMultiplier) && runMultiplier > 0 ? runMultiplier : 4;
    migrated = true;
  }

  if (typeof data.derived.defenseBonus !== "number") {
    const defenseBonus = Number(data.derived.defenseBonus);
    data.derived.defenseBonus = Number.isFinite(defenseBonus) ? defenseBonus : 0;
    migrated = true;
  }

  if (!data.destinyPoints || typeof data.destinyPoints !== "object") {
    data.destinyPoints = {};
    migrated = true;
  }

  for (const key of ["total", "available", "spent", "invested"]) {
    if (typeof data.destinyPoints[key] !== "number") {
      const numericValue = Number(data.destinyPoints[key]);
      data.destinyPoints[key] = Number.isFinite(numericValue) ? Math.max(0, Math.trunc(numericValue)) : 0;
      migrated = true;
    }
  }

  data.destinyPoints.spent = normalizeDestinyNumber(data.destinyPoints.spent ?? data.destinyPoints.gastos, 0);
  data.destinyPoints.total = normalizeDestinyNumber(data.destinyPoints.total, 0);

  if (!data.traits || typeof data.traits !== "object") {
    data.traits = {};
    migrated = true;
  }

  if (!Array.isArray(data.traits.qualities)) {
    data.traits.qualities = [];
    migrated = true;
  }

  if (!Array.isArray(data.traits.defects)) {
    data.traits.defects = [];
    migrated = true;
  }

  for (const quality of data.traits.qualities) {
    if (!quality.id) {
      quality.id = createId();
      migrated = true;
    }

    if (!Array.isArray(quality.effects)) {
      quality.effects = [];
      migrated = true;
    }

    if (!Array.isArray(quality.configs)) {
      quality.configs = [];
      migrated = true;
    }

    if (!quality.configValues || typeof quality.configValues !== "object") {
      quality.configValues = {};
      migrated = true;
    }

    if (!Array.isArray(quality.notes)) {
      quality.notes = [];
      migrated = true;
    }

    const destinyPaid = quality.destinyPaid === true || quality.paidWithDestiny === true;
    const destinyCost = destinyPaid ? normalizeDestinyNumber(quality.destinyCost, 1) || 1 : 0;

    if (quality.destinyPaid !== destinyPaid) {
      quality.destinyPaid = destinyPaid;
      migrated = true;
    }

    if (quality.paidWithDestiny !== destinyPaid) {
      quality.paidWithDestiny = destinyPaid;
      migrated = true;
    }

    if (quality.destinyCost !== destinyCost) {
      quality.destinyCost = destinyCost;
      migrated = true;
    }
  }

  applyCalculatedDestinyPoints(data);

  for (const defect of data.traits.defects) {
    if (!defect.id) {
      defect.id = createId();
      migrated = true;
    }

    if (!Array.isArray(defect.effects)) {
      defect.effects = [];
      migrated = true;
    }

    if (!Array.isArray(defect.configs)) {
      defect.configs = [];
      migrated = true;
    }

    if (!defect.configValues || typeof defect.configValues !== "object") {
      defect.configValues = {};
      migrated = true;
    }

    if (!Array.isArray(defect.notes)) {
      defect.notes = [];
      migrated = true;
    }
  }

  if (!Array.isArray(data.abilities)) {
    data.abilities = [];
    migrated = true;
  }

  for (const ability of data.abilities) {
    if (!ability || typeof ability !== "object") continue;

    if (!Array.isArray(ability.specializations)) {
      ability.specializations = [];
      migrated = true;
    }

    for (const specialization of ability.specializations) {
      if (!specialization || typeof specialization !== "object") continue;

      if (!specialization.id) {
        specialization.id = createId();
        migrated = true;
      }

      if (typeof specialization.name !== "string") {
        specialization.name = String(specialization.name ?? "");
        migrated = true;
      }

      if (typeof specialization.bonus !== "number") {
        const numericBonus = Number(specialization.bonus);
        specialization.bonus = Number.isFinite(numericBonus) ? numericBonus : 0;
        migrated = true;
      }
    }
  }

  if (!data.combat || typeof data.combat !== "object") {
    data.combat = {};
    migrated = true;
  }

  if (!data.combat.combatDefense || typeof data.combat.combatDefense !== "object") {
    data.combat.combatDefense = { value: 6, max: 6 };
    migrated = true;
  }

  if (!data.combat.health || typeof data.combat.health !== "object") {
    data.combat.health = { value: 6, max: 6 };
    migrated = true;
  }

  if (!data.combat.wounds || typeof data.combat.wounds !== "object") {
    data.combat.wounds = { value: 0, max: 0 };
    migrated = true;
  }

  if (!data.combat.injuries || typeof data.combat.injuries !== "object") {
    data.combat.injuries = { value: 0, max: 0 };
    migrated = true;
  }

  if (!data.combat.armor || typeof data.combat.armor !== "object") {
    data.combat.armor = {
      name: "",
      value: "",
      penalty: "",
      bulk: ""
    };
    migrated = true;
  }

  for (const key of ["name", "value", "penalty", "bulk"]) {
    if (data.combat.armor[key] === undefined || data.combat.armor[key] === null) {
      data.combat.armor[key] = "";
      migrated = true;
    }
  }

  if (!Array.isArray(data.combat.weapons)) {
    data.combat.weapons = [];
    migrated = true;
  }

  if (data.combat.weapons.length === 0) {
    data.combat.weapons.push(createDefaultWeapon());
    migrated = true;
  }

  for (const weapon of data.combat.weapons) {
    if (!weapon.id) {
      weapon.id = createId();
      migrated = true;
    }

    for (const key of ["name", "ability", "specialty", "test", "damage", "qualities", "notes"]) {
      if (weapon[key] === undefined || weapon[key] === null) {
        weapon[key] = "";
        migrated = true;
      }
    }

    if (weapon.bulk === undefined || weapon.bulk === null || weapon.bulk === "") {
      weapon.bulk = 0;
      migrated = true;
    } else if (typeof weapon.bulk !== "number") {
      const numericBulk = Number(weapon.bulk);
      weapon.bulk = Number.isFinite(numericBulk) ? numericBulk : 0;
      migrated = true;
    }

    if (weapon.carried === undefined || weapon.carried === null) {
      weapon.carried = true;
      migrated = true;
    }
  }

  if (!data.intrigue || typeof data.intrigue !== "object") {
    data.intrigue = {};
    migrated = true;
  }

  for (const key of ["intrigueDefense", "composure", "victories", "frustrations"]) {
    if (!data.intrigue[key] || typeof data.intrigue[key] !== "object") {
      data.intrigue[key] = { value: 0, max: 0 };
      migrated = true;
    }

    for (const subKey of ["value", "max"]) {
      if (typeof data.intrigue[key][subKey] !== "number") {
        const numericValue = Number(data.intrigue[key][subKey]);
        data.intrigue[key][subKey] = Number.isFinite(numericValue) ? numericValue : 0;
        migrated = true;
      }
    }
  }

  for (const key of ["techniques", "notes"]) {
    if (data.intrigue[key] === undefined || data.intrigue[key] === null) {
      data.intrigue[key] = "";
      migrated = true;
    }
  }

  if (!data.inventory || typeof data.inventory !== "object") {
    data.inventory = {};
    migrated = true;
  }

  for (const key of ["personalEquipment", "possessions", "money", "importantItems", "notes"]) {
    if (data.inventory[key] === undefined || data.inventory[key] === null) {
      data.inventory[key] = "";
      migrated = true;
    }
  }

  if (!Array.isArray(data.inventory.items)) {
    data.inventory.items = [];
    migrated = true;
  }

  if (data.inventory.items.length === 0) {
    data.inventory.items.push(createDefaultInventoryItem());
    migrated = true;
  }

  for (const item of data.inventory.items) {
    if (!item.id) {
      item.id = createId();
      migrated = true;
    }

    if (item.name === undefined || item.name === null) {
      item.name = "";
      migrated = true;
    }

    if (item.category === undefined || item.category === null) {
      item.category = "Equipamento";
      migrated = true;
    }

    if (item.quantity === undefined || item.quantity === null || item.quantity === "") {
      item.quantity = 1;
      migrated = true;
    } else if (typeof item.quantity !== "number") {
      const numericQuantity = Number(item.quantity);
      item.quantity = Number.isFinite(numericQuantity) ? numericQuantity : 1;
      migrated = true;
    }

    if (item.price === undefined || item.price === null) {
      item.price = "";
      migrated = true;
    }

    if (item.bulk === undefined || item.bulk === null || item.bulk === "") {
      item.bulk = 0;
      migrated = true;
    } else if (typeof item.bulk !== "number") {
      const numericBulk = Number(item.bulk);
      item.bulk = Number.isFinite(numericBulk) ? numericBulk : 0;
      migrated = true;
    }

    if (item.carried === undefined || item.carried === null) {
      item.carried = true;
      migrated = true;
    }

    if (item.notes === undefined || item.notes === null) {
      item.notes = "";
      migrated = true;
    }
  }

  return { data, migrated };
}

function createDefaultWeapon() {
  return {
    id: createId(),
    name: "",
    ability: "",
    specialty: "",
    test: "",
    damage: "",
    qualities: "",
    bulk: 0,
    carried: true,
    notes: ""
  };
}

function isEmptyDefaultWeapon(weapon) {
  return !String(weapon?.name ?? "").trim()
    && !String(weapon?.ability ?? "").trim()
    && !String(weapon?.specialty ?? "").trim()
    && !String(weapon?.test ?? "").trim()
    && !String(weapon?.damage ?? "").trim()
    && !String(weapon?.qualities ?? "").trim()
    && !String(weapon?.notes ?? "").trim()
    && Number(weapon?.bulk ?? 0) === 0
    && !weapon?.sourceUuid
    && !weapon?.gearType;
}

function createDefaultInventoryItem() {
  return {
    id: createId(),
    name: "",
    category: "Equipamento",
    quantity: 1,
    price: "",
    bulk: 0,
    carried: true,
    notes: ""
  };
}

function readInputValue(input) {
  if (input.type === "checkbox") return input.checked;
  if (input.type === "number") return Number(input.value || 0);
  return input.value;
}

function setByPath(object, path, value) {
  if (!path) return;

  const parts = path.split(".");
  let target = object;

  while (parts.length > 1) {
    const part = parts.shift();

    if (!target[part] || typeof target[part] !== "object") {
      target[part] = {};
    }

    target = target[part];
  }

  target[parts[0]] = value;
}

function isDragonActor(actor) {
  return actor?.documentName === "Actor" && String(actor.type).includes("dragon");
}

function getTraitTypeLabel(item) {
  return isDefectItem(item) ? "Defeito" : "Qualidade";
}

function getPlacedTokenDocumentsForActor(actor) {
  if (!canvas?.scene || !actor) return [];

  return canvas.scene.tokens.filter((tokenDocument) => {
    return tokenDocument.actor?.id === actor.id || tokenDocument.actorId === actor.id;
  });
}

function refreshActorDirectory() {
  ui.actors?.render?.(true);
  ui.sidebar?.tabs?.actors?.render?.(true);
}

function getTraitConfigDisplayParts(configValues = {}) {
  const values = [];
  const weaponName = configValues.chosenWeaponName ?? configValues.chosenWeapon;

  if (weaponName) {
    values.push(weaponName);
  }

  if (configValues.companionName) {
    values.push(configValues.companionName);
  }

  const animalLabel = [configValues.animalType, configValues.animalName].filter(Boolean).join(" - ");

  if (animalLabel) {
    values.push(animalLabel);
  }

  if (configValues.chosenAbility && configValues.chosenSpecialty) {
    values.push(`${configValues.chosenAbility}: ${configValues.chosenSpecialty}`);
  } else if (configValues.chosenAbility) {
    values.push(configValues.chosenAbility);
  } else if (configValues.chosenSpecialty) {
    values.push(configValues.chosenSpecialty);
  }

  for (const key of ["chosenLocation", "contactLocation", "chosenTerrain", "chosenFaith", "faith"]) {
    if (configValues[key]) {
      values.push(configValues[key]);
    }
  }

  return values.filter(Boolean);
}

function getTraitDisplayName(trait) {
  const configParts = getTraitConfigDisplayParts(trait?.configValues ?? {});

  if (configParts.length === 0) {
    return trait?.name ?? "";
  }

  return `${trait?.name ?? ""} (${configParts.join(", ")})`;
}

function toOwnedTraitView(trait) {
  return {
    id: trait.id,
    name: trait.name,
    displayName: getTraitDisplayName(trait),
    category: trait.category ?? "",
    prerequisite: trait.prerequisite ?? "",
    description: stripAutomationPlaceholderHtml(trait.description ?? ""),
    sourceUuid: trait.sourceUuid ?? "",
    itemType: trait.itemType ?? "",
    effects: trait.effects ?? [],
    configs: trait.configs ?? [],
    configValues: trait.configValues ?? {},
    notes: trait.notes ?? [],
    configPending: Boolean(trait.configPending),
    destinyPaid: trait.destinyPaid === true || trait.paidWithDestiny === true,
    paidWithDestiny: trait.destinyPaid === true || trait.paidWithDestiny === true,
    destinyCost: getQualityDestinyCost(trait),
    automationVersion: trait.automationVersion ?? ""
  };
}

function sortByNamePtBr(a, b) {
  return String(a.name ?? "").localeCompare(String(b.name ?? ""), "pt-BR", {
    sensitivity: "base"
  });
}

function getStoredQuality(data, traitId) {
  return data?.traits?.qualities?.find((trait) => trait.id === traitId) ?? null;
}

function getStoredDefect(data, traitId) {
  return data?.traits?.defects?.find((trait) => trait.id === traitId) ?? null;
}

function getAbilityOptions(data) {
  return (data?.abilities ?? [])
    .map((ability) => ability?.name)
    .filter(Boolean)
    .sort((a, b) => String(a).localeCompare(String(b), "pt-BR", {
      sensitivity: "base"
    }));
}

function getAbilityRank(data, abilityName) {
  const normalizedAbility = normalizeConfigComparisonValue(abilityName);
  const ability = (data?.abilities ?? []).find((item) => {
    return normalizeConfigComparisonValue(item?.name) === normalizedAbility
      || normalizeConfigComparisonValue(item?.id) === normalizedAbility;
  });

  const rank = Number(ability?.rank ?? 0);

  return Number.isFinite(rank) ? rank : 0;
}

function getSpecializationOptions(data, abilityName) {
  const normalizedAbility = String(abilityName ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();

  const ability = (data?.abilities ?? []).find((item) => {
    const name = String(item?.name ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim()
      .toLowerCase();

    return name === normalizedAbility;
  });

  return (ability?.specializations ?? [])
    .map((specialization) => specialization?.name)
    .filter(Boolean)
    .sort((a, b) => String(a).localeCompare(String(b), "pt-BR", {
      sensitivity: "base"
    }));
}

function normalizeWeaponName(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function getWeaponDisplayName(weapon) {
  return String(weapon?.name ?? "").replace(/\s+/g, " ").trim();
}

function getNamedWeaponOptions(data) {
  return (data?.combat?.weapons ?? [])
    .map((weapon, weaponIndex) => {
      const name = getWeaponDisplayName(weapon);

      return {
        id: String(weapon?.id ?? ""),
        name,
        value: String(weapon?.id || name || weaponIndex),
        weapon,
        weaponIndex
      };
    })
    .filter((option) => option.name)
    .sort((a, b) => a.name.localeCompare(b.name, "pt-BR", {
      sensitivity: "base"
    }));
}

function getConfiguredWeaponName(configValues = {}) {
  return String(configValues.chosenWeaponName ?? configValues.chosenWeapon ?? "").trim();
}

function getConfiguredWeaponId(configValues = {}) {
  return String(configValues.chosenWeaponId ?? "").trim();
}

function weaponMatchesConfig(weapon, configValues = {}) {
  const weaponId = String(weapon?.id ?? "").trim();
  const configuredId = getConfiguredWeaponId(configValues);

  if (weaponId && configuredId && weaponId === configuredId) {
    return true;
  }

  const weaponName = normalizeWeaponName(getWeaponDisplayName(weapon));
  const configuredName = normalizeWeaponName(getConfiguredWeaponName(configValues));

  return Boolean(weaponName && configuredName && weaponName === configuredName);
}

function hasWeaponMastery(data, weapon) {
  return (data?.traits?.qualities ?? []).some((quality) => {
    return normalizeTraitRepeatableName(quality?.name) === "maestria em arma"
      && weaponMatchesConfig(weapon, quality?.configValues ?? {});
  });
}

function getWeaponOptionsWithMastery(data) {
  return getNamedWeaponOptions(data).filter((option) => hasWeaponMastery(data, option.weapon));
}

function getWeaponOptionsForConfig(data, config) {
  const inputType = getNormalizedConfigInputType(config);
  return inputType === "weaponWithMastery" ? getWeaponOptionsWithMastery(data) : getNamedWeaponOptions(data);
}

function findWeaponOptionForConfigValue(data, config, value) {
  const normalizedValue = normalizeWeaponName(value);
  const rawValue = String(value ?? "").trim();

  return getWeaponOptionsForConfig(data, config).find((option) => {
    return option.value === rawValue
      || option.id === rawValue
      || normalizeWeaponName(option.name) === normalizedValue;
  }) ?? null;
}

function findWeaponByConfigValues(data, configValues = {}, key = "chosenWeapon") {
  const configuredId = String(configValues[`${key}Id`] ?? configValues.chosenWeaponId ?? "").trim();
  const configuredName = normalizeWeaponName(configValues[`${key}Name`] ?? configValues[key] ?? configValues.chosenWeaponName ?? configValues.chosenWeapon);

  return (data?.combat?.weapons ?? []).find((weapon) => {
    const weaponId = String(weapon?.id ?? "").trim();
    const weaponName = normalizeWeaponName(getWeaponDisplayName(weapon));
    return Boolean((configuredId && weaponId === configuredId) || (configuredName && weaponName === configuredName));
  }) ?? null;
}

function getWeaponConfigComparisonValue(configValues = {}) {
  const weaponName = normalizeWeaponName(getConfiguredWeaponName(configValues));
  return weaponName || normalizeConfigComparisonValue(getConfiguredWeaponId(configValues));
}

function parseWeaponDamage(value) {
  const text = String(value ?? "").trim().replace(",", ".");
  if (!/^[+-]?\d+(?:\.\d+)?$/.test(text)) return null;

  const numericValue = Number(text);
  return Number.isFinite(numericValue) ? numericValue : null;
}

function formatWeaponDamageValue(value) {
  if (!Number.isFinite(value)) return "";
  return Number.isInteger(value) ? String(value) : String(Number(value.toFixed(2))).replace(".", ",");
}

function getWeaponDamageEffectValue(trait, fallbackValue = 1) {
  const effect = (trait?.effects ?? []).find((item) => item?.type === "weapon.damage");
  const value = Number(effect?.value ?? fallbackValue);
  return Number.isFinite(value) ? value : fallbackValue;
}
function normalizeGearType(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[\s_-]+/g, "")
    .trim()
    .toLowerCase();
}

function getGotSheetFlagObject(item) {
  return item?.flags?.[MODULE_ID] ?? item?.flags?.["got-beautiful-sheet"] ?? {};
}

function getGearType(item) {
  const flagValue = item?.getFlag?.(MODULE_ID, "gearType") ?? getGotSheetFlagObject(item).gearType;
  const normalizedType = normalizeGearType(flagValue);

  if (normalizedType === "weapon") return "weapon";
  if (normalizedType === "weaponquality") return "weaponQuality";
  if (normalizedType === "armor") return "armor";
  if (normalizedType === "shield") return "shield";
  if (normalizedType === "equipment") return "equipment";

  return "";
}

function getObjectPathValue(source, path) {
  if (!source || !path) return undefined;

  if (globalThis.foundry?.utils?.getProperty) {
    return foundry.utils.getProperty(source, path);
  }

  return String(path)
    .split(".")
    .reduce((current, key) => current?.[key], source);
}

function getGearFieldValue(item, aliases = []) {
  const flagObject = getGotSheetFlagObject(item);
  const system = item?.system ?? {};
  const sources = [
    flagObject,
    system,
    system.props ?? {},
    system.data ?? {},
    system.flags ?? {}
  ];

  for (const alias of aliases) {
    const flagValue = item?.getFlag?.(MODULE_ID, alias);

    if (flagValue !== undefined && flagValue !== null && flagValue !== "") {
      return flagValue;
    }
  }

  for (const source of sources) {
    for (const alias of aliases) {
      const value = getObjectPathValue(source, alias);

      if (value !== undefined && value !== null && value !== "") {
        return value;
      }
    }
  }

  return "";
}

function isGearPlainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function normalizeGearPrimitive(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function pickGearObjectText(value, keys = []) {
  if (!isGearPlainObject(value)) return "";

  for (const key of keys) {
    const picked = getObjectPathValue(value, key);

    if (picked === undefined || picked === null || picked === "") continue;

    const text = normalizeGearText(picked, keys);
    if (text) return text;
  }

  return "";
}

function normalizeGearText(value, keys = ["text", "texto", "label", "name", "nome", "title", "value", "valor", "id"]) {
  if (value === undefined || value === null) return "";

  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    return normalizeGearPrimitive(value);
  }

  if (Array.isArray(value)) {
    return value
      .map((item) => normalizeGearText(item, keys))
      .filter(Boolean)
      .join(" | ");
  }

  if (isGearPlainObject(value)) {
    const picked = pickGearObjectText(value, keys);
    if (picked) return picked;

    const primitiveValues = Object.values(value)
      .map((item) => normalizeGearText(item, keys))
      .filter(Boolean);

    return primitiveValues.join(" | ");
  }

  return "";
}

function normalizeGearQualities(value) {
  const qualityKeys = ["name", "nome", "label", "title", "value", "valor", "id"];
  const parts = Array.isArray(value)
    ? value.map((item) => normalizeGearText(item, qualityKeys))
    : isGearPlainObject(value)
      ? [normalizeGearText(value, qualityKeys)]
      : String(value ?? "").split(/[,;|]/g);

  return parts
    .map((item) => normalizeGearText(item, qualityKeys))
    .flatMap((item) => String(item).split(/[,;|]/g))
    .map((item) => normalizeGearPrimitive(item))
    .filter(Boolean)
    .join(" | ");
}

function splitWeaponQualityText(value) {
  const text = normalizeGearQualities(value);

  if (!text) return [];

  return text
    .split(/[|,;]/g)
    .map((item) => normalizeGearPrimitive(item))
    .filter(Boolean);
}

function getWeaponQualityItemName(item) {
  const directName = normalizeGearText(item?.name);
  if (directName) return directName;

  return normalizeGearText(getGearFieldValue(item, [
    "name",
    "nome",
    "label",
    "title"
  ]));
}

function getWeaponQualityBulkValue(qualityName) {
  const match = normalizeGearComparisonText(qualityName).match(/\bvolume\s*([+-]?\d+)/);
  if (!match) return null;

  const bulk = Number(match[1]);
  return Number.isFinite(bulk) ? Math.max(0, Math.trunc(bulk)) : null;
}

function getWeaponDropCardFromEvent(event) {
  const target = event?.target ?? event?.originalEvent?.target;
  return target?.closest?.(".got-weapon-card") ?? null;
}

function formatGearSignedModifier(value) {
  const text = normalizeGearText(value, ["value", "valor", "modifier", "modificador", "bonus", "bônus", "mod"]);
  if (!text) return "";

  const numeric = Number(String(text).replace(",", "."));
  if (!Number.isFinite(numeric) || numeric === 0) return "";

  const absoluteValue = Math.abs(numeric);
  const formatted = Number.isInteger(absoluteValue) ? String(absoluteValue) : String(absoluteValue).replace(".", ",");
  return numeric > 0 ? `+ ${formatted}` : `- ${formatted}`;
}

function normalizeGearDamage(value) {
  if (value === undefined || value === null) return "";

  if (typeof value === "string" || typeof value === "number") {
    return normalizeGearPrimitive(value);
  }

  if (Array.isArray(value)) {
    return normalizeGearText(value);
  }

  if (isGearPlainObject(value)) {
    const base = pickGearObjectText(value, ["ability", "habilidade", "attribute", "atributo", "base", "stat"]);
    const modifier = getObjectPathValue(value, "modifier")
      ?? getObjectPathValue(value, "modificador")
      ?? getObjectPathValue(value, "bonus")
      ?? getObjectPathValue(value, "bônus")
      ?? getObjectPathValue(value, "mod")
      ?? getObjectPathValue(value, "value")
      ?? getObjectPathValue(value, "valor");
    const signedModifier = formatGearSignedModifier(modifier);

    if (base && signedModifier) return `${base} ${signedModifier}`;
    if (base) return base;
    if (signedModifier) return signedModifier;

    const explicitText = pickGearObjectText(value, ["text", "texto", "label", "name", "nome", "formula"]);
    if (explicitText) return explicitText;

    return normalizeGearText(value);
  }

  return "";
}

function getGearBulk(value, qualities) {
  const explicitBulkText = normalizeGearText(value, ["bulk", "volume", "value", "valor", "number", "numero"]);
  const explicitBulk = Number(String(explicitBulkText).replace(",", ".").match(/[+-]?\d+(?:\.\d+)?/)?.[0] ?? NaN);

  if (Number.isFinite(explicitBulk)) {
    return explicitBulk;
  }

  const qualityBulk = String(qualities ?? "").match(/volume\s*([+-]?\d+)/i);

  if (qualityBulk) {
    const parsedBulk = Number(qualityBulk[1]);
    return Number.isFinite(parsedBulk) ? parsedBulk : 0;
  }

  return 0;
}

function normalizeGearComparisonText(value) {
  return normalizeGearText(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function inferWeaponAbility({ ability, specialty, group }) {
  const explicitAbility = normalizeGearText(ability, ["ability", "habilidade", "name", "nome", "label", "value", "valor"]);

  if (explicitAbility) {
    return explicitAbility;
  }

  const comparisonText = normalizeGearComparisonText(`${normalizeGearText(specialty)} ${normalizeGearText(group)}`);
  const rangedGroups = ["bestas", "arcos", "fundas", "armas arremessadas"];

  if (rangedGroups.some((item) => comparisonText.includes(item))) {
    return "Pontaria";
  }

  return "Luta";
}

function createGearNotes({ group, training, weight, price, notes }) {
  const lines = [
    ["Grupo", group],
    ["Treinamento", training],
    ["Peso", weight],
    ["Preço", price],
    ["Notas", notes]
  ];

  return lines
    .map(([label, value]) => [label, normalizeGearText(value)])
    .filter(([, value]) => value)
    .map(([label, value]) => `${label}: ${value}`)
    .join("\n");
}

function getGearSourcePack(item) {
  return String(item?.pack ?? item?.compendium?.collection ?? item?.collection?.metadata?.id ?? "").trim();
}

function createWeaponFromGearItem(item, gearType) {
  const group = getGearFieldValue(item, ["group", "grupo"]);
  const specialty = getGearFieldValue(item, ["specialty", "specialization", "especialidade", "especialização", "especializacao"]);
  const ability = inferWeaponAbility({
    ability: getGearFieldValue(item, ["ability", "habilidade"]),
    specialty,
    group
  });
  const testText = normalizeGearText(getGearFieldValue(item, ["test", "teste"]));
  const specialtyText = normalizeGearText(specialty);
  const test = testText || (specialtyText ? `${ability} / ${specialtyText}` : ability);
  const qualities = normalizeGearQualities(getGearFieldValue(item, ["qualities", "qualidades", "qualitiesList", "qualidadesLista"]));
  const bulk = getGearBulk(getGearFieldValue(item, ["bulk", "volume"]), qualities);
  const training = getGearFieldValue(item, ["training", "treinamento"]);
  const weight = getGearFieldValue(item, ["weight", "peso"]);
  const price = getGearFieldValue(item, ["price", "preco", "preço"]);
  const notes = getGearFieldValue(item, ["notes", "notas"]);

  return {
    id: createId(),
    name: normalizeGearText(item?.name),
    ability,
    specialty: specialtyText,
    test,
    damage: normalizeGearDamage(getGearFieldValue(item, ["damage", "dano"])),
    qualities,
    bulk,
    carried: true,
    notes: createGearNotes({ group, training, weight, price, notes }),
    sourceUuid: String(item?.uuid ?? ""),
    sourcePack: getGearSourcePack(item),
    gearType
  };
}

function normalizeGearNumber(value, fallbackValue = 0) {
  if (value === undefined || value === null || value === "") return fallbackValue;

  if (typeof value === "number") {
    return Number.isFinite(value) ? value : fallbackValue;
  }

  const text = normalizeGearText(value, [
    "value",
    "valor",
    "number",
    "numero",
    "número",
    "amount",
    "quantidade",
    "total"
  ]).replace(",", ".");
  const match = text.match(/[+-]?\d+(?:\.\d+)?/);

  if (!match) return fallbackValue;

  const numericValue = Number(match[0]);
  return Number.isFinite(numericValue) ? numericValue : fallbackValue;
}

function createArmorNotes({ category, group, weight, price, notes, description }) {
  const lines = [
    ["Categoria", category],
    ["Grupo", group],
    ["Peso", weight],
    ["Preço", price],
    ["Notas", notes],
    ["Descrição", description]
  ];

  return lines
    .map(([label, value]) => [label, normalizeGearText(value)])
    .filter(([, value]) => value)
    .map(([label, value]) => `${label}: ${value}`)
    .join("\n");
}

function createArmorFromGearItem(item) {
  const name = normalizeGearText(item?.name) || normalizeGearText(getGearFieldValue(item, [
    "name",
    "nome",
    "label",
    "title"
  ])) || "Armadura";

  const armorValue = normalizeGearNumber(getGearFieldValue(item, [
    "armorValue",
    "valorArmadura",
    "valor_de_armadura",
    "va",
    "VA",
    "value",
    "valor",
    "armor",
    "armadura"
  ]), 0);

  const armorPenalty = normalizeGearNumber(getGearFieldValue(item, [
    "armorPenalty",
    "penalidadeArmadura",
    "penalidade_de_armadura",
    "penalty",
    "penalidade",
    "pa",
    "PA"
  ]), 0);

  const armorBulk = normalizeGearNumber(getGearFieldValue(item, [
    "bulk",
    "volume",
    "encumbrance",
    "carga"
  ]), 0);

  const category = getGearFieldValue(item, ["category", "categoria"]);
  const group = getGearFieldValue(item, ["group", "grupo"]);
  const weight = getGearFieldValue(item, ["weight", "peso"]);
  const price = getGearFieldValue(item, ["price", "preco", "preço"]);
  const notes = getGearFieldValue(item, ["notes", "notas"]);
  const description = getGearFieldValue(item, ["description", "descricao", "descrição"]);

  return {
    name,
    value: armorValue,
    penalty: armorPenalty,
    bulk: armorBulk,
    notes: createArmorNotes({ category, group, weight, price, notes, description }),
    sourceUuid: String(item?.uuid ?? ""),
    sourcePack: getGearSourcePack(item),
    gearType: "armor"
  };
}
function getWeaponDamageModifiers(data, weapon) {
  const modifiers = [];

  for (const quality of data?.traits?.qualities ?? []) {
    const normalizedName = normalizeTraitRepeatableName(quality?.name);
    if (normalizedName !== "maestria em arma" && normalizedName !== "maestria em arma aprimorada") continue;
    if (!weaponMatchesConfig(weapon, quality?.configValues ?? {})) continue;

    const value = getWeaponDamageEffectValue(quality, 1);
    modifiers.push({
      sourceName: quality.name,
      value,
      label: `+${formatWeaponDamageValue(value)}`
    });
  }

  return modifiers;
}

function buildWeaponItemView(data, weapon, weaponIndex) {
  const baseDamage = parseWeaponDamage(weapon?.damage);
  const weaponDamageModifiers = getWeaponDamageModifiers(data, weapon);
  const damageBonus = weaponDamageModifiers.reduce((total, modifier) => total + modifier.value, 0);
  const effectiveDamage = baseDamage === null ? null : baseDamage + damageBonus;

  return {
    ...weapon,
    weaponIndex,
    weaponDamageModifiers,
    hasWeaponDamageModifiers: weaponDamageModifiers.length > 0,
    effectiveDamage: formatWeaponDamageValue(effectiveDamage),
    hasEffectiveDamage: baseDamage !== null && damageBonus !== 0
  };
}

function getNormalizedConfigInputType(config) {
  return String(config?.input ?? "text").trim();
}

function normalizeConfigOptions(options = []) {
  return options.map((option) => {
    if (typeof option === "string") {
      return {
        value: option,
        label: option
      };
    }

    return {
      value: option?.value ?? option?.label ?? "",
      label: option?.label ?? option?.value ?? ""
    };
  }).filter((option) => option.value !== "");
}

function renderSelectConfigInput({ key, label, required, options }) {
  return `
    <label class="got-quality-item-field">
      <span>${label}</span>
      <select name="${key}" ${required}>
        ${normalizeConfigOptions(options).map((option) => `
          <option value="${escapeHTML(option.value)}">${escapeHTML(option.label)}</option>
        `).join("")}
      </select>
    </label>
  `;
}

function renderTextConfigInput({ key, label, required, placeholder }) {
  return `
    <label class="got-quality-item-field">
      <span>${label}</span>
      <input name="${key}"
             value=""
             placeholder="${escapeHTML(placeholder ?? "")}"
             ${required}>
    </label>
  `;
}

function renderWeaponConfigInput({ key, label, required, options }) {
  return renderSelectConfigInput({
    key,
    label,
    required,
    options: options.map((option) => {
      return {
        value: option.value,
        label: option.name
      };
    })
  });
}

function normalizeTraitConfigValues(configs, values, data) {
  const normalizedValues = { ...values };

  for (const config of configs) {
    const inputType = getNormalizedConfigInputType(config);
    if (inputType !== "weapon" && inputType !== "weaponWithMastery") continue;

    const weaponOption = findWeaponOptionForConfigValue(data, config, values[config.key]);
    if (!weaponOption) continue;

    normalizedValues[config.key] = weaponOption.name;
    normalizedValues[`${config.key}Id`] = weaponOption.id;
    normalizedValues[`${config.key}Name`] = weaponOption.name;
  }

  return normalizedValues;
}

function validateTraitConfigAvailability(data, item, configs) {
  for (const config of configs ?? []) {
    const inputType = getNormalizedConfigInputType(config);

    if (inputType === "weapon" && getNamedWeaponOptions(data).length === 0) {
      return {
        ok: false,
        message: `${item.name} exige uma arma cadastrada com nome na aba Combate.`
      };
    }

    if (inputType === "weaponWithMastery" && getWeaponOptionsWithMastery(data).length === 0) {
      return {
        ok: false,
        message: `${item.name} exige Maestria em Arma em uma arma cadastrada.`
      };
    }
  }

  return { ok: true };
}

function renderConfigInput(config, data) {
  const key = escapeHTML(config.key);
  const label = escapeHTML(config.label ?? config.key);
  const required = config.required ? "required" : "";
  const inputType = getNormalizedConfigInputType(config);
  const abilityMinimum = Number(config.abilityMinimum ?? 0);

  if (inputType === "ability") {
    let abilities = getAbilityOptions(data);

    if (abilities.length === 0) {
      abilities = [...FALLBACK_ABILITY_OPTIONS];
    }

    if (abilityMinimum > 0) {
      abilities = abilities.filter((abilityName) => {
        return getAbilityRank(data, abilityName) >= abilityMinimum;
      });
    }

    if (abilities.length > 0) {
      return renderSelectConfigInput({
        key,
        label,
        required,
        options: abilities
      });
    }
  }

  if (inputType === "weapon" || inputType === "weaponWithMastery") {
    return renderWeaponConfigInput({
      key,
      label,
      required,
      options: getWeaponOptionsForConfig(data, config)
    });
  }

  if (inputType === "select" || inputType === "choice") {
    return renderSelectConfigInput({
      key,
      label,
      required,
      options: config.options ?? []
    });
  }

  if (inputType === "terrain") {
    return renderSelectConfigInput({
      key,
      label,
      required,
      options: TERRAIN_CONFIG_OPTIONS
    });
  }

  if (inputType === "knowledgeFocus") {
    return renderSelectConfigInput({
      key,
      label,
      required,
      options: KNOWLEDGE_FOCUS_OPTIONS
    });
  }

  if (inputType === "specialty" || inputType === "specialization") {
    const specializations = getSpecializationOptions(data, config.ability);

    if (specializations.length > 0) {
      return renderSelectConfigInput({
        key,
        label,
        required,
        options: specializations
      });
    }

    return renderTextConfigInput({
      key,
      label,
      required,
      placeholder: config.placeholder ?? "Digite a especialidade"
    });
  }

  return renderTextConfigInput({
    key,
    label,
    required,
    placeholder: config.placeholder ?? ""
  });
}


async function promptTraitConfiguration({ item, configs, data }) {
  if (!Array.isArray(configs) || configs.length === 0) {
    return {};
  }

  return new Promise((resolve, reject) => {
    let settled = false;

    const settle = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };

    const fail = (error) => {
      if (settled) return;
      settled = true;
      reject(error);
    };

    const content = `
      <form class="got-quality-item-form got-trait-config-dialog">
        <section class="got-quality-item-panel">
          <header class="got-quality-item-header">
            <h2>Configurar ${escapeHTML(item.name)}</h2>
            <p>Esta ${escapeHTML(getTraitTypeLabel(item).toLowerCase())} precisa de uma escolha antes de entrar na ficha.</p>
          </header>

          <div class="got-quality-item-fields">
            ${configs.map((config) => renderConfigInput(config, data)).join("")}
          </div>
        </section>
      </form>
    `;

    new Dialog({
      title: `Configurar ${item.name}`,
      content,
      buttons: {
        save: {
          label: "Adicionar",
          callback: (html) => {
            try {
              const root = html?.[0] ?? html;
              const form = root?.querySelector?.("form") ?? root?.find?.("form")?.[0] ?? null;

              if (!form) {
                throw new Error("Formulário de configuração não encontrado.");
              }

              const formData = new FormData(form);
              const values = {};

              for (const config of configs) {
                values[config.key] = String(formData.get(config.key) ?? "").trim();
              }

              const normalizedValues = normalizeTraitConfigValues(configs, values, data);
              const missingConfig = configs.find((config) => {
                return config.required && !normalizedValues[config.key];
              });

              if (missingConfig) {
                ui.notifications.warn(`Configuração obrigatória: ${missingConfig.label ?? missingConfig.key}.`);
                return false;
              }

              settle(normalizedValues);
              return true;
            } catch (error) {
              fail(error);
              return true;
            }
          }
        },
        cancel: {
          label: "Cancelar",
          callback: () => settle(null)
        }
      },
      default: "save",
      close: () => settle(null)
    }).render(true);
  });
}


async function promptQualityDestinyCost({ item, data }) {
  const available = calculateDestinyPoints(data).available;

  return new Promise((resolve) => {
    let settled = false;

    const settle = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };

    new Dialog({
      title: "Custo de Ponto de Destino",
      content: `
        <section class="got-roll-card">
          <p>A qualidade <strong>${escapeHTML(item?.name ?? "Qualidade")}</strong> custa 1 Ponto de Destino?</p>
          <p><strong>Pontos disponiveis:</strong> ${available}</p>
        </section>
      `,
      buttons: {
        pay: {
          label: "Pagar 1 Ponto de Destino",
          callback: () => {
            const currentAvailable = calculateDestinyPoints(data).available;

            if (currentAvailable <= 0) {
              ui.notifications.warn("Nenhum Ponto de Destino disponivel para investir nesta Qualidade.");
              return false;
            }

            settle("paid");
            return true;
          }
        },
        free: {
          label: "Gratuita / Sem custo",
          callback: () => {
            settle("free");
            return true;
          }
        },
        cancel: {
          label: "Cancelar",
          callback: () => {
            settle(null);
            return true;
          }
        }
      },
      default: "free",
      close: () => settle(null)
    }).render(true);
  });
}

async function promptDestinyUse({ title, message, label, placeholder }) {
  return new Promise((resolve) => {
    let settled = false;

    const settle = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };

    new Dialog({
      title,
      content: `
        <form class="got-quality-item-form got-destiny-dialog">
          <section class="got-quality-item-panel">
            <p>${message}</p>
            <label>
              <span>${label}</span>
              <input name="reason" type="text" placeholder="${escapeHTML(placeholder)}">
            </label>
          </section>
        </form>
      `,
      buttons: {
        confirm: {
          label: "Confirmar",
          callback: (html) => {
            const root = html?.[0] ?? html;
            const form = root?.querySelector?.("form") ?? root?.find?.("form")?.[0] ?? null;
            const formData = form ? new FormData(form) : null;
            settle(String(formData?.get("reason") ?? "").trim());
            return true;
          }
        },
        cancel: {
          label: "Cancelar",
          callback: () => {
            settle(null);
            return true;
          }
        }
      },
      default: "confirm",
      close: () => settle(null)
    }).render(true);
  });
}

async function postDestinyChatMessage({ actor, actorName, title, lines }) {
  if (typeof ChatMessage === "undefined") return;

  const content = `
    <section class="got-roll-card">
      <header class="got-roll-header">
        <h2>${escapeHTML(title)}</h2>
        <span>${escapeHTML(actorName)}</span>
      </header>
      ${lines.map((line) => `<p>${escapeHTML(line)}</p>`).join("")}
    </section>
  `;

  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: actor ?? null }),
    content
  });
}
async function getDroppedDocument(event) {
  const dataTransfer = event.originalEvent?.dataTransfer ?? event.dataTransfer;
  if (!dataTransfer) return null;

  let dragData = null;

  try {
    if (typeof TextEditor !== "undefined") {
      dragData = TextEditor.getDragEventData?.(event.originalEvent ?? event) ?? null;
    }
  } catch (error) {
    console.warn(`${MODULE_ID} | Não foi possível ler drop pelo TextEditor.`, error);
  }

  if (!dragData) {
    const rawData = dataTransfer.getData("text/plain") || dataTransfer.getData("application/json");

    if (!rawData) return null;

    try {
      dragData = JSON.parse(rawData);
    } catch (error) {
      console.warn(`${MODULE_ID} | Drop ignorado: dados inválidos.`, rawData, error);
      return null;
    }
  }

  if (dragData.type !== "Item" && dragData.documentName !== "Item") {
    return null;
  }

  if (dragData.uuid) {
    return fromUuid(dragData.uuid);
  }

  if (dragData.id) {
    return game.items?.get(dragData.id) ?? null;
  }

  return null;
}

function shouldKeepEffectForConfig(effect, configValues) {
  if (!effect.whenConfig) return true;

  const key = effect.whenConfig.key;
  const expectedValue = String(effect.whenConfig.value ?? "");
  const actualValue = String(configValues?.[key] ?? "");

  return actualValue === expectedValue;
}

function resolveConfigToken(value, configValues) {
  if (typeof value !== "string") return value;

  return value.replace(/{{\s*([\w.-]+)\s*}}/g, (_match, key) => {
    return String(configValues?.[key] ?? "");
  });
}

function resolveEffectForConfig(effect, configValues) {
  const nextEffect = cloneData(effect);

  if (nextEffect.targetFromConfig) {
    const configKey = nextEffect.targetFromConfig;
    const configValue = configValues?.[configKey];

    if (configValue) {
      nextEffect.target = configValue;
    }

    delete nextEffect.targetFromConfig;
  }

  if (nextEffect.specializationFromConfig) {
    const configKey = nextEffect.specializationFromConfig;
    const configValue = configValues?.[configKey];

    if (configValue) {
      nextEffect.specialization = configValue;
    }

    delete nextEffect.specializationFromConfig;
  }

  if (nextEffect.target && typeof nextEffect.target === "object") {
    if (nextEffect.target.abilityFromConfig) {
      const configValue = configValues?.[nextEffect.target.abilityFromConfig];

      if (configValue) {
        nextEffect.target.ability = configValue;
      }

      delete nextEffect.target.abilityFromConfig;
    }

    if (nextEffect.target.specializationFromConfig) {
      const configValue = configValues?.[nextEffect.target.specializationFromConfig];

      if (configValue) {
        nextEffect.target.specialization = configValue;
      }

      delete nextEffect.target.specializationFromConfig;
    }
  }

  if (nextEffect.valueFromSpecializationBonus && typeof nextEffect.valueFromSpecializationBonus === "object") {
    if (nextEffect.valueFromSpecializationBonus.abilityFromConfig) {
      const configValue = configValues?.[nextEffect.valueFromSpecializationBonus.abilityFromConfig];

      if (configValue) {
        nextEffect.valueFromSpecializationBonus.ability = configValue;
      }

      delete nextEffect.valueFromSpecializationBonus.abilityFromConfig;
    }

    if (nextEffect.valueFromSpecializationBonus.specializationFromConfig) {
      const configValue = configValues?.[nextEffect.valueFromSpecializationBonus.specializationFromConfig];

      if (configValue) {
        nextEffect.valueFromSpecializationBonus.specialization = configValue;
      }

      delete nextEffect.valueFromSpecializationBonus.specializationFromConfig;
    }
  }

  nextEffect.label = resolveConfigToken(nextEffect.label, configValues);

  delete nextEffect.whenConfig;

  return nextEffect;
}

function resolveAutomationEffects(effects, configValues) {
  if (!Array.isArray(effects)) return [];

  return effects
    .filter((effect) => shouldKeepEffectForConfig(effect, configValues))
    .map((effect) => resolveEffectForConfig(effect, configValues));
}

function resolveAutomationNotes(notes, configValues) {
  if (!Array.isArray(notes)) return [];

  return notes
    .filter((note) => shouldKeepEffectForConfig(note, configValues))
    .map((note) => {
      const nextNote = cloneData(note);
      nextNote.text = resolveConfigToken(nextNote.text, configValues);
      nextNote.label = resolveConfigToken(nextNote.label, configValues);
      delete nextNote.whenConfig;
      return nextNote;
    });
}

function normalizePrerequisiteText(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function normalizeConfigComparisonValue(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}

function normalizeTraitRepeatableName(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}

function normalizeDestinyNumber(value, fallback = 0) {
  const numberValue = Number(value);
  return Number.isFinite(numberValue) ? Math.max(0, Math.trunc(numberValue)) : fallback;
}

function getQualityDestinyCost(quality) {
  if (!quality) return 0;

  if (quality.destinyPaid === true || quality.paidWithDestiny === true) {
    return normalizeDestinyNumber(quality.destinyCost, 1) || 1;
  }

  return 0;
}

function getCharacterQualities(data) {
  return Array.isArray(data?.traits?.qualities) ? data.traits.qualities : [];
}

function calculateDestinyPoints(data) {
  const destiny = data?.destinyPoints ?? {};
  const total = normalizeDestinyNumber(destiny.total, 0);
  const spent = normalizeDestinyNumber(destiny.spent ?? destiny.gastos, 0);
  const invested = getCharacterQualities(data).reduce((sum, quality) => {
    return sum + getQualityDestinyCost(quality);
  }, 0);
  const available = Math.max(0, total - spent - invested);

  return {
    total,
    spent,
    gastos: spent,
    invested,
    investidos: invested,
    available,
    disponiveis: available
  };
}

function applyCalculatedDestinyPoints(data) {
  if (!data.destinyPoints || typeof data.destinyPoints !== "object") {
    data.destinyPoints = {};
  }

  const calculated = calculateDestinyPoints(data);

  data.destinyPoints.total = calculated.total;
  data.destinyPoints.spent = calculated.spent;
  data.destinyPoints.gastos = calculated.spent;
  data.destinyPoints.invested = calculated.invested;
  data.destinyPoints.investidos = calculated.invested;
  data.destinyPoints.available = calculated.available;
  data.destinyPoints.disponiveis = calculated.available;

  return calculated;
}

function isRepeatableTraitName(value) {
  const normalizedName = normalizeTraitRepeatableName(value);

  return REPEATABLE_TRAIT_NAMES.has(normalizedName);
}

function hasMeaningfulConfigValues(configValues = {}) {
  return getConfigComparisonKeys(configValues).length > 0;
}

function getConfigComparisonKeys(configValues = {}) {
  return Object.keys(configValues)
    .filter((key) => configValues[key] !== undefined && configValues[key] !== null && String(configValues[key]).trim() !== "")
    .sort();
}

function haveSameConfigValues(left = {}, right = {}) {
  const leftKeys = getConfigComparisonKeys(left);
  const rightKeys = getConfigComparisonKeys(right);

  if (leftKeys.length !== rightKeys.length) return false;

  return leftKeys.every((key, index) => {
    return key === rightKeys[index]
      && normalizeConfigComparisonValue(left[key]) === normalizeConfigComparisonValue(right[key]);
  });
}

function getSpecializationBonusAnywhere(data, specializationName) {
  const normalizedSpecialization = normalizePrerequisiteText(specializationName);
  let bestBonus = 0;

  for (const ability of data?.abilities ?? []) {
    for (const specialization of ability?.specializations ?? []) {
      if (normalizePrerequisiteText(specialization?.name) !== normalizedSpecialization) continue;

      const bonus = Number(specialization?.bonus ?? 0);
      if (Number.isFinite(bonus)) {
        bestBonus = Math.max(bestBonus, bonus);
      }
    }
  }

  return bestBonus;
}


function getSpecializationBonusForAbility(data, abilityName, specializationName) {
  const normalizedAbility = normalizePrerequisiteText(abilityName);
  const normalizedSpecialization = normalizePrerequisiteText(specializationName);
  const ability = (data?.abilities ?? []).find((item) => {
    return normalizePrerequisiteText(item?.name) === normalizedAbility
      || normalizePrerequisiteText(item?.id) === normalizedAbility;
  });

  if (!ability || !Array.isArray(ability.specializations)) {
    return 0;
  }

  let bestBonus = 0;

  for (const specialization of ability.specializations) {
    if (normalizePrerequisiteText(specialization?.name) !== normalizedSpecialization) continue;

    const bonus = Number(specialization?.bonus ?? 0);
    if (Number.isFinite(bonus)) {
      bestBonus = Math.max(bestBonus, bonus);
    }
  }

  return bestBonus;
}

function hasQualityNamed(data, qualityName) {
  const normalizedQuality = normalizePrerequisiteText(qualityName);

  return (data?.traits?.qualities ?? []).some((quality) => {
    return normalizePrerequisiteText(quality?.name) === normalizedQuality;
  });
}

function getPrerequisiteText(item) {
  const system = getTraitSystemView(item);

  return String(system.prerequisite ?? system.flags?.prerequisite ?? "").trim();
}

function stripPrerequisitePrefix(value) {
  return String(value ?? "")
    .replace(/^\s*exige\s+/i, "")
    .trim();
}

function splitPrerequisiteAlternatives(value) {
  return String(value ?? "")
    .split(/\s+ou\s+/i)
    .map((part) => part.trim())
    .filter(Boolean);
}

function evaluateSinglePrerequisitePart(data, rawPart) {
  const part = stripPrerequisitePrefix(rawPart);
  if (!part) return { ok: true };

  const parentheticalParts = [];
  const withoutParentheses = part.replace(/\(([^)]+)\)/g, (_match, inner) => {
    parentheticalParts.push(inner.trim());
    return " ";
  }).trim();

  const checks = [withoutParentheses, ...parentheticalParts].map((item) => item.trim()).filter(Boolean);

  if (checks.length === 0) return { ok: true };

  for (const check of checks) {
    const specializationMatch = check.match(/^(.+?)\s+(\d+)\s*B$/i);

    if (specializationMatch) {
      const specializationName = specializationMatch[1].trim();
      const requiredBonus = Number(specializationMatch[2]);
      const actualBonus = getSpecializationBonusAnywhere(data, specializationName);

      if (actualBonus < requiredBonus) {
        return {
          ok: false,
          interpreted: true,
          message: `exige ${specializationName} ${requiredBonus}B`
        };
      }

      continue;
    }

    const abilityMatch = check.match(/^(.+?)\s+(\d+)$/i);

    if (abilityMatch) {
      const abilityName = abilityMatch[1].trim();
      const requiredRank = Number(abilityMatch[2]);
      const actualRank = getAbilityRank(data, abilityName);

      if (actualRank < requiredRank) {
        return {
          ok: false,
          interpreted: true,
          message: `exige ${abilityName} ${requiredRank}`
        };
      }

      continue;
    }

    if (!hasQualityNamed(data, check)) {
      return {
        ok: false,
        interpreted: true,
        message: `exige ${check}`
      };
    }
  }

  return { ok: true, interpreted: true };
}

function checkTraitPrerequisites(data, item) {
  const normalizedTraitName = normalizeTraitRepeatableName(item?.name);

  if (normalizedTraitName === "companheiro" && getAbilityRank(data, "Status") < 3) {
    return {
      ok: false,
      interpreted: true,
      message: "exige Status 3"
    };
  }

  if (normalizedTraitName === "companheiro animal") {
    if (getAbilityRank(data, "Lidar com Animais") < 3) {
      return {
        ok: false,
        interpreted: true,
        message: "exige Lidar com Animais 3"
      };
    }

    if (getSpecializationBonusForAbility(data, "Lidar com Animais", "Treinar") < 1) {
      return {
        ok: false,
        interpreted: true,
        message: "exige Lidar com Animais: Treinar 1B"
      };
    }
  }

  const prerequisite = getPrerequisiteText(item);
  const normalizedPrerequisite = normalizePrerequisiteText(prerequisite);

  if (!normalizedPrerequisite || normalizedPrerequisite === "-" || normalizedPrerequisite === "nenhum") {
    return { ok: true };
  }

  const prerequisiteWithoutPrefix = stripPrerequisitePrefix(prerequisite);
  const alternatives = splitPrerequisiteAlternatives(prerequisiteWithoutPrefix);

  if (alternatives.length > 1) {
    const failures = alternatives.map((alternative) => evaluateSinglePrerequisitePart(data, alternative));

    if (failures.some((result) => result.ok)) {
      return { ok: true };
    }

    return {
      ok: false,
      interpreted: failures.some((result) => result.interpreted),
      message: `exige ${alternatives.join(" ou ")}`
    };
  }

  const result = evaluateSinglePrerequisitePart(data, prerequisiteWithoutPrefix);

  if (!result.interpreted) {
    return {
      ok: true,
      warning: "Pré-requisito não interpretado automaticamente. Confirme manualmente com o mestre."
    };
  }

  return result;
}

function validateConfiguredTrait(data, item, configValues = {}) {
  const normalizedName = normalizeTraitRepeatableName(item?.name);

  if (normalizedName === "sangue dos andalos") {
    const abilityName = configValues.chosenAbility;

    if (!abilityName || getAbilityRank(data, abilityName) < 3) {
      return {
        ok: false,
        message: "Sangue dos Ândalos exige escolher uma habilidade com 3 ou mais graduações."
      };
    }
  }

  if (normalizedName === "companheiro") {
    if (!String(configValues.companionName ?? "").trim()) {
      return {
        ok: false,
        message: "Companheiro exige informar o nome do companheiro."
      };
    }
  }

  if (normalizedName === "companheiro animal") {
    if (!String(configValues.animalType ?? "").trim()) {
      return {
        ok: false,
        message: "Companheiro Animal exige escolher o tipo do animal."
      };
    }
  }

  if (normalizedName === "maestria em arma") {
    const weapon = findWeaponByConfigValues(data, configValues);

    if (!weapon) {
      return {
        ok: false,
        message: "Maestria em Arma exige escolher uma arma cadastrada na aba Combate."
      };
    }
  }

  if (normalizedName === "maestria em arma aprimorada") {
    const weapon = findWeaponByConfigValues(data, configValues);

    if (!weapon) {
      return {
        ok: false,
        message: "Maestria em Arma Aprimorada exige escolher uma arma cadastrada na aba Combate."
      };
    }

    if (!hasWeaponMastery(data, weapon)) {
      return {
        ok: false,
        message: `Maestria em Arma Aprimorada exige Maestria em Arma para ${getWeaponDisplayName(weapon)}.`
      };
    }
  }

  return { ok: true };
}

function isDuplicateTrait(trait, item, configValues, automation) {
  if (trait.name !== item.name || trait.itemType !== item.type) {
    return false;
  }

  const repeatable = Boolean(automation?.allowMultiple) || isRepeatableTraitName(item.name);

  if (!repeatable) {
    return true;
  }

  if (!hasMeaningfulConfigValues(configValues)) {
    return false;
  }

  const normalizedName = normalizeTraitRepeatableName(item.name);

  if (normalizedName === "maestria em arma" || normalizedName === "maestria em arma aprimorada") {
    const existingWeapon = getWeaponConfigComparisonValue(trait.configValues ?? {});
    const nextWeapon = getWeaponConfigComparisonValue(configValues ?? {});

    return Boolean(existingWeapon && nextWeapon && existingWeapon === nextWeapon);
  }

  return haveSameConfigValues(trait.configValues ?? {}, configValues ?? {});
}

function appendPendingConfigurationNote(notes = []) {
  const nextNotes = Array.isArray(notes) ? cloneData(notes) : [];
  const alreadyHasNote = nextNotes.some((note) => {
    return String(note?.text ?? note?.label ?? "") === PENDING_CONFIGURATION_NOTE;
  });

  if (!alreadyHasNote) {
    nextNotes.push({
      id: "configuracao-pendente-nota",
      type: "note",
      target: "manual",
      text: PENDING_CONFIGURATION_NOTE
    });
  }

  return nextNotes;
}

function getTraitTypeDebugValue(item) {
  const system = getTraitSystemView(item);

  return String(
    item?.getFlag?.(MODULE_ID, "traitType")
    ?? item?.flags?.[MODULE_ID]?.traitType
    ?? system?.flags?.traitType
    ?? system?.traitType
    ?? item?.system?.traitType
    ?? item?.system?.flags?.traitType
    ?? item?.type
    ?? ""
  );
}

function logTraitDropConfigurationIssue({ item, configs, configValues = {}, error, reason }) {
  const traitType = getTraitTypeDebugValue(item);
  const recognizedAsQuality = isQualityItem(item);
  const recognizedAsDefect = isDefectItem(item);
  const hadConfig = Array.isArray(configs) && configs.length > 0;

  console.error(`${MODULE_ID} | Erro ao abrir configuração da Qualidade.`, {
    traitName: item?.name ?? "",
    itemName: item?.name ?? "",
    itemType: item?.type ?? "",
    traitType,
    recognizedAsQuality,
    recognizedAsDefect,
    hadConfig,
    configs,
    configValues,
    reason,
    error,
    stack: error?.stack
  });
}
function createStoredTraitFromItem(item, configValues = {}, options = {}) {
  const automation = getTraitAutomationByName(item.name);
  const traitSystem = getTraitSystemView(item);

  const itemEffects = Array.isArray(traitSystem.effects) ? cloneData(traitSystem.effects) : [];
  const itemConfigs = Array.isArray(traitSystem.configs) ? cloneData(traitSystem.configs) : [];
  const itemNotes = Array.isArray(traitSystem.notes) ? cloneData(traitSystem.notes) : [];

  const automationEffects = Array.isArray(automation.effects) ? automation.effects : [];
  const automationConfigs = Array.isArray(automation.configs) ? automation.configs : [];
  const automationNotes = Array.isArray(automation.notes) ? automation.notes : [];

  const configs = automationConfigs.length > 0 ? automationConfigs : itemConfigs;
  const effectsSource = automationEffects.length > 0 ? automationEffects : itemEffects;
  const notesSource = automationNotes.length > 0 ? automationNotes : itemNotes;

  const preserveUnresolvedConfig = Boolean(options.configPending);
  const effects = preserveUnresolvedConfig ? cloneData(effectsSource) : resolveAutomationEffects(effectsSource, configValues);
  const notes = preserveUnresolvedConfig ? cloneData(notesSource) : resolveAutomationNotes(notesSource, configValues);

  return {
    id: createId(),
    name: item.name ?? "Característica",
    itemType: item.type ?? "",
    sourceUuid: item.uuid ?? "",
    category: traitSystem.category ?? "",
    prerequisite: traitSystem.prerequisite ?? traitSystem.flags?.prerequisite ?? "",
    description: stripAutomationPlaceholderHtml(traitSystem.description ?? ""),
    effects,
    configs,
    configValues: cloneData(configValues),
    notes: options.configPending ? appendPendingConfigurationNote(notes) : notes,
    configPending: Boolean(options.configPending),
    destinyPaid: Boolean(options.destinyPaid),
    paidWithDestiny: Boolean(options.destinyPaid),
    destinyCost: options.destinyPaid ? normalizeDestinyNumber(options.destinyCost, 1) || 1 : 0,
    flags: cloneData(traitSystem.flags ?? {}),
    automationVersion: automationEffects.length > 0 || automationConfigs.length > 0 || automationNotes.length > 0
      ? TRAIT_AUTOMATION_VERSION
      : traitSystem.automationVersion ?? ""
  };
}

async function openStoredTrait(trait) {
  if (!trait) return;

  const configLines = Object.entries(trait.configValues ?? {})
    .filter(([, value]) => value)
    .map(([key, value]) => `<li><strong>${escapeHTML(key)}:</strong> ${escapeHTML(value)}</li>`)
    .join("");

  const notesHtml = Array.isArray(trait.notes) && trait.notes.length > 0
    ? `
      <hr>
      <p><strong>Notas manuais:</strong></p>
      <ul>
        ${trait.notes.map((note) => `<li>${escapeHTML(note.text ?? note.label ?? "")}</li>`).join("")}
      </ul>
    `
    : "";

  new Dialog({
    title: trait.name ?? "Característica",
    content: `
      <section class="got-roll-card">
        <header class="got-roll-header">
          <h2>${escapeHTML(trait.name ?? "Característica")}</h2>
          <span>${escapeHTML(trait.category ?? "")}</span>
        </header>

        ${trait.prerequisite ? `<p><strong>Pré-requisito:</strong> ${escapeHTML(trait.prerequisite)}</p>` : ""}

        ${configLines ? `
          <p><strong>Configuração:</strong></p>
          <ul>${configLines}</ul>
        ` : ""}

        <div>${stripAutomationPlaceholderHtml(trait.description) || "<p>Sem descrição.</p>"}</div>

        ${notesHtml}
      </section>
    `,
    buttons: {
      source: {
        label: "Abrir origem",
        callback: async () => {
          if (!trait.sourceUuid) return;

          const source = await fromUuid(trait.sourceUuid);
          source?.sheet?.render(true);
        }
      },
      ok: {
        label: "Fechar"
      }
    },
    default: "ok"
  }).render(true);
}

export class CharacterSheetApp extends Application {
  constructor(document, options = {}) {
    super(options);

    this.originalDocument = document;
    this.document = getPersistentActor(document);

    const sourceData = this.document.getFlag(MODULE_ID, CHARACTER_FLAG);
    const missingDestinyPoints = !sourceData?.destinyPoints || typeof sourceData.destinyPoints !== "object";
    const missingAbilitySpecializations = Array.isArray(sourceData?.abilities)
      && sourceData.abilities.some((ability) => !Array.isArray(ability?.specializations));
    const missingTraits = !sourceData?.traits || typeof sourceData.traits !== "object";
    const missingDerived = !sourceData?.derived || typeof sourceData.derived !== "object";
    const missingInventoryItems = !Array.isArray(sourceData?.inventory?.items);
    const missingBannerData = !sourceData?.visuals
      || sourceData.visuals.themeBanner === undefined
      || sourceData.visuals.houseBanner === undefined
      || sourceData.visuals.personalBanner === undefined
      || sourceData.visuals.bannerDisplaySource === undefined
      || sourceData.visuals.frameStyle === undefined;

    const normalized = normalizeCharacterData(mergeWithDefault(sourceData));

    this.data = normalized.data;
    this.needsDefaultDataMigration = normalized.migrated
      || missingDestinyPoints
      || missingAbilitySpecializations
      || missingTraits
      || missingDerived
      || missingInventoryItems
      || missingBannerData;

    const storedActiveTab = ACTIVE_TAB_BY_DOCUMENT.get(getActiveTabStorageKey(this.document));
    this.activeTab = normalizeCharacterTab(options.activeTab ?? storedActiveTab ?? this.activeTab ?? "geral");
    ACTIVE_TAB_BY_DOCUMENT.set(getActiveTabStorageKey(this.document), this.activeTab);
    this.editingAbilities = false;
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "got-character-sheet",
      classes: ["got-beautiful-sheet", "got-character-sheet-app"],
      title: "Ficha de Personagem GOT",
      template: "modules/got-beautiful-sheet/templates/character-sheet.hbs",
      width: 940,
      height: 820,
      resizable: true
    });
  }

  get title() {
    const name = this.data?.identity?.name || this.document?.name || "Personagem";
    return `Ficha GOT: ${name}`;
  }

  getDragonOptions() {
    const linkedDragonUuid = this.data?.valyrian?.linkedDragonUuid ?? "";

    return game.actors.contents
      .filter(isDragonActor)
      .map((actor) => {
        return {
          name: actor.name,
          uuid: actor.uuid,
          selected: actor.uuid === linkedDragonUuid
        };
      })
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  getBannerView() {
    const mainBanner = getResolvedMainBanner(this.data);
    const themeBanner = getThemeWatermarkBanner(this.data);
    const selectedSource = normalizeBannerDisplaySource(this.data?.visuals?.bannerDisplaySource);

    return {
      main: {
        source: mainBanner.source,
        sourceLabel: getBannerSourceLabel(mainBanner.source),
        path: mainBanner.path
      },

      watermark: {
        path: themeBanner,
        cssUrl: cssUrlValue(themeBanner),
        hasImage: Boolean(themeBanner)
      },

      sources: {
        theme: {
          id: "theme",
          label: "Estandarte do Tema",
          path: String(this.data?.visuals?.themeBanner ?? "").trim(),
          selected: selectedSource === "theme"
        },
        house: {
          id: "house",
          label: "Estandarte da Casa",
          path: String(this.data?.visuals?.houseBanner || this.data?.visuals?.houseCrest || "").trim(),
          selected: selectedSource === "house"
        },
        personal: {
          id: "personal",
          label: "Estandarte Pessoal",
          path: String(this.data?.visuals?.personalBanner ?? "").trim(),
          selected: selectedSource === "personal"
        }
      }
    };
  }

  async getData() {
    if (this.needsDefaultDataMigration) {
      this.needsDefaultDataMigration = false;
      await this.document.setFlag(MODULE_ID, CHARACTER_FLAG, cloneData(this.data));
    }

    this.activeTab = normalizeCharacterTab(this.activeTab);
    ACTIVE_TAB_BY_DOCUMENT.set(getActiveTabStorageKey(this.document), this.activeTab);

    const tabs = {
      geral: this.activeTab === "geral",
      habilidades: this.activeTab === "habilidades",
      combate: this.activeTab === "combate",
      intriga: this.activeTab === "intriga",
      qualidades: this.activeTab === "qualidades",
      inventario: this.activeTab === "inventario",
      visuais: this.activeTab === "visuais"
    };

    const abilitiesView = this.data.abilities.map((ability, abilityIndex) => {
      return {
        ...ability,
        abilityIndex,
        editingAbilities: this.editingAbilities,
        specializations: (ability.specializations ?? []).map((specialization, specializationIndex) => {
          return {
            ...specialization,
            specializationIndex
          };
        })
      };
    }).sort(sortByNamePtBr);

    const destinyPoints = applyCalculatedDestinyPoints(this.data);

    const qualityItems = (this.data.traits?.qualities ?? [])
      .map(toOwnedTraitView)
      .sort(sortByNamePtBr);

    const defectItems = (this.data.traits?.defects ?? [])
      .map(toOwnedTraitView)
      .sort(sortByNamePtBr);

    const derivedStats = buildDerivedStatsView(this.data);

    const weaponItems = (this.data.combat?.weapons ?? []).map((weapon, weaponIndex) => {
      return buildWeaponItemView(this.data, weapon, weaponIndex);
    });

    const inventoryItems = (this.data.inventory?.items ?? []).map((item, itemIndex) => {
      return {
        ...item,
        itemIndex
      };
    });

    const bannerView = this.getBannerView();

    return {
      document: this.document,
      documentName: this.document?.name ?? "",
      uuid: this.document?.uuid ?? "",
      data: this.data,
      destinyPoints,
      bannerView,
      watermarkStyle: `--got-theme-banner-url: ${bannerView.watermark.cssUrl};`,
      derivedStats,
      abilitiesView,
      weaponItems,
      inventoryItems,
      hasInventoryItems: inventoryItems.length > 0,
      qualityItems,
      defectItems,
      hasQualityItems: qualityItems.length > 0,
      hasDefectItems: defectItems.length > 0,
      editingAbilities: this.editingAbilities,
      activeTab: this.activeTab,
      tabs,
      dragonOptions: this.getDragonOptions(),
      hasLinkedDragon: Boolean(this.data?.valyrian?.linkedDragonUuid),
      isGM: game.user.isGM
    };
  }

  _getScrollElement(selector) {
    if (!selector) return null;

    return this.element?.find?.(selector)?.[0]
      ?? this.element?.[0]?.querySelector?.(selector)
      ?? null;
  }

  _captureScrollPosition() {
    const selectors = [".got-character-body", ".window-content"];
    const snapshot = [];

    for (const selector of selectors) {
      const element = this._getScrollElement(selector);

      if (!element) continue;

      snapshot.push({
        selector,
        top: element.scrollTop ?? 0,
        left: element.scrollLeft ?? 0
      });
    }

    return snapshot;
  }

  _restoreScrollPosition(snapshot = []) {
    for (const item of snapshot) {
      const element = this._getScrollElement(item.selector);

      if (!element) continue;

      element.scrollTop = item.top ?? 0;
      element.scrollLeft = item.left ?? 0;
    }
  }

  _restorePendingScrollPosition() {
    const snapshot = this._pendingScrollPosition;

    if (!Array.isArray(snapshot) || snapshot.length === 0) {
      return;
    }

    this._pendingScrollPosition = null;

    const restore = () => this._restoreScrollPosition(snapshot);
    const scheduleFrame = globalThis.requestAnimationFrame ?? ((callback) => setTimeout(callback, 0));

    restore();
    scheduleFrame(() => {
      restore();
      scheduleFrame(restore);
    });
  }

  _renderPreservingScroll(force = false) {
    this._pendingScrollPosition = this._captureScrollPosition();
    return this.render(force);
  }

  activateListeners(html) {
    super.activateListeners(html);

    html.find("[data-tab-button]").on("click", this._onChangeTab.bind(this));
    html.find("[data-path]").on("change", this._onFieldChange.bind(this));

    html.find("[data-action='save']").on("click", this._onSaveClick.bind(this));
    html.find("[data-action='reset']").on("click", this._onResetClick.bind(this));
    html.find("[data-action='pick-image']").on("click", this._onPickImage.bind(this));
    html.find("[data-action='copy-uuid']").on("click", this._onCopyUuid.bind(this));

    html.find("[data-action='set-banner-display-source']").on("change", this._onSetBannerDisplaySource.bind(this));

    html.find("[data-action='gm-link-dragon']").on("change", this._onGmLinkDragon.bind(this));
    html.find("[data-action='gm-open-linked-dragon']").on("click", this._onGmOpenLinkedDragon.bind(this));
    html.find("[data-action='gm-clear-linked-dragon']").on("click", this._onGmClearLinkedDragon.bind(this));

    html.find("[data-action='roll-ability']").on("click", this._onRollAbility.bind(this));
    html.find("[data-action='roll-specialization']").on("click", this._onRollSpecialization.bind(this));
    html.find("[data-action='toggle-abilities-edit']").on("click", this._onToggleAbilitiesEdit.bind(this));
    html.find("[data-action='add-specialization']").on("click", this._onAddSpecialization.bind(this));
    html.find("[data-action='remove-specialization']").on("click", this._onRemoveSpecialization.bind(this));

    html.find("[data-action='add-weapon']").on("click", this._onAddWeapon.bind(this));
    html.find("[data-action='remove-weapon']").on("click", this._onRemoveWeapon.bind(this));

    html.find("[data-action='add-inventory-item']").on("click", this._onAddInventoryItem.bind(this));
    html.find("[data-action='remove-inventory-item']").on("click", this._onRemoveInventoryItem.bind(this));

    html.find("[data-action='open-quality-item']").on("click", this._onOpenQualityItem.bind(this));
    html.find("[data-action='remove-quality-item']").on("click", this._onRemoveQualityItem.bind(this));
    html.find("[data-action='toggle-quality-destiny-paid']").on("change", this._onToggleQualityDestinyPaid.bind(this));

    html.find("[data-action='spend-destiny']").on("click", this._onSpendDestiny.bind(this));
    html.find("[data-action='burn-destiny']").on("click", this._onBurnDestiny.bind(this));
    html.find("[data-action='restore-destiny']").on("click", this._onRestoreDestiny.bind(this));

    html.find("[data-action='open-defect-item']").on("click", this._onOpenDefectItem.bind(this));
    html.find("[data-action='remove-defect-item']").on("click", this._onRemoveDefectItem.bind(this));

    html.find(".got-weapon-card").on("dragenter dragover", this._onWeaponCardDragEnter.bind(this));
    html.find(".got-weapon-card").on("dragleave", this._onWeaponCardDragLeave.bind(this));
    html.on("dragover", this._onDragOver.bind(this));
    html.on("drop", this._onDropItem.bind(this));

    this._restorePendingScrollPosition();
  }

  async saveData({ notify = false } = {}) {
    this.activeTab = normalizeCharacterTab(this.activeTab);
    ACTIVE_TAB_BY_DOCUMENT.set(getActiveTabStorageKey(this.document), this.activeTab);

    await this.document.setFlag(MODULE_ID, CHARACTER_FLAG, cloneData(this.data));
    await this.syncActorVisuals();

    if (notify) {
      ui.notifications.info("Ficha GOT salva e visuais sincronizados.");
    }
  }

  async syncActorVisuals() {
    if (this.document?.documentName !== "Actor") {
      console.warn(`${MODULE_ID} | Documento não é Actor. Visuais não sincronizados.`);
      return;
    }

    const actor = this.document;

    const actorName = String(this.data?.identity?.name ?? "").trim();
    const portrait = String(this.data?.visuals?.portrait ?? "").trim();
    const mapToken = String(this.data?.visuals?.mapToken ?? "").trim();

    const actorUpdates = {};
    const desiredActorImage = portrait || actor.img;
    const desiredTokenImage = mapToken || portrait || actor.prototypeToken?.texture?.src || actor.img;

    if (actorName && actor.name !== actorName) {
      actorUpdates.name = actorName;
    }

    if (desiredActorImage && actor.img !== desiredActorImage) {
      actorUpdates.img = desiredActorImage;
    }

    if (desiredTokenImage) {
      actorUpdates["prototypeToken.texture.src"] = desiredTokenImage;
      actorUpdates["prototypeToken.name"] = actorName || actor.name;
      actorUpdates["prototypeToken.actorLink"] = false;
      actorUpdates["prototypeToken.disposition"] = actor.prototypeToken?.disposition ?? 0;
    }

    if (Object.keys(actorUpdates).length > 0) {
      await actor.update(actorUpdates);
      console.log(`${MODULE_ID} | Personagem/token prototype atualizado`, actorUpdates);
    }

    const placedTokenDocuments = getPlacedTokenDocumentsForActor(actor);

    for (const tokenDocument of placedTokenDocuments) {
      const tokenUpdates = {};

      if (desiredTokenImage) {
        tokenUpdates["texture.src"] = desiredTokenImage;
      }

      if (actorName) {
        tokenUpdates.name = actorName;
      }

      if (Object.keys(tokenUpdates).length > 0) {
        await tokenDocument.update(tokenUpdates);
      }
    }

    if (placedTokenDocuments.length > 0) {
      console.log(`${MODULE_ID} | Tokens do personagem atualizados no mapa: ${placedTokenDocuments.length}`);
    }

    refreshActorDirectory();
  }

  async _onChangeTab(event) {
    event.preventDefault();

    const requestedTab = event.currentTarget.dataset.tabButton;
    if (!requestedTab) return;

    const tab = normalizeCharacterTab(requestedTab);

    this.activeTab = tab;
    ACTIVE_TAB_BY_DOCUMENT.set(getActiveTabStorageKey(this.document), this.activeTab);
    this._renderPreservingScroll(false);
  }

  async _onFieldChange(event) {
    const input = event.currentTarget;
    const path = input.dataset.path ?? input.name ?? "";

    if (!path) return;

    const value = readInputValue(input);

    setByPath(this.data, path, value);

    if (path === "visuals.houseBanner") {
      this.data.visuals.houseCrest = value;
    }

    await this.saveData();
    this._renderPreservingScroll(false);
  }

  async _onSaveClick(event) {
    event.preventDefault();
    await this.saveData({ notify: true });
  }

  async _onResetClick(event) {
    event.preventDefault();

    const confirmed = await Dialog.confirm({
      title: "Resetar Ficha GOT",
      content: "<p>Isso vai apagar os dados novos desta ficha salvos pelo módulo. O Actor original não será apagado.</p>",
      yes: () => true,
      no: () => false,
      defaultYes: false
    });

    if (!confirmed) return;

    this.data = getDefaultCharacterData();
    await this.saveData({ notify: true });
    this._renderPreservingScroll(true);
  }

  async _onPickImage(event) {
    event.preventDefault();

    const targetPath = event.currentTarget.dataset.path;
    if (!targetPath) return;

    const current = foundry.utils.getProperty(this.data, targetPath) ?? "";

    new FilePicker({
      type: "image",
      current,
      callback: async (selectedPath) => {
        setByPath(this.data, targetPath, selectedPath);

        if (targetPath === "visuals.houseBanner") {
          this.data.visuals.houseCrest = selectedPath;
        }

        await this.saveData({ notify: true });
        this._renderPreservingScroll(false);
      }
    }).render(true);
  }

  async _onCopyUuid(event) {
    event.preventDefault();

    const uuid = this.document?.uuid ?? "";

    if (!uuid) {
      ui.notifications.warn("UUID indisponível.");
      return;
    }

    try {
      if (game.clipboard?.copyPlainText) {
        await game.clipboard.copyPlainText(uuid);
      } else if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(uuid);
      } else {
        throw new Error("Clipboard API indisponível.");
      }

      ui.notifications.info("UUID copiado.");
    } catch (error) {
      console.warn(`${MODULE_ID} | Falha ao copiar UUID.`, error);
      ui.notifications.warn("Não foi possível copiar o UUID.");
    }
  }

  async _onSetBannerDisplaySource(event) {
    const input = event.currentTarget;
    const source = normalizeBannerDisplaySource(input.value);

    this.data.visuals.bannerDisplaySource = source;

    await this.saveData();
    this._renderPreservingScroll(false);
  }

  async _onGmLinkDragon(event) {
    event.preventDefault();

    if (!game.user.isGM) {
      ui.notifications.warn("Apenas o Mestre pode vincular dragões.");
      return;
    }

    const uuid = event.currentTarget.value;

    if (!uuid) {
      this.data.valyrian.linkedDragonUuid = "";
      this.data.valyrian.linkedDragonName = "";
      await this.saveData({ notify: true });
      this._renderPreservingScroll(false);
      return;
    }

    const dragon = await fromUuid(uuid);

    if (!dragon) {
      ui.notifications.warn("Dragão não encontrado ou inacessível.");
      return;
    }

    this.data.valyrian.enabled = true;
    this.data.valyrian.canRideDragon = true;
    this.data.valyrian.linkedDragonUuid = dragon.uuid;
    this.data.valyrian.linkedDragonName = dragon.name;

    await this.saveData({ notify: true });
    this._renderPreservingScroll(false);
  }

  async _onGmOpenLinkedDragon(event) {
    event.preventDefault();

    if (!game.user.isGM) {
      ui.notifications.warn("Apenas o Mestre pode abrir a ficha do dragão por este vínculo.");
      return;
    }

    const uuid = this.data?.valyrian?.linkedDragonUuid;

    if (!uuid) {
      ui.notifications.warn("Nenhum dragão vinculado.");
      return;
    }

    const dragon = await fromUuid(uuid);

    if (!dragon) {
      ui.notifications.warn("Dragão vinculado não encontrado ou inacessível.");
      return;
    }

    dragon.sheet?.render(true);
  }

  async _onGmClearLinkedDragon(event) {
    event.preventDefault();

    if (!game.user.isGM) {
      ui.notifications.warn("Apenas o Mestre pode remover vínculos de dragão.");
      return;
    }

    this.data.valyrian.linkedDragonUuid = "";
    this.data.valyrian.linkedDragonName = "";

    await this.saveData({ notify: true });
    this._renderPreservingScroll(false);
  }

  async _onToggleAbilitiesEdit(event) {
    event.preventDefault();

    this.editingAbilities = !this.editingAbilities;
    this._renderPreservingScroll(false);
  }

  async _onRollAbility(event) {
    event.preventDefault();

    if (this.editingAbilities) return;

    const abilityId = event.currentTarget.dataset.abilityId;
    const ability = this.data.abilities.find((item) => item.id === abilityId);

    if (!ability) return;

    await rollKeepHighest({
      document: this.document,
      label: ability.name || "Habilidade",
      rank: ability.rank,
      bonusDice: 0,
      flavor: ""
    });
  }

  async _onRollSpecialization(event) {
    event.preventDefault();

    if (this.editingAbilities) return;

    const abilityId = event.currentTarget.dataset.abilityId;
    const specializationId = event.currentTarget.dataset.specializationId;
    const ability = this.data.abilities.find((item) => item.id === abilityId);
    const specialization = ability?.specializations?.find((item) => item.id === specializationId);

    if (!ability || !specialization) return;

    await rollKeepHighest({
      document: this.document,
      label: `${ability.name || "Habilidade"}: ${specialization.name || "Especialização"}`,
      rank: ability.rank,
      bonusDice: specialization.bonus,
      flavor: `${specialization.bonus || 0}B`
    });
  }

  async _onAddSpecialization(event) {
    event.preventDefault();

    const abilityId = event.currentTarget.dataset.abilityId;
    const ability = this.data.abilities.find((item) => item.id === abilityId);

    if (!ability) return;
    if (!Array.isArray(ability.specializations)) ability.specializations = [];

    ability.specializations.push({
      id: createId(),
      name: "",
      bonus: 0
    });

    this.editingAbilities = true;

    await this.saveData();
    this._renderPreservingScroll(false);
  }

  async _onRemoveSpecialization(event) {
    event.preventDefault();

    const abilityId = event.currentTarget.dataset.abilityId;
    const specializationId = event.currentTarget.dataset.specializationId;
    const ability = this.data.abilities.find((item) => item.id === abilityId);

    if (!ability || !Array.isArray(ability.specializations)) return;

    ability.specializations = ability.specializations.filter((specialization) => specialization.id !== specializationId);

    await this.saveData();
    this._renderPreservingScroll(false);
  }

  async _onAddWeapon(event) {
    event.preventDefault();

    if (!Array.isArray(this.data.combat.weapons)) {
      this.data.combat.weapons = [];
    }

    this.data.combat.weapons.push(createDefaultWeapon());

    await this.saveData();
    this._renderPreservingScroll(false);
  }

  async _onRemoveWeapon(event) {
    event.preventDefault();

    const weaponId = event.currentTarget.dataset.weaponId;
    this.data.combat.weapons = this.data.combat.weapons.filter((weapon) => weapon.id !== weaponId);

    if (this.data.combat.weapons.length === 0) {
      this.data.combat.weapons.push(createDefaultWeapon());
    }

    await this.saveData();
    this._renderPreservingScroll(false);
  }

  async _onAddInventoryItem(event) {
    event.preventDefault();

    if (!this.data.inventory || typeof this.data.inventory !== "object") {
      this.data.inventory = {};
    }

    if (!Array.isArray(this.data.inventory.items)) {
      this.data.inventory.items = [];
    }

    this.data.inventory.items.push(createDefaultInventoryItem());

    await this.saveData();
    this._renderPreservingScroll(false);
  }

  async _onRemoveInventoryItem(event) {
    event.preventDefault();

    const itemId = event.currentTarget.dataset.itemId;

    if (!Array.isArray(this.data.inventory.items)) {
      this.data.inventory.items = [];
    }

    this.data.inventory.items = this.data.inventory.items.filter((item) => item.id !== itemId);

    if (this.data.inventory.items.length === 0) {
      this.data.inventory.items.push(createDefaultInventoryItem());
    }

    await this.saveData();
    this._renderPreservingScroll(false);
  }

  async _onOpenQualityItem(event) {
    event.preventDefault();

    const trait = getStoredQuality(this.data, event.currentTarget.dataset.itemId);

    await openStoredTrait(trait);
  }

  async _onRemoveQualityItem(event) {
    event.preventDefault();

    const trait = getStoredQuality(this.data, event.currentTarget.dataset.itemId);

    if (!trait) return;

    const confirmed = await Dialog.confirm({
      title: "Remover Qualidade",
      content: `<p>Remover <strong>${escapeHTML(trait.name)}</strong> deste personagem?</p>`,
      yes: () => true,
      no: () => false,
      defaultYes: false
    });

    if (!confirmed) return;

    this.data.traits.qualities = this.data.traits.qualities.filter((item) => item.id !== trait.id);

    await this.saveData();
    this._renderPreservingScroll(false);
  }

  async _onToggleQualityDestinyPaid(event) {
    const input = event.currentTarget;
    const trait = getStoredQuality(this.data, input.dataset.itemId);

    if (!trait) return;

    const checked = Boolean(input.checked);

    if (checked && !getQualityDestinyCost(trait)) {
      const available = calculateDestinyPoints(this.data).available;

      if (available <= 0) {
        input.checked = false;
        ui.notifications.warn("Nenhum Ponto de Destino disponivel para investir nesta Qualidade.");
        return;
      }
    }

    trait.destinyPaid = checked;
    trait.paidWithDestiny = checked;
    trait.destinyCost = checked ? 1 : 0;

    applyCalculatedDestinyPoints(this.data);
    await this.saveData();
    this._renderPreservingScroll(false);
  }

  async _onSpendDestiny(event) {
    event.preventDefault();

    const destiny = applyCalculatedDestinyPoints(this.data);

    if (destiny.available <= 0) {
      ui.notifications.warn("Nenhum Ponto de Destino disponivel para gastar.");
      return;
    }

    const reason = await promptDestinyUse({
      title: "Gastar Ponto de Destino",
      message: "Gastar 1 Ponto de Destino?",
      label: "Uso / motivo:",
      placeholder: "Ex.: +1B em um teste, efeito narrativo, ativar regra do livro..."
    });

    if (reason === null) return;

    this.data.destinyPoints.spent = normalizeDestinyNumber(this.data.destinyPoints.spent, 0) + 1;
    const updated = applyCalculatedDestinyPoints(this.data);

    await this.saveData();

    const actorName = this.data?.identity?.name || this.document?.name || "Personagem";
    await postDestinyChatMessage({
      actor: this.document,
      actorName,
      title: "Ponto de Destino gasto",
      lines: [
        `${actorName} gastou 1 Ponto de Destino.`,
        reason ? `Uso: ${reason}` : "Uso: nao informado.",
        `Disponiveis restantes: ${updated.available}`
      ]
    });

    this._renderPreservingScroll(false);
  }

  async _onBurnDestiny(event) {
    event.preventDefault();

    const destiny = applyCalculatedDestinyPoints(this.data);

    if (destiny.available <= 0) {
      ui.notifications.warn("Nenhum Ponto de Destino disponivel para queimar.");
      return;
    }

    const reason = await promptDestinyUse({
      title: "Queimar Ponto de Destino",
      message: "Queimar um Ponto de Destino reduz o Total permanentemente em 1. Continuar?",
      label: "Motivo / efeito:",
      placeholder: "Ex.: evitar a morte, mudar a historia, efeito dramatico..."
    });

    if (reason === null) return;

    this.data.destinyPoints.total = Math.max(0, normalizeDestinyNumber(this.data.destinyPoints.total, 0) - 1);
    const updated = applyCalculatedDestinyPoints(this.data);

    await this.saveData();

    const actorName = this.data?.identity?.name || this.document?.name || "Personagem";
    await postDestinyChatMessage({
      actor: this.document,
      actorName,
      title: "Ponto de Destino queimado",
      lines: [
        `${actorName} queimou 1 Ponto de Destino.`,
        `Total atual: ${updated.total}`,
        reason ? `Motivo: ${reason}` : "Motivo: nao informado."
      ]
    });

    this._renderPreservingScroll(false);
  }
  async _onRestoreDestiny(event) {
    event.preventDefault();

    const destiny = applyCalculatedDestinyPoints(this.data);

    if (destiny.spent <= 0) {
      ui.notifications.warn("Nao ha Pontos de Destino gastos para restaurar.");
      return;
    }

    const confirmed = await Dialog.confirm({
      title: "Restaurar Pontos de Destino",
      content: `<p>Restaurar todos os Pontos de Destino gastos nesta sessao?</p><p><strong>Isso nao restaura pontos queimados.</strong></p>`,
      yes: () => true,
      no: () => false,
      defaultYes: false
    });

    if (!confirmed) return;

    this.data.destinyPoints.spent = 0;
    this.data.destinyPoints.gastos = 0;
    const updated = applyCalculatedDestinyPoints(this.data);

    await this.saveData();

    const actorName = this.data?.identity?.name || this.document?.name || "Personagem";
    await postDestinyChatMessage({
      actor: this.document,
      actorName,
      title: "Pontos de Destino restaurados",
      lines: [
        `${actorName} restaurou os Pontos de Destino gastos no fim da sessao.`,
        "Pontos queimados nao foram restaurados.",
        `Disponiveis: ${updated.available}`
      ]
    });

    this._renderPreservingScroll(false);
  }
  async _onOpenDefectItem(event) {
    event.preventDefault();

    const trait = getStoredDefect(this.data, event.currentTarget.dataset.itemId);

    await openStoredTrait(trait);
  }

  async _onRemoveDefectItem(event) {
    event.preventDefault();

    const trait = getStoredDefect(this.data, event.currentTarget.dataset.itemId);

    if (!trait) return;

    const confirmed = await Dialog.confirm({
      title: "Remover Defeito",
      content: `<p>Remover <strong>${escapeHTML(trait.name)}</strong> deste personagem?</p>`,
      yes: () => true,
      no: () => false,
      defaultYes: false
    });

    if (!confirmed) return;

    this.data.traits.defects = this.data.traits.defects.filter((item) => item.id !== trait.id);

    await this.saveData();
    this._renderPreservingScroll(false);
  }

  _onWeaponCardDragEnter(event) {
    event.preventDefault();
    event.currentTarget?.classList?.add("got-weapon-card-drop-hover");
  }

  _onWeaponCardDragLeave(event) {
    const relatedTarget = event.relatedTarget ?? event.originalEvent?.relatedTarget;

    if (relatedTarget && event.currentTarget?.contains?.(relatedTarget)) return;

    event.currentTarget?.classList?.remove("got-weapon-card-drop-hover");
  }

  _onDragOver(event) {
    event.preventDefault();

    const dataTransfer = event.originalEvent?.dataTransfer ?? event.dataTransfer;

    if (dataTransfer) {
      dataTransfer.dropEffect = "copy";
    }
  }

  async _onDropWeaponQualityItem(item, weaponId) {
    if (!weaponId) {
      ui.notifications.error("Não foi possível identificar a arma de destino.");
      return;
    }

    if (!this.data.combat || typeof this.data.combat !== "object") {
      this.data.combat = {};
    }

    if (!Array.isArray(this.data.combat.weapons)) {
      this.data.combat.weapons = [];
    }

    const weapon = this.data.combat.weapons.find((item) => item?.id === weaponId);

    if (!weapon) {
      ui.notifications.error("Não foi possível identificar a arma de destino.");
      return;
    }

    const qualityName = getWeaponQualityItemName(item);

    if (!qualityName) {
      ui.notifications.warn("Qualidade de Arma sem nome legível.");
      return;
    }

    const qualities = splitWeaponQualityText(weapon.qualities);
    const normalizedQualityName = normalizeGearComparisonText(qualityName);
    const alreadyOwned = qualities.some((quality) => normalizeGearComparisonText(quality) === normalizedQualityName);

    if (alreadyOwned) {
      ui.notifications.warn(`A arma já possui esta qualidade: ${qualityName}`);
      return;
    }

    qualities.push(qualityName);
    weapon.qualities = qualities.join(" | ");

    const qualityBulk = getWeaponQualityBulkValue(qualityName);

    if (qualityBulk !== null) {
      const currentBulk = Number(String(weapon.bulk ?? 0).replace(",", ".").match(/[+-]?\d+(?:\.\d+)?/)?.[0] ?? 0);
      weapon.bulk = Math.max(Number.isFinite(currentBulk) ? Math.trunc(currentBulk) : 0, qualityBulk);
    }

    if (this.activeTab !== "combate") {
      this.activeTab = "combate";
    }

    await this.saveData();

    ui.notifications.info(`Qualidade adicionada a ${normalizeGearText(weapon.name) || "arma"}: ${qualityName}`);
    this._renderPreservingScroll(true);
  }

  async _onDropArmorItem(item) {
    if (!this.data.combat || typeof this.data.combat !== "object") {
      this.data.combat = {};
    }

    if (!this.data.combat.armor || typeof this.data.combat.armor !== "object") {
      this.data.combat.armor = {
        name: "",
        value: 0,
        penalty: 0,
        bulk: 0
      };
    }

    const armor = createArmorFromGearItem(item);
    const currentArmorName = normalizeGearText(this.data.combat.armor?.name);

    if (currentArmorName) {
      const confirmed = await Dialog.confirm({
        title: "Substituir Armadura",
        content: `<p>Substituir <strong>${escapeHTML(currentArmorName)}</strong> por <strong>${escapeHTML(armor.name)}</strong>?</p>`,
        yes: () => true,
        no: () => false,
        defaultYes: false
      });

      if (!confirmed) {
        ui.notifications.warn("Substituição de armadura cancelada.");
        return;
      }
    }

    this.data.combat.armor = {
      ...this.data.combat.armor,
      ...armor
    };

    if (this.activeTab !== "combate") {
      this.activeTab = "combate";
    }

    await this.saveData();

    ui.notifications.info(`Armadura equipada: ${armor.name}`);
    this._renderPreservingScroll(true);
  }
  async _onDropGearItem(item, gearType) {
    if (gearType === "weaponQuality") {
      ui.notifications.warn("Qualidades de Arma ainda não entram direto na ficha. Arraste isso para uma arma.");
      return;
    }

    if (gearType === "armor") {
      await this._onDropArmorItem(item);
      return;
    }

    if (gearType === "equipment") {
      ui.notifications.warn("Equipamentos ainda não entram direto na ficha. Vamos implementar isso em Inventário.");
      return;
    }

    if (gearType !== "weapon" && gearType !== "shield") {
      ui.notifications.warn("A ficha aceita apenas Items de Qualidade, Defeito ou Equipamento GOT.");
      return;
    }

    if (!this.data.combat || typeof this.data.combat !== "object") {
      this.data.combat = {};
    }

    if (!Array.isArray(this.data.combat.weapons)) {
      this.data.combat.weapons = [];
    }

    const weapon = createWeaponFromGearItem(item, gearType);

    if (this.data.combat.weapons.length === 1 && isEmptyDefaultWeapon(this.data.combat.weapons[0])) {
      this.data.combat.weapons = [];
    }

    this.data.combat.weapons.push(weapon);

    if (this.activeTab !== "combate") {
      this.activeTab = "combate";
    }

    await this.saveData();

    const label = gearType === "shield" ? "Escudo" : "Arma";
    const action = gearType === "shield" ? "adicionado" : "adicionada";
    ui.notifications.info(`${label} ${action}: ${weapon.name || item.name}`);

    this._renderPreservingScroll(true);
  }

  async _onDropItem(event) {
    event.preventDefault();

    if (this.document?.documentName !== "Actor") {
      ui.notifications.warn("Só é possível adicionar Qualidades e Defeitos em Actors.");
      return;
    }

    const item = await getDroppedDocument(event);

    this.element?.find?.(".got-weapon-card-drop-hover")?.removeClass?.("got-weapon-card-drop-hover");

    if (!item) {
      ui.notifications.warn("Item arrastado não encontrado.");
      return;
    }

    if (!isTraitItem(item)) {
      const gearType = getGearType(item);

      if (gearType === "weaponQuality") {
        const weaponCard = getWeaponDropCardFromEvent(event);

        if (weaponCard) {
          await this._onDropWeaponQualityItem(item, weaponCard.dataset.weaponId);
        } else {
          await this._onDropGearItem(item, gearType);
        }

        return;
      }

      if (gearType) {
        await this._onDropGearItem(item, gearType);
        return;
      }

      ui.notifications.warn("A ficha aceita apenas Items de Qualidade, Defeito ou Equipamento GOT.");
      return;
    }

    if (!this.data.traits || typeof this.data.traits !== "object") {
      this.data.traits = {
        qualities: [],
        defects: []
      };
    }

    if (!Array.isArray(this.data.traits.qualities)) {
      this.data.traits.qualities = [];
    }

    if (!Array.isArray(this.data.traits.defects)) {
      this.data.traits.defects = [];
    }

    const targetList = isDefectItem(item) ? this.data.traits.defects : this.data.traits.qualities;

    const automation = getTraitAutomationByName(item.name);
    const configs = Array.isArray(automation.configs) ? automation.configs : [];

    const prerequisiteCheck = checkTraitPrerequisites(this.data, item);

    if (!prerequisiteCheck.ok) {
      ui.notifications.warn(`Pré-requisito não atendido: ${item.name} ${prerequisiteCheck.message}.`);
      return;
    }

    if (prerequisiteCheck.warning) {
      ui.notifications.warn(prerequisiteCheck.warning);
    }

    let configValues = {};
    let configPending = false;

    const configAvailability = validateTraitConfigAvailability(this.data, item, configs);

    if (!configAvailability.ok) {
      ui.notifications.warn(configAvailability.message);
      return;
    }

    if (configs.length > 0) {
      try {
        const configuredValues = await promptTraitConfiguration({
          item,
          configs,
          data: this.data
        });

        if (configuredValues && typeof configuredValues === "object") {
          configValues = configuredValues;
        } else {
          ui.notifications.warn(`Qualidade não adicionada: configuração cancelada.`);
          return;
        }
      } catch (error) {
        logTraitDropConfigurationIssue({
          item,
          configs,
          configValues,
          error,
          reason: "configuration-error"
        });
        ui.notifications.warn(`Erro ao abrir configuração de ${item.name}. Veja o console.`);
        return;
      }
    }

    const configuredTraitCheck = validateConfiguredTrait(this.data, item, configValues);

    if (!configuredTraitCheck.ok) {
      ui.notifications.warn(configuredTraitCheck.message);
      return;
    }

    const alreadyOwned = targetList.some((trait) => isDuplicateTrait(trait, item, configValues, automation));

    if (alreadyOwned) {
      ui.notifications.warn(`${getTraitTypeLabel(item)} já adicionado: ${item.name}`);
      return;
    }

    let destinyPaid = false;

    if (isQualityItem(item)) {
      applyCalculatedDestinyPoints(this.data);
      const destinyChoice = await promptQualityDestinyCost({
        item,
        data: this.data
      });

      if (destinyChoice === null) {
        ui.notifications.warn("Qualidade nao adicionada: custo de Ponto de Destino cancelado.");
        return;
      }

      destinyPaid = destinyChoice === "paid";
    }

    const storedTrait = createStoredTraitFromItem(item, configValues, {
      configPending,
      destinyPaid,
      destinyCost: destinyPaid ? 1 : 0
    });

    targetList.push(storedTrait);
    applyCalculatedDestinyPoints(this.data);

    if (this.activeTab !== "qualidades") {
      this.activeTab = "qualidades";
    }

    await this.saveData();

    ui.notifications.info(`${getTraitTypeLabel(item)} adicionado: ${item.name}`);

    this._renderPreservingScroll(true);
  }
}









