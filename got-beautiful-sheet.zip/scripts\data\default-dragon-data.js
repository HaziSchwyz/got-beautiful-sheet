export function getDefaultDragonData() {
  return {
    meta: {
      schemaVersion: 1,
      sheetType: "dragon",
      createdByModule: "got-beautiful-sheet"
    },

    visuals: {
      coverFrame: "",
      mainImage: "",
      mapToken: "",
      riderPortraitCustom: "",
      useLinkedRiderPortrait: true,

      colors: {
        primary: "#07111C",
        secondary: "#0A1D2C",
        accent: "#D4472F",
        coldAccent: "#2AA6B8",
        textMain: "#F2E7D8"
      }
    },

    rider: {
      name: "",
      documentUuid: ""
    },

    identity: {
      name: "",
      title: "",
      house: "",
      riderName: "",
      sex: "",
      age: "",
      birth: "",
      category: "",
      size: "",
      home: "",
      favoriteFood: ""
    },

    profile: {
      personality: "",
      appearance: "",
      temperament: "",
      bond: ""
    },

    combat: {
      combatDefense: {
        value: 0,
        max: 0
      },
      health: {
        value: 0,
        max: 0
      },
      movement: 0,
      flight: 0,
      armor: {
        name: "",
        value: 0,
        penalty: "",
        bulk: ""
      },

      wounds: {
        value: 0,
        max: 0
      },
      injuries: {
        value: 0,
        max: 0
      },

      attacks: [
        {
          id: crypto.randomUUID(),
          name: "Presas",
          test: "",
          damage: "",
          qualities: "",
          notes: ""
        },
        {
          id: crypto.randomUUID(),
          name: "Garras",
          test: "",
          damage: "",
          qualities: "",
          notes: ""
        },
        {
          id: crypto.randomUUID(),
          name: "Baforada",
          test: "",
          damage: "",
          qualities: "",
          notes: ""
        }
      ],

      basicActions: [
        {
          id: "ataque-padrao",
          name: "Ataque Padrão",
          actionType: "Ação Menor",
          test: "Teste de Conflito",
          description: "Ataque comum do dragão usando Presas, Garras ou Baforada."
        },
        {
          id: "ataque-dividido",
          name: "Ataque Dividido",
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "Divide dados de Luta entre múltiplos oponentes."
        },
        {
          id: "atacar-cavaleiro",
          name: "Atacar Cavaleiro",
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "Tenta atingir diretamente o cavaleiro/montador de um dragão inimigo."
        },
        {
          id: "imobilizar",
          name: "Imobilizar",
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "Tenta imobilizar outro dragão no ar enquanto estiver agarrando-o."
        },
        {
          id: "agarrar",
          name: "Agarrar",
          actionType: "Regra de ataque",
          test: "Teste de Conflito",
          description: "Aplica-se a ataques com a qualidade Agarrar."
        },
        {
          id: "prontidao",
          name: "Prontidão",
          actionType: "Ação Menor ou Maior",
          test: "Teste de Conflito",
          description: "Prepara um ataque ou movimento com condição definida."
        },
        {
          id: "mover-se",
          name: "Mover-se",
          actionType: "Ação Menor",
          test: "Teste de Conflito",
          description: "Move até o valor de Movimento do dragão."
        },
        {
          id: "correr",
          name: "Correr",
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "Move até quatro vezes o Movimento, modificado por Volume."
        },
        {
          id: "ajuda",
          name: "Ajuda",
          actionType: "Ação Menor",
          test: "Teste de Conflito",
          description: "Ajuda um aliado em um teste de habilidade."
        },
        {
          id: "esquiva",
          name: "Esquiva",
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "Rola Agilidade e substitui a Defesa em Combate até o próximo turno."
        },
        {
          id: "interagir",
          name: "Interagir",
          actionType: "Ação Menor",
          test: "Teste de Conflito",
          description: "Manipula objetos, abre portas, puxa alavancas ou interage com o ambiente."
        },
        {
          id: "passar",
          name: "Passar",
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "Não age no turno e recebe +2B no próximo teste."
        }
      ],

      trainedActions: [
        {
          id: "ataque-exploratorio",
          name: "Ataque Exploratório",
          trained: false,
          difficulty: 6,
          actionType: "Ação Menor",
          test: "Teste de Conflito",
          description: "O dragão ataca com cautela. Faz teste de Luta com -1D, mas recebe +5 em Defesa até o início da próxima rodada.",
          notes: ""
        },
        {
          id: "ataque-relampago",
          name: "Ataque Relâmpago",
          trained: false,
          difficulty: 6,
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "O dragão move-se em linha reta até sua velocidade de corrida e ataca unidades inimigas no caminho.",
          notes: ""
        },
        {
          id: "atropelar",
          name: "Atropelar",
          trained: false,
          difficulty: 3,
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "O dragão move-se em linha reta à velocidade de corrida e ataca unidades no caminho. Em acerto, causa +5 dano.",
          notes: ""
        },
        {
          id: "emboscar",
          name: "Emboscar",
          trained: false,
          difficulty: 3,
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "Só pode ser usado por dragão escondido. Causa +5 dano durante a primeira rodada de batalha.",
          notes: ""
        },
        {
          id: "empurrar",
          name: "Empurrar",
          trained: false,
          difficulty: 3,
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "O dragão faz teste de Luta contra Atletismo passivo do inimigo e empurra 10m por grau de sucesso.",
          notes: ""
        },
        {
          id: "envolver",
          name: "Envolver",
          trained: false,
          difficulty: 6,
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "O dragão envolve e agarra completamente um dragão inimigo, podendo fazer ataque livre se ele tentar sair.",
          notes: ""
        },
        {
          id: "fogo-de-supressao",
          name: "Fogo de Supressão",
          trained: false,
          difficulty: 3,
          actionType: "Ação Maior",
          test: "Teste de Conflito",
          description: "Usa Baforada para impedir movimento. Aumenta a dificuldade para dar ordens ao dragão alvo.",
          notes: ""
        },
        {
          id: "terra-arrasada",
          name: "Terra Arrasada",
          trained: false,
          difficulty: 3,
          actionType: "Ação Menor",
          test: "Teste de Conflito",
          description: "Destrói plantações, incendeia prédios e arrasa terras, reduzindo População e Riqueza do domínio.",
          notes: ""
        }
      ]
    },

    abilities: [
      {
        id: "status",
        name: "Status",
        rank: 2,
        specialties: ""
      },
      {
        id: "vontade",
        name: "Vontade",
        rank: 2,
        specialties: ""
      },
      {
        id: "astucia",
        name: "Astúcia",
        rank: 2,
        specialties: ""
      },
      {
        id: "percepcao",
        name: "Percepção",
        rank: 2,
        specialties: ""
      },
      {
        id: "agilidade",
        name: "Agilidade",
        rank: 2,
        specialties: ""
      },
      {
        id: "atletismo",
        name: "Atletismo",
        rank: 2,
        specialties: ""
      },
      {
        id: "vigor",
        name: "Vigor",
        rank: 2,
        specialties: ""
      },
      {
        id: "luta",
        name: "Luta",
        rank: 2,
        specialties: ""
      },
      {
        id: "pontaria",
        name: "Pontaria",
        rank: 2,
        specialties: ""
      },
      {
        id: "persuasao",
        name: "Persuasão",
        rank: 2,
        specialties: ""
      },
      {
        id: "enganacao",
        name: "Enganação",
        rank: 2,
        specialties: ""
      },
      {
        id: "lidar-com-animais",
        name: "Lidar com Animais",
        rank: 2,
        specialties: ""
      },
      {
        id: "conhecimento",
        name: "Conhecimento",
        rank: 2,
        specialties: ""
      },
      {
        id: "cura",
        name: "Cura",
        rank: 2,
        specialties: ""
      },
      {
        id: "furtividade",
        name: "Furtividade",
        rank: 2,
        specialties: ""
      },
      {
        id: "ladinagem",
        name: "Ladinagem",
        rank: 2,
        specialties: ""
      },
      {
        id: "sobrevivencia",
        name: "Sobrevivência",
        rank: 2,
        specialties: ""
      },
      {
        id: "guerra",
        name: "Guerra",
        rank: 2,
        specialties: ""
      },
      {
        id: "idioma",
        name: "Idioma",
        rank: 2,
        specialties: ""
      }
    ],

    qualities: [],

    flaws: [],

    notes: {
      lore: "",
      deeds: "",
      houseRelation: "",
      riderRelation: "",
      secrets: "",
      gmNotes: ""
    }
  };
}