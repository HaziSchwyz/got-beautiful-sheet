import { ARMOR_COMPENDIUM_DATA } from "../data/armor-compendium-data.js";

const MODULE_ID = "got-beautiful-sheet";
const PACK_ID = `${MODULE_ID}.got-armors`;

function normalizeKey(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function armorToItemData(armor) {
  return {
    name: armor.nome,
    type: "equippableItem",
    img: "icons/equipment/chest/breastplate-cuirass-steel-grey.webp",
    system: {},
    flags: {
      [MODULE_ID]: {
        gearType: "armor",
        group: armor.grupo,
        grupo: armor.grupo,
        value: armor.valor,
        valor: armor.valor,
        armorValue: armor.valor,
        va: armor.valor,
        penalty: armor.penalidade,
        penalidade: armor.penalidade,
        armorPenalty: armor.penalidade,
        bulk: armor.volume,
        volume: armor.volume,
        weight: armor.peso,
        peso: armor.peso,
        price: armor.preco,
        preco: armor.preco,
        notes: armor.notas,
        notas: armor.notas
      }
    }
  };
}

export async function seedArmorCompendium() {
  if (!game.user?.isGM) {
    ui.notifications.error("Apenas o Mestre pode popular o compendium de Armaduras GOT.");
    return;
  }

  const pack = game.packs.get(PACK_ID);

  if (!pack) {
    ui.notifications.error(`Compendium não encontrado: ${PACK_ID}. Reinicie o Foundry depois de alterar o module.json.`);
    return;
  }

  const wasLocked = pack.locked;

  if (pack.locked) {
    await pack.configure({ locked: false });
  }

  const existingDocuments = await pack.getDocuments();
  let created = 0;
  let updated = 0;

  for (const armor of ARMOR_COMPENDIUM_DATA) {
    const itemData = armorToItemData(armor);
    const existing = existingDocuments.find((document) => normalizeKey(document.name) === normalizeKey(itemData.name));

    if (existing) {
      await existing.update(itemData);
      updated += 1;
    } else {
      await Item.create(itemData, { pack: PACK_ID });
      created += 1;
    }
  }

  if (wasLocked) {
    await pack.configure({ locked: true });
  }

  ui.notifications.info(`Armaduras GOT populadas. Criadas: ${created}. Atualizadas: ${updated}.`);
  console.log(`${MODULE_ID} | Armaduras GOT populadas`, { created, updated });
}

globalThis.seedGotArmorCompendium = seedArmorCompendium;

await seedArmorCompendium();