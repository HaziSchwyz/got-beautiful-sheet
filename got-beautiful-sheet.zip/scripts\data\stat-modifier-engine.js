const MODULE_ID = "got-beautiful-sheet";

function cloneData(value) {
  if (globalThis.foundry?.utils?.deepClone) {
    return foundry.utils.deepClone(value);
  }

  return JSON.parse(JSON.stringify(value ?? null));
}

function toNumber(value, fallback = 0) {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : fallback;
  }

  const cleaned = String(value ?? "")
    .trim()
    .replace(",", ".")
    .replace(/[^\d.+-]/g, "");

  if (!cleaned) return fallback;

  const number = Number(cleaned);

  return Number.isFinite(number) ? number : fallback;
}

function toInteger(value, fallback = 0) {
  return Math.trunc(toNumber(value, fallback));
}

function normalizeKey(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}

function formatSigned(value) {
  const numericValue = toNumber(value, 0);
  const sign = numericValue >= 0 ? "+" : "";

  return `${sign}${numericValue}`;
}

function isCarried(value) {
  if (value === undefined || value === null) return true;
  if (typeof value === "boolean") return value;

  const normalized = normalizeKey(value);

  if (["false", "0", "nao", "não", "no", "off", "desmarcado"].includes(normalized)) {
    return false;
  }

  return true;
}

function getAbility(data, abilityName) {
  const wantedName = normalizeKey(abilityName);

  return (data?.abilities ?? []).find((ability) => {
    return normalizeKey(ability?.name) === wantedName || normalizeKey(ability?.id) === wantedName;
  }) ?? null;
}

function getAbilityRank(data, abilityName, fallback = 0) {
  const ability = getAbility(data, abilityName);

  return toInteger(ability?.rank, fallback);
}

function normalizeNameList(value) {
  if (Array.isArray(value)) {
    return value
      .map((item) => String(item ?? "").trim())
      .filter(Boolean);
  }

  if (value === undefined || value === null || value === "") {
    return [];
  }

  return [String(value).trim()].filter(Boolean);
}

function getSpecializationBonus(data, abilityName, specializationNames = []) {
  const ability = getAbility(data, abilityName);
  const wantedNames = normalizeNameList(specializationNames).map(normalizeKey);

  if (!ability || !Array.isArray(ability.specializations) || wantedNames.length === 0) {
    return 0;
  }

  let bestBonus = 0;

  for (const specialization of ability.specializations) {
    const specializationName = normalizeKey(specialization?.name);

    if (!wantedNames.includes(specializationName)) continue;

    bestBonus = Math.max(bestBonus, toInteger(specialization?.bonus, 0));
  }

  return bestBonus;
}

function getSpecializationBonusFromDescriptor(data, descriptor) {
  if (!descriptor || typeof descriptor !== "object") {
    return 0;
  }

  const abilityName = descriptor.ability
    ?? descriptor.skill
    ?? descriptor.habilidade
    ?? descriptor.abilityName
    ?? "";

  const specializationNames = descriptor.specializations
    ?? descriptor.specialization
    ?? descriptor.specialty
    ?? descriptor.especializacao
    ?? descriptor.especialização
    ?? descriptor.name
    ?? descriptor.names
    ?? [];

  return getSpecializationBonus(data, abilityName, specializationNames);
}

function hasDynamicEffectValue(effect) {
  return Boolean(
    effect?.valueFromAbility
    || effect?.valueFromAbilityHalf
    || effect?.valueFromSpecializationBonus
    || effect?.valueFromSpecializationBonusHalf
  );
}

function resolveDynamicEffectValue(data, effect) {
  let value = 0;

  if (effect.valueFromAbility) {
    value = getAbilityRank(data, effect.valueFromAbility, 0);
  }

  if (effect.valueFromAbilityHalf) {
    value = Math.floor(getAbilityRank(data, effect.valueFromAbilityHalf, 0) / 2);
  }

  if (effect.valueFromSpecializationBonus) {
    value = getSpecializationBonusFromDescriptor(data, effect.valueFromSpecializationBonus);
  }

  if (effect.valueFromSpecializationBonusHalf) {
    value = Math.floor(getSpecializationBonusFromDescriptor(data, effect.valueFromSpecializationBonusHalf) / 2);
  }

  const multiplier = toNumber(
    effect.multiplier
      ?? effect.valueMultiplier
      ?? effect.valueFromSpecializationBonus?.multiplier
      ?? effect.valueFromAbility?.multiplier
      ?? 1,
    1
  );

  const divisor = toNumber(
    effect.divisor
      ?? effect.valueDivisor
      ?? effect.valueFromSpecializationBonus?.divisor
      ?? effect.valueFromAbility?.divisor
      ?? 1,
    1
  );

  if (divisor !== 0) {
    value = value * multiplier / divisor;
  } else {
    value = value * multiplier;
  }

  const rounding = normalizeKey(effect.rounding ?? "floor");

  if (rounding === "ceil" || rounding === "up") {
    return Math.ceil(value);
  }

  if (rounding === "round") {
    return Math.round(value);
  }

  return Math.floor(value);
}

function getTraitEffects(data) {
  const qualities = Array.isArray(data?.traits?.qualities) ? data.traits.qualities : [];
  const defects = Array.isArray(data?.traits?.defects) ? data.traits.defects : [];
  const traits = [
    ...qualities.map((trait) => ({ ...trait, traitKind: "quality" })),
    ...defects.map((trait) => ({ ...trait, traitKind: "defect" }))
  ];

  const effects = [];

  for (const trait of traits) {
    const traitEffects = Array.isArray(trait.effects) ? trait.effects : [];

    for (const effect of traitEffects) {
      if (!effect || typeof effect !== "object") continue;
      if (effect.enabled === false || effect.disabled === true) continue;

      const clonedEffect = cloneData(effect);

      if (hasDynamicEffectValue(clonedEffect)) {
        const resolvedValue = resolveDynamicEffectValue(data, clonedEffect);
        clonedEffect.value = resolvedValue;
        clonedEffect.resolvedValue = resolvedValue;
      }

      effects.push({
        ...clonedEffect,
        sourceName: trait.name ?? "Característica",
        sourceKind: trait.traitKind ?? "trait"
      });
    }
  }

  return effects;
}

function isStatModifierEffect(effect) {
  const type = normalizeKey(effect.type ?? effect.kind ?? "");

  return type === "stat.modifier"
    || type === "statmodifier"
    || type === "derived.modifier"
    || type === "derivedmodifier";
}

function normalizeStatTarget(target) {
  const normalized = normalizeKey(target);

  if (["movement", "movimento"].includes(normalized)) {
    return "movement";
  }

  if (["run", "corrida"].includes(normalized)) {
    return "run";
  }

  if (["runmultiplier", "corridamultiplicador", "multiplicadorcorrida", "multiplicador de corrida"].includes(normalized)) {
    return "runMultiplier";
  }

  if (["health", "saude", "saúde"].includes(normalized)) {
    return "health";
  }

  if (["combatdefense", "defesacombate", "defesaemcombate", "defesa em combate"].includes(normalized)) {
    return "combatDefense";
  }

  if (["intriguedefense", "defesaintriga", "defesaemintriga", "defesa em intriga"].includes(normalized)) {
    return "intrigueDefense";
  }

  if (["composure", "compostura"].includes(normalized)) {
    return "composure";
  }

  if (["frustrationlimit", "frustrations", "frustracoes", "frustrações", "limitefrustracoes", "limite de frustracoes"].includes(normalized)) {
    return "frustrationLimit";
  }

  if (["bulk", "volume"].includes(normalized)) {
    return "bulk";
  }

  if (["armorvalue", "valorarmadura", "valor de armadura", "va"].includes(normalized)) {
    return "armorValue";
  }

  if (["armorbulk", "volumearmadura", "volume da armadura", "armadurabulk"].includes(normalized)) {
    return "armorBulk";
  }

  if (["armorpenalty", "penaltyarmor", "penalidadearmadura", "penalidadearmadura", "penalidade de armadura", "pa"].includes(normalized)) {
    return "armorPenalty";
  }

  if (["defensebonus", "bonusdefesa", "bônusdefesa", "bonus de defesa", "bônus de defesa"].includes(normalized)) {
    return "defenseBonus";
  }

  return normalized;
}

function getEffectTarget(effect) {
  return normalizeStatTarget(effect.target ?? effect.stat ?? effect.attribute ?? "");
}

function getEffectMode(effect) {
  return normalizeKey(effect.mode ?? effect.operation ?? "add");
}

function getDisplayTargetLabel(target) {
  switch (target) {
    case "movement":
      return "Movimento";

    case "run":
      return "Corrida";

    case "runMultiplier":
      return "Multiplicador de Corrida";

    case "health":
      return "Saúde";

    case "combatDefense":
      return "Defesa em Combate";

    case "intrigueDefense":
      return "Defesa em Intriga";

    case "composure":
      return "Compostura";

    case "frustrationLimit":
      return "Limite de Frustrações";

    case "bulk":
      return "Volume";

    case "armorValue":
      return "VA da Armadura";

    case "armorBulk":
      return "Volume da Armadura";

    case "armorPenalty":
      return "Penalidade de Armadura";

    case "defenseBonus":
      return "Bônus de Defesa";

    default:
      return target;
  }
}

export function getStatModifierEffects(data, target) {
  const normalizedTarget = normalizeStatTarget(target);

  return getTraitEffects(data).filter((effect) => {
    if (!isStatModifierEffect(effect)) return false;

    return getEffectTarget(effect) === normalizedTarget;
  });
}

function getModifierDescription(effect) {
  const mode = getEffectMode(effect);
  const value = toNumber(effect.value, 0);

  if (effect.label) return effect.label;

  if (mode === "multiply" || mode === "mult" || mode === "x") {
    return `x${value}`;
  }

  if (mode === "set" || mode === "override") {
    return `define como ${value}`;
  }

  return formatSigned(value);
}

function applySingleModifier(baseValue, effect, context = {}) {
  const mode = getEffectMode(effect);
  let rawValue = toNumber(effect.value, 0);

  if (effect.capByBaseValue || effect.maximumFromBaseValue || effect.maxFromBaseValue) {
    const baseCap = Math.max(0, toNumber(context.baseValue ?? baseValue, 0));
    rawValue = Math.min(rawValue, baseCap);
  }

  const minimum = effect.minimum === undefined ? null : toNumber(effect.minimum, 0);
  const maximum = effect.maximum === undefined ? null : toNumber(effect.maximum, 0);

  let nextValue = baseValue;

  if (mode === "multiply" || mode === "mult" || mode === "x") {
    nextValue = Math.floor(nextValue * rawValue);
  } else if (mode === "set" || mode === "override") {
    nextValue = rawValue;
  } else if (mode === "subtract" || mode === "sub" || mode === "minus") {
    nextValue -= rawValue;
  } else {
    nextValue += rawValue;
  }

  if (minimum !== null) {
    nextValue = Math.max(minimum, nextValue);
  }

  if (maximum !== null) {
    nextValue = Math.min(maximum, nextValue);
  }

  return nextValue;
}

function sortModifierEffects(effects) {
  const order = {
    set: 10,
    override: 10,
    add: 20,
    subtract: 20,
    multiply: 30,
    mult: 30,
    x: 30
  };

  return [...effects].sort((a, b) => {
    const aMode = getEffectMode(a);
    const bMode = getEffectMode(b);

    return (order[aMode] ?? 20) - (order[bMode] ?? 20);
  });
}

function applyModifiers(baseValue, effects, target) {
  let value = baseValue;

  const applied = sortModifierEffects(effects).map((effect) => {
    const before = value;
    const context = { baseValue, target };
    const after = applySingleModifier(before, effect, context);

    value = after;

    return {
      id: effect.id ?? "",
      sourceName: effect.sourceName ?? "Característica",
      target,
      mode: getEffectMode(effect),
      rawValue: effect.value,
      before,
      after,
      label: getModifierDescription(effect)
    };
  });

  return {
    value,
    applied
  };
}

function getArmorValue(data) {
  const manualValue = toInteger(data?.combat?.armor?.value, 0);
  const modifierEffects = getStatModifierEffects(data, "armorValue");
  const modified = applyModifiers(manualValue, modifierEffects, "armorValue");
  const finalValue = Math.max(0, Math.floor(modified.value));

  return {
    target: "armorValue",
    label: "VA da Armadura",
    baseValue: manualValue,
    value: finalValue,
    modified: finalValue !== manualValue || modified.applied.length > 0,
    applied: modified.applied
  };
}

function getArmorPenalty(data) {
  const manualPenalty = toInteger(data?.combat?.armor?.penalty, 0);
  const modifierEffects = getStatModifierEffects(data, "armorPenalty");
  const modified = applyModifiers(manualPenalty, modifierEffects, "armorPenalty");

  return {
    target: "armorPenalty",
    label: "Penalidade de Armadura",
    baseValue: manualPenalty,
    value: modified.value,
    modified: modified.value !== manualPenalty,
    applied: modified.applied
  };
}


function hasTraitNamed(data, traitNames = []) {
  const wantedNames = normalizeNameList(traitNames).map(normalizeKey);

  if (wantedNames.length === 0) return false;

  const qualities = Array.isArray(data?.traits?.qualities) ? data.traits.qualities : [];
  const defects = Array.isArray(data?.traits?.defects) ? data.traits.defects : [];

  return [...qualities, ...defects].some((trait) => {
    return wantedNames.includes(normalizeKey(trait?.name));
  });
}

function normalizeEquipmentText(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function equipmentValueToText(value) {
  if (value === undefined || value === null) return "";
  if (["string", "number", "boolean"].includes(typeof value)) return String(value).trim();

  if (Array.isArray(value)) {
    return value
      .map((entry) => equipmentValueToText(entry))
      .filter(Boolean)
      .join(" | ");
  }

  if (typeof value === "object") {
    for (const key of ["name", "nome", "label", "title", "value", "valor", "id", "text", "texto", "formula"]) {
      const text = equipmentValueToText(value[key]);
      if (text) return text;
    }

    return Object.values(value)
      .map((entry) => equipmentValueToText(entry))
      .filter(Boolean)
      .join(" | ");
  }

  return "";
}

function splitWeaponQualities(value) {
  const text = equipmentValueToText(value);

  if (!text) return [];

  return text
    .split(/[|,;]/g)
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function getDefensiveBonusFromWeapon(weapon) {
  let bestBonus = 0;

  for (const quality of splitWeaponQualities(weapon?.qualities)) {
    const match = normalizeEquipmentText(quality).match(/defensiva\s*\+?\s*(\d+)/);
    if (!match) continue;

    bestBonus = Math.max(bestBonus, toInteger(match[1], 0));
  }

  return bestBonus;
}

function getBulkFromWeapon(weapon) {
  const explicitBulk = Number(String(weapon?.bulk ?? "").replace(",", ".").match(/[+-]?\d+(?:\.\d+)?/)?.[0] ?? NaN);

  if (Number.isFinite(explicitBulk)) {
    return Math.max(0, Math.trunc(explicitBulk));
  }

  let bestBulk = 0;

  for (const text of [
    ...splitWeaponQualities(weapon?.qualities),
    equipmentValueToText(weapon?.notes)
  ]) {
    const match = normalizeEquipmentText(text).match(/(?:volume|vol\.?)\s*([+-]?\d+)/);
    if (!match) continue;

    bestBulk = Math.max(bestBulk, toInteger(match[1], 0));
  }

  return Math.max(0, bestBulk);
}

function isShieldWeapon(weapon) {
  const gearType = normalizeEquipmentText(weapon?.gearType ?? weapon?.sourceGearType ?? weapon?.type);
  const name = normalizeEquipmentText(weapon?.name);

  return gearType === "shield" || name.includes("escudo");
}

function getCarriedWeapons(data) {
  const weapons = Array.isArray(data?.combat?.weapons) ? data.combat.weapons : [];

  return weapons.filter((weapon) => isCarried(weapon?.carried));
}

function getManualDefenseShieldBulk(data) {
  return Math.max(0, toInteger(
    data?.derived?.defenseBonusBulk
      ?? data?.derived?.defenseShieldBulk
      ?? data?.derived?.shieldBulk
      ?? 0,
    0
  ));
}

function getEffectiveShieldBulkInfo(data) {
  const shieldSources = getCarriedWeapons(data)
    .filter(isShieldWeapon)
    .map((weapon) => {
      const bulk = getBulkFromWeapon(weapon);

      return {
        name: equipmentValueToText(weapon?.name) || "Escudo",
        bulk
      };
    });

  if (shieldSources.length > 0) {
    const value = shieldSources.reduce((best, source) => Math.max(best, source.bulk), 0);

    return {
      value,
      source: "weapons",
      sources: shieldSources
    };
  }

  return {
    value: getManualDefenseShieldBulk(data),
    source: "manual",
    sources: []
  };
}

function getDefensiveEquipmentBonus(data) {
  const sources = [];
  let total = 0;

  for (const weapon of getCarriedWeapons(data)) {
    const bonus = getDefensiveBonusFromWeapon(weapon);

    if (bonus <= 0) continue;

    const name = equipmentValueToText(weapon?.name) || "Equipamento defensivo";
    total += bonus;

    sources.push({
      id: `defensive-equipment-${normalizeEquipmentText(name).replace(/[^a-z0-9]+/g, "-")}`,
      sourceName: name,
      target: "defenseBonus",
      mode: "equipment",
      rawValue: bonus,
      label: `+${bonus} Defensiva`
    });
  }

  return { total, sources };
}

function getDefenseShieldBulk(data) {
  return getEffectiveShieldBulkInfo(data).value;
}

function getDefenseAcrobaticaInfo(data) {
  const hasQuality = hasTraitNamed(data, [
    "Defesa Acrobática",
    "Defesa Acrobatica"
  ]);
  const active = Boolean(data?.derived?.defenseAcrobaticaActive);
  const acrobaticsBonus = getSpecializationBonus(data, "Agilidade", [
    "Acrobacia"
  ]);
  const bonus = Math.max(0, acrobaticsBonus * 2);
  const armorBulk = getArmorBulk(data).value;
  const shieldBulkInfo = getEffectiveShieldBulkInfo(data);
  const shieldBulk = shieldBulkInfo.value;
  const blockedByArmor = armorBulk >= 1;
  const blockedByShield = shieldBulk >= 1;
  const blocked = blockedByArmor || blockedByShield;
  const canApply = hasQuality && active && bonus > 0 && !blocked;

  return {
    hasQuality,
    active,
    acrobaticsBonus,
    bonus,
    armorBulk,
    shieldBulk,
    blockedByArmor,
    blockedByShield,
    blocked,
    canApply,
    shieldBulkSource: shieldBulkInfo.source,
    shieldBulkSources: shieldBulkInfo.sources
  };
}

function getDefenseBonus(data) {
  const manualBonus = toInteger(data?.derived?.defenseBonus, 0);
  const modifierEffects = getStatModifierEffects(data, "defenseBonus");
  const modified = applyModifiers(manualBonus, modifierEffects, "defenseBonus");
  const defensiveEquipment = getDefensiveEquipmentBonus(data);
  const defenseAcrobatica = getDefenseAcrobaticaInfo(data);

  let value = modified.value;
  const applied = [...modified.applied];

  for (const source of defensiveEquipment.sources) {
    const before = value;
    value += source.rawValue;

    applied.push({
      ...source,
      before,
      after: value
    });
  }

  if (defenseAcrobatica.canApply) {
    const before = value;
    value += defenseAcrobatica.bonus;

    applied.push({
      id: "defesa-acrobatica-active-defense-bonus",
      sourceName: "Defesa Acrobática",
      target: "defenseBonus",
      mode: "maneuver",
      rawValue: defenseAcrobatica.bonus,
      before,
      after: value,
      label: `+${defenseAcrobatica.bonus} Defesa em Combate até o início do próximo turno (${defenseAcrobatica.acrobaticsBonus}B em Acrobacia × 2)`
    });
  }

  return {
    target: "defenseBonus",
    label: "Bônus de Defesa",
    baseValue: manualBonus,
    value,
    modified: value !== manualBonus || applied.length > 0,
    applied,
    details: {
      defensiveEquipment,
      defenseAcrobatica
    }
  };
}
function getArmorBulk(data) {
  const manualBulk = Math.max(0, toInteger(data?.combat?.armor?.bulk, 0));
  const modifierEffects = getStatModifierEffects(data, "armorBulk");
  const modified = applyModifiers(manualBulk, modifierEffects, "armorBulk");
  const finalValue = Math.max(0, Math.floor(modified.value));

  return {
    target: "armorBulk",
    label: "Volume da Armadura",
    baseValue: manualBulk,
    value: finalValue,
    modified: finalValue !== manualBulk || modified.applied.length > 0,
    applied: modified.applied
  };
}

function getWeaponBulkTotal(data) {
  return getCarriedWeapons(data).reduce((total, weapon) => {
    return total + getBulkFromWeapon(weapon);
  }, 0);
}
function getInventoryBulkTotal(data) {
  const inventoryItems = Array.isArray(data?.inventory?.items) ? data.inventory.items : [];

  return inventoryItems.reduce((total, item) => {
    if (!isCarried(item?.carried)) return total;

    const itemBulk = toInteger(item?.bulk ?? item?.volume, 0);
    const quantity = Math.max(1, toInteger(item?.quantity ?? item?.qty, 1));

    return total + Math.max(0, itemBulk) * quantity;
  }, 0);
}

function calculateBulk(data, armorBulkStat = null) {
  const armorBulk = armorBulkStat ?? getArmorBulk(data);
  const weaponBulk = getWeaponBulkTotal(data);
  const inventoryBulk = getInventoryBulkTotal(data);

  const baseValue = armorBulk.value + weaponBulk + inventoryBulk;
  const modifierEffects = getStatModifierEffects(data, "bulk");
  const modified = applyModifiers(baseValue, modifierEffects, "bulk");
  const finalValue = Math.max(0, Math.floor(modified.value));

  return {
    target: "bulk",
    label: "Volume",
    baseValue,
    value: finalValue,
    modified: finalValue !== baseValue,
    applied: modified.applied,
    details: {
      armorBulk: armorBulk.value,
      armorBulkBase: armorBulk.baseValue,
      armorBulkApplied: armorBulk.applied,
      weaponBulk,
      inventoryBulk
    }
  };
}

function getRunningBonusDice(data) {
  return getSpecializationBonus(data, "Atletismo", [
    "Correr",
    "Corrida"
  ]);
}

function getMovementBase(data, runningBonusDice) {
  const configuredBase = toInteger(data?.derived?.movementBase, 4);
  const athleticsRank = getAbilityRank(data, "Atletismo", 2);

  if (athleticsRank <= 1 && runningBonusDice <= 0) {
    return 3;
  }

  return configuredBase;
}

function calculateRunMultiplier(data) {
  const baseValue = toNumber(data?.derived?.runMultiplier, 4);
  const modifierEffects = getStatModifierEffects(data, "runMultiplier");
  const modified = applyModifiers(baseValue, modifierEffects, "runMultiplier");
  const finalValue = Math.max(1, modified.value);

  return {
    target: "runMultiplier",
    label: "Multiplicador de Corrida",
    baseValue,
    value: finalValue,
    modified: finalValue !== baseValue,
    applied: modified.applied
  };
}

function calculateMovement(data, bulkStat = null) {
  const bulk = bulkStat ?? calculateBulk(data);
  const runningBonusDice = getRunningBonusDice(data);
  const runningBonusMeters = Math.floor(runningBonusDice / 2);
  const movementBase = getMovementBase(data, runningBonusDice);
  const beforeTraitModifiers = movementBase + runningBonusMeters;

  const modifierEffects = getStatModifierEffects(data, "movement");
  const modified = applyModifiers(beforeTraitModifiers, modifierEffects, "movement");

  const beforeBulk = Math.max(1, Math.floor(modified.value));
  const bulkPenalty = Math.floor(Math.max(0, bulk.value) / 2);
  const finalValue = Math.max(1, beforeBulk - bulkPenalty);

  const applied = [
    ...(runningBonusMeters > 0
      ? [
        {
          id: "athletics-running-bonus",
          sourceName: "Atletismo: Corrida",
          target: "movement",
          mode: "specialization",
          rawValue: runningBonusDice,
          before: movementBase,
          after: movementBase + runningBonusMeters,
          label: `+${runningBonusMeters}m por ${runningBonusDice}B em Corrida`
        }
      ]
      : []),
    ...modified.applied,
    ...(bulkPenalty > 0
      ? [
        {
          id: "bulk-movement-penalty",
          sourceName: "Volume",
          target: "movement",
          mode: "bulk",
          rawValue: bulk.value,
          before: beforeBulk,
          after: finalValue,
          label: `-${bulkPenalty}m por Volume ${bulk.value}`
        }
      ]
      : [])
  ];

  return {
    target: "movement",
    label: "Movimento",
    baseValue: movementBase,
    value: finalValue,
    modified: finalValue !== movementBase || applied.length > 0,
    applied,
    details: {
      movementBase,
      athleticsRank: getAbilityRank(data, "Atletismo", 2),
      runningBonusDice,
      runningBonusMeters,
      beforeTraitModifiers,
      beforeBulk,
      bulkTotal: bulk.value,
      bulkPenalty
    }
  };
}

function calculateRun(data, movementStat = null, bulkStat = null, runMultiplierStat = null) {
  const bulk = bulkStat ?? calculateBulk(data);
  const movement = movementStat ?? calculateMovement(data, bulk);
  const runMultiplier = runMultiplierStat ?? calculateRunMultiplier(data);

  const baseValue = movement.value * runMultiplier.value;
  const afterBulk = Math.max(4, baseValue - bulk.value);

  const runModifierEffects = getStatModifierEffects(data, "run");
  const modified = applyModifiers(afterBulk, runModifierEffects, "run");
  const finalValue = Math.max(4, Math.floor(modified.value));

  const applied = [
    ...(runMultiplier.modified
      ? runMultiplier.applied.map((effect) => ({
        ...effect,
        target: "runMultiplier"
      }))
      : []),
    ...(bulk.value > 0
      ? [
        {
          id: "bulk-run-penalty",
          sourceName: "Volume",
          target: "run",
          mode: "bulk",
          rawValue: bulk.value,
          before: baseValue,
          after: afterBulk,
          label: `-${bulk.value}m por Volume ${bulk.value}`
        }
      ]
      : []),
    ...modified.applied
  ];

  return {
    target: "run",
    label: "Corrida",
    baseValue,
    value: finalValue,
    modified: finalValue !== baseValue || applied.length > 0,
    applied,
    details: {
      movement: movement.value,
      runMultiplier: runMultiplier.value,
      bulkTotal: bulk.value,
      afterBulk
    }
  };
}

function calculateCombatDefense(data, armorPenaltyStat = null, defenseBonusStat = null) {
  const armorPenalty = armorPenaltyStat ?? getArmorPenalty(data);
  const defenseBonus = defenseBonusStat ?? getDefenseBonus(data);

  const agility = getAbilityRank(data, "Agilidade", 2);
  const athletics = getAbilityRank(data, "Atletismo", 2);
  const perception = getAbilityRank(data, "PercepÃ§Ã£o", 2);

  const baseValue = agility + athletics + perception + defenseBonus.value + armorPenalty.value;
  const modifierEffects = getStatModifierEffects(data, "combatDefense");
  const modified = applyModifiers(baseValue, modifierEffects, "combatDefense");
  const finalValue = Math.max(0, Math.floor(modified.value));
  const defenseBonusApplied = (defenseBonus.applied ?? []).map((effect) => ({
    ...effect,
    target: "combatDefense"
  }));
  const applied = [...defenseBonusApplied, ...modified.applied];

  return {
    target: "combatDefense",
    label: "Defesa em Combate",
    baseValue,
    value: finalValue,
    modified: finalValue !== baseValue || applied.length > 0,
    applied,
    details: {
      agility,
      athletics,
      perception,
      defenseBonus: defenseBonus.value,
      armorPenalty: armorPenalty.value,
      defenseBonusApplied
    }
  };
}
function calculateHealth(data) {
  const vigor = getAbilityRank(data, "Vigor", 2);
  const baseValue = vigor * 3;
  const modifierEffects = getStatModifierEffects(data, "health");
  const modified = applyModifiers(baseValue, modifierEffects, "health");
  const finalValue = Math.max(0, Math.floor(modified.value));

  return {
    target: "health",
    label: "Saúde",
    baseValue,
    value: finalValue,
    modified: finalValue !== baseValue || modified.applied.length > 0,
    applied: modified.applied,
    details: {
      vigor
    }
  };
}

function calculateIntrigueDefense(data) {
  const cunning = getAbilityRank(data, "Astúcia", 2);
  const perception = getAbilityRank(data, "Percepção", 2);
  const status = getAbilityRank(data, "Status", 2);

  const baseValue = cunning + perception + status;
  const modifierEffects = getStatModifierEffects(data, "intrigueDefense");
  const modified = applyModifiers(baseValue, modifierEffects, "intrigueDefense");
  const finalValue = Math.max(0, Math.floor(modified.value));

  return {
    target: "intrigueDefense",
    label: "Defesa em Intriga",
    baseValue,
    value: finalValue,
    modified: finalValue !== baseValue || modified.applied.length > 0,
    applied: modified.applied,
    details: {
      cunning,
      perception,
      status
    }
  };
}

function calculateComposure(data) {
  const will = getAbilityRank(data, "Vontade", 2);
  const baseValue = will * 3;
  const modifierEffects = getStatModifierEffects(data, "composure");
  const modified = applyModifiers(baseValue, modifierEffects, "composure");
  const finalValue = Math.max(0, Math.floor(modified.value));

  return {
    target: "composure",
    label: "Compostura",
    baseValue,
    value: finalValue,
    modified: finalValue !== baseValue || modified.applied.length > 0,
    applied: modified.applied,
    details: {
      will
    }
  };
}

function calculateFrustrationLimit(data) {
  const will = getAbilityRank(data, "Vontade", 2);
  const baseValue = will;
  const modifierEffects = getStatModifierEffects(data, "frustrationLimit");
  const modified = applyModifiers(baseValue, modifierEffects, "frustrationLimit");
  const finalValue = Math.max(0, Math.floor(modified.value));

  return {
    target: "frustrationLimit",
    label: "Limite de Frustrações",
    baseValue,
    value: finalValue,
    modified: finalValue !== baseValue || modified.applied.length > 0,
    applied: modified.applied,
    details: {
      will
    }
  };
}

function makeBasicStat(data, target, baseValue = 0) {
  const normalizedTarget = normalizeStatTarget(target);
  const modifierEffects = getStatModifierEffects(data, normalizedTarget);
  const modified = applyModifiers(baseValue, modifierEffects, normalizedTarget);

  return {
    target: normalizedTarget,
    label: getDisplayTargetLabel(normalizedTarget),
    baseValue,
    value: modified.value,
    modified: modified.value !== baseValue || modified.applied.length > 0,
    applied: modified.applied
  };
}

export function calculateModifiedStat(data, target) {
  const normalizedTarget = normalizeStatTarget(target);
  const allStats = calculateAllModifiedStats(data);

  if (allStats[normalizedTarget]) {
    return allStats[normalizedTarget];
  }

  return makeBasicStat(data, normalizedTarget, 0);
}

export function calculateAllModifiedStats(data) {
  const armorValue = getArmorValue(data);
  const armorBulk = getArmorBulk(data);
  const bulk = calculateBulk(data, armorBulk);
  const armorPenalty = getArmorPenalty(data);
  const defenseBonus = getDefenseBonus(data);
  const runMultiplier = calculateRunMultiplier(data);
  const movement = calculateMovement(data, bulk);
  const run = calculateRun(data, movement, bulk, runMultiplier);
  const combatDefense = calculateCombatDefense(data, armorPenalty, defenseBonus);
  const health = calculateHealth(data);
  const intrigueDefense = calculateIntrigueDefense(data);
  const composure = calculateComposure(data);
  const frustrationLimit = calculateFrustrationLimit(data);

  return {
    armorValue,
    armorBulk,
    bulk,
    armorPenalty,
    defenseBonus,
    movement,
    run,
    runMultiplier,
    combatDefense,
    health,
    intrigueDefense,
    composure,
    frustrationLimit
  };
}

export function buildDerivedStatsView(data) {
  const stats = calculateAllModifiedStats(data);

  return {
    ...stats,

    combat: {
      combatDefense: stats.combatDefense,
      health: stats.health,
      movement: stats.movement,
      run: stats.run,
      armorValue: stats.armorValue,
      armorBulk: stats.armorBulk,
      bulk: stats.bulk,
      armorPenalty: stats.armorPenalty,
      defenseBonus: stats.defenseBonus,
      runMultiplier: stats.runMultiplier
    },

    intrigue: {
      intrigueDefense: stats.intrigueDefense,
      composure: stats.composure,
      frustrationLimit: stats.frustrationLimit
    }
  };
}

export function buildStatModifierDebugReport(data) {
  const stats = calculateAllModifiedStats(data);

  return {
    moduleId: MODULE_ID,
    stats,
    rawEffects: {
      movement: getStatModifierEffects(data, "movement"),
      run: getStatModifierEffects(data, "run"),
      runMultiplier: getStatModifierEffects(data, "runMultiplier"),
      health: getStatModifierEffects(data, "health"),
      combatDefense: getStatModifierEffects(data, "combatDefense"),
      intrigueDefense: getStatModifierEffects(data, "intrigueDefense"),
      composure: getStatModifierEffects(data, "composure"),
      frustrationLimit: getStatModifierEffects(data, "frustrationLimit"),
      armorValue: getStatModifierEffects(data, "armorValue"),
      armorBulk: getStatModifierEffects(data, "armorBulk"),
      bulk: getStatModifierEffects(data, "bulk"),
      armorPenalty: getStatModifierEffects(data, "armorPenalty"),
      defenseBonus: getStatModifierEffects(data, "defenseBonus")
    }
  };
}